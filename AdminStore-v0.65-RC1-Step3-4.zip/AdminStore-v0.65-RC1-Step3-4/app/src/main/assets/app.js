(() => {
  'use strict';

  const CONFIG = window.AdminStoreConfig || {};
  const nativeValue = (name) => {
    try {
      const value = window.NativeBridge?.[name]?.();
      return typeof value === 'string' && value.trim() ? value.trim() : '';
    } catch (_) { return ''; }
  };
  const API_BASE = (nativeValue('apiBaseUrl') || CONFIG.apiBase || '').replace(/\/+$/, '');
  const HEALTH_URL = nativeValue('healthUrl') || CONFIG.healthUrl || '';
  const APP_VERSION = nativeValue('appVersion') || CONFIG.appVersion || 'dev';
  const API_HOST = (() => { try { return new URL(API_BASE).host; } catch (_) { return API_BASE || 'نامشخص'; } })();
  const TOKEN_KEY = 'adminstore.access';
  let token = sessionStorage.getItem(TOKEN_KEY) || '';
  let me = null;
  let page = 'dashboard';
  let cache = { dashboard:null, products:[], productMeta:null, catalog:null, inventory:[], inventoryHistory:{}, orders:[], payments:[], audit:[] };
  let moreOpen = false;
  let modalOpen = false;

  const Authz = window.AdminStorePermissions;
  if (!Authz) throw new Error('AdminStorePermissions is required');
  const P = Authz.P;
  const can = permission => Authz.has(me, permission);
  const canAny = permissions => Authz.hasAny(me, permissions);
  const canAccessPage = target => Authz.canAccessPage(me, target);
  const requirePermission = (permission, message='برای این عملیات دسترسی کافی ندارید.') => {
    if (can(permission)) return true;
    toast(message, 'error');
    return false;
  };
  const requireAnyPermission = (permissions, message='برای این عملیات دسترسی کافی ندارید.') => {
    if (canAny(permissions)) return true;
    toast(message, 'error');
    return false;
  };

  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const esc = (v='') => String(v).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const fa = n => new Intl.NumberFormat('fa-IR').format(Number(n || 0));
  const money = n => `${fa(n)} تومان`;
  const dateFa = v => v ? new Date(v).toLocaleString('fa-IR') : '—';
  const haptic = () => { try { window.NativeBridge?.haptic(); } catch (_) {} };
  const openUrl = url => { try { if (window.NativeBridge?.openUrl) window.NativeBridge.openUrl(url); else window.open(url, '_blank'); } catch (_) {} };

  const statusFa = {
    DRAFT:'پیش‌نویس', AWAITING_PAYMENT:'در انتظار پرداخت', PAYMENT_SUBMITTED:'رسید ارسال شده', PAYMENT_REVIEW:'بررسی پرداخت',
    PAID:'پرداخت شده', PREPARING:'در حال آماده‌سازی', SHIPPED:'ارسال شده', DELIVERED:'تحویل شده', CANCELLED:'لغو شده', RETURNED:'مرجوعی',
    CREATED:'ایجاد شده', REVIEW:'نیازمند بررسی', APPROVED:'تأیید شده', REJECTED:'رد شده', NEEDS_RESUBMISSION:'ارسال مجدد رسید'
  };
  const statusClass = s => ['APPROVED','PAID','DELIVERED'].includes(s) ? 'ok' : ['REVIEW','PAYMENT_REVIEW','PREPARING','SHIPPED','NEEDS_RESUBMISSION'].includes(s) ? 'warn' : ['REJECTED','CANCELLED','RETURNED'].includes(s) ? 'danger' : '';
  const statusBadge = s => `<span class="badge ${statusClass(s)}">${esc(statusFa[s] || s || '—')}</span>`;

  function toast(msg, type='ok') {
    const el = $('#toast');
    el.textContent = msg;
    el.className = `toast show ${type === 'error' ? 'error' : ''}`;
    clearTimeout(toast._t);
    toast._t = setTimeout(() => el.className = 'toast', 2800);
  }

  const errorFa = code => ({
    INVALID_ADMIN_CREDENTIALS:'شماره موبایل یا رمز عبور نادرست است.', UNAUTHORIZED_ADMIN:'نشست مدیر منقضی شده است.', REFRESH_REQUIRED:'لطفاً دوباره وارد شوید.',
    SESSION_EXPIRED:'نشست شما منقضی شده است.', FORBIDDEN:'برای این عملیات دسترسی کافی ندارید.', HTTP_403:'برای این عملیات دسترسی کافی ندارید.', VALIDATION_ERROR:'اطلاعات واردشده معتبر نیست.',
    PRODUCT_NOT_FOUND:'محصول پیدا نشد.', VARIANT_NOT_FOUND:'واریانت پیدا نشد.', SKU_EXISTS:'این SKU قبلاً ثبت شده است.', INVENTORY_NOT_FOUND:'رکورد موجودی پیدا نشد.', INVALID_STOCK_ADJUSTMENT:'تغییر موجودی معتبر نیست.', ENDPOINT_NOT_AVAILABLE:'این قابلیت هنوز در بک‌اند فعال نشده است.', ORDER_NOT_FOUND:'سفارش پیدا نشد.', INVALID_ORDER_TRANSITION:'این تغییر وضعیت مجاز نیست.',
    PAYMENT_NOT_FOUND:'پرداخت پیدا نشد.', PAYMENT_NOT_REVIEWABLE:'این پرداخت قابل بررسی نیست.', RECEIPT_NOT_FOUND:'رسید برای این پرداخت ثبت نشده است.',
    STORAGE_NOT_CONFIGURED:'فضای ذخیره‌سازی رسید هنوز تنظیم نشده است.', STOCK_CHANGED:'موجودی محصول تغییر کرده است.', NETWORK:'اتصال به سرور برقرار نشد.', API_CONFIG:'آدرس API تنظیم نشده است.'
  }[code] || code || 'خطای نامشخص');

  const NO_REFRESH_PATHS = new Set(['/admin/auth/login','/admin/auth/refresh','/admin/auth/logout']);
  let refreshPromise = null;

  async function refreshSession() {
    if (refreshPromise) return refreshPromise;
    refreshPromise = (async () => {
      let rr;
      try {
        rr = await fetch(API_BASE + '/admin/auth/refresh', {
          method:'POST',
          credentials:'include',
          headers:{'Accept':'application/json'}
        });
      } catch (_) {
        const e = new Error('NETWORK'); e.code='NETWORK'; throw e;
      }
      if (!rr.ok) {
        const e = new Error('SESSION_EXPIRED'); e.code='SESSION_EXPIRED'; e.status=rr.status; throw e;
      }
      const payload = await rr.json();
      if (!payload?.accessToken) {
        const e = new Error('SESSION_EXPIRED'); e.code='SESSION_EXPIRED'; throw e;
      }
      setToken(payload.accessToken);
      if (payload.admin) {
        me = {
          ...(me || {}),
          ...payload.admin,
          permissions: payload.admin.permissions ?? me?.permissions,
          role: payload.admin.role ?? me?.role
        };
      }
      return payload;
    })().finally(() => { refreshPromise = null; });
    return refreshPromise;
  }

  async function raw(path, options={}, retry=true) {
    if (!API_BASE) { const e = new Error('API_CONFIG'); e.code='API_CONFIG'; throw e; }
    const headers = new Headers(options.headers || {});
    headers.set('Accept','application/json');
    if (!(options.body instanceof FormData)) headers.set('Content-Type','application/json');
    if (token) headers.set('Authorization', `Bearer ${token}`);
    let res;
    try {
      res = await fetch(API_BASE + path, {...options, headers, credentials:'include'});
    } catch (_) {
      const e = new Error('NETWORK'); e.code='NETWORK'; throw e;
    }
    if (res.status === 401 && retry && !NO_REFRESH_PATHS.has(path)) {
      try {
        await refreshSession();
        return raw(path, options, false);
      } catch (refreshError) {
        setToken('');
        me = null;
        throw refreshError;
      }
    }
    if (!res.ok) {
      let payload = {};
      try { payload = await res.json(); } catch (_) {}
      const e = new Error(payload.error || `HTTP_${res.status}`); e.code = payload.error || `HTTP_${res.status}`; e.status=res.status; e.payload=payload; throw e;
    }
    return res.status === 204 ? null : res.json();
  }
  function setToken(v) { token = v || ''; token ? sessionStorage.setItem(TOKEN_KEY, token) : sessionStorage.removeItem(TOKEN_KEY); }
  const qs = params => {
    const q = new URLSearchParams();
    Object.entries(params || {}).forEach(([k,v]) => { if(v !== undefined && v !== null && v !== '' && v !== 'all') q.set(k, String(v)); });
    const out=q.toString(); return out ? `?${out}` : '';
  };
  const productId = p => String(p?.serverId ?? p?.id ?? p?._id ?? '');
  const variantId = v => String(v?.id ?? v?.serverId ?? v?._id ?? '');
  const endpointMissing = e => [404,405,501].includes(Number(e?.status));
  async function firstAvailable(requests) {
    let last=null;
    for (const fn of requests) {
      try { return await fn(); }
      catch(e) { last=e; if(!endpointMissing(e)) throw e; }
    }
    const e=last || new Error('ENDPOINT_NOT_AVAILABLE'); e.code='ENDPOINT_NOT_AVAILABLE'; throw e;
  }
  async function optionalRequest(requests, fallback=null) {
    try { return await firstAvailable(requests); }
    catch(e) { if(endpointMissing(e) || e.code==='ENDPOINT_NOT_AVAILABLE') return fallback; throw e; }
  }
  function listPayload(payload, keys=[]) {
    if(Array.isArray(payload)) return {items:payload, meta:null};
    const root=payload?.data && !Array.isArray(payload.data) && typeof payload.data==='object' ? payload.data : payload;
    const candidates=[Array.isArray(payload?.data)?payload.data:null,root?.items,root?.results,...keys.map(k=>root?.[k]),...keys.map(k=>payload?.[k])];
    const items=candidates.find(Array.isArray) || [];
    return {items, meta:root?.meta || root?.pagination || payload?.meta || payload?.pagination || null};
  }
  function absoluteAssetUrl(url='') {
    if(!url) return '';
    try { return new URL(url, API_BASE.replace(/\/api\/v\d+\/?$/, '/') || location.href).href; } catch(_) { return url; }
  }
  const api = {
    login:(mobile,password)=>raw('/admin/auth/login',{method:'POST',body:JSON.stringify({mobile,password})}),
    me:()=>raw('/admin/auth/me'), logout:()=>raw('/admin/auth/logout',{method:'POST'}),
    dashboard:()=>raw('/admin/dashboard'),
    products:(params={})=>raw('/admin/products'+qs(params)),
    product:async id=>{const r=await firstAvailable([()=>raw(`/admin/products/${id}`)]);return r?.data && !Array.isArray(r.data) ? r.data : r},
    createProduct:data=>raw('/admin/products',{method:'POST',body:JSON.stringify(data)}),
    updateProduct:(id,data)=>raw(`/admin/products/${id}`,{method:'PATCH',body:JSON.stringify(data)}),
    archiveProduct:id=>firstAvailable([()=>raw(`/admin/products/${id}`,{method:'DELETE'}),()=>raw(`/admin/products/${id}`,{method:'PATCH',body:JSON.stringify({active:false,archived:true})})]),
    updateVariant:(id,data)=>raw(`/admin/variants/${id}`,{method:'PATCH',body:JSON.stringify(data)}),
    createVariant:(productId,data)=>firstAvailable([()=>raw(`/admin/products/${productId}/variants`,{method:'POST',body:JSON.stringify(data)}),()=>raw('/admin/variants',{method:'POST',body:JSON.stringify({...data,productId})})]),
    deleteVariant:(productId,id)=>firstAvailable([()=>raw(`/admin/products/${productId}/variants/${id}`,{method:'DELETE'}),()=>raw(`/admin/variants/${id}`,{method:'DELETE'})]),
    validateSku:(sku,excludeId='')=>optionalRequest([()=>raw('/admin/variants/validate-sku'+qs({sku,excludeId}))],null),
    categories:()=>optionalRequest([()=>raw('/admin/categories')],[]),
    brands:()=>optionalRequest([()=>raw('/admin/brands')],[]),
    attributes:()=>optionalRequest([()=>raw('/admin/attributes')],[]),
    createCategory:data=>firstAvailable([()=>raw('/admin/categories',{method:'POST',body:JSON.stringify(data)})]),
    updateCategory:(id,data)=>raw(`/admin/categories/${id}`,{method:'PATCH',body:JSON.stringify(data)}),
    deleteCategory:id=>raw(`/admin/categories/${id}`,{method:'DELETE'}),
    createBrand:data=>firstAvailable([()=>raw('/admin/brands',{method:'POST',body:JSON.stringify(data)})]),
    updateBrand:(id,data)=>raw(`/admin/brands/${id}`,{method:'PATCH',body:JSON.stringify(data)}),
    deleteBrand:id=>raw(`/admin/brands/${id}`,{method:'DELETE'}),
    createAttribute:data=>firstAvailable([()=>raw('/admin/attributes',{method:'POST',body:JSON.stringify(data)})]),
    updateAttribute:(id,data)=>raw(`/admin/attributes/${id}`,{method:'PATCH',body:JSON.stringify(data)}),
    deleteAttribute:id=>raw(`/admin/attributes/${id}`,{method:'DELETE'}),
    uploadProductImage:(id,file)=>{const fd=new FormData();fd.append('file',file);return firstAvailable([()=>raw(`/admin/products/${id}/images`,{method:'POST',body:fd}),()=>raw(`/admin/products/${id}/image`,{method:'POST',body:fd})])},
    deleteProductImage:(id,imageId)=>firstAvailable([()=>raw(`/admin/products/${id}/images/${imageId}`,{method:'DELETE'}),()=>raw(`/admin/product-images/${imageId}`,{method:'DELETE'})]),
    setMainProductImage:(id,imageId)=>firstAvailable([()=>raw(`/admin/products/${id}/images/${imageId}`,{method:'PATCH',body:JSON.stringify({isMain:true})}),()=>raw(`/admin/products/${id}/main-image`,{method:'PATCH',body:JSON.stringify({imageId})})]),
    inventory:(params={})=>optionalRequest([()=>raw('/admin/inventory'+qs(params))],null),
    inventoryHistory:id=>optionalRequest([()=>raw(`/admin/inventory/${id}/history`),()=>raw(`/admin/variants/${id}/inventory-history`)],null),
    adjustInventory:(id,data,currentStock)=>firstAvailable([()=>raw(`/admin/inventory/${id}/adjust`,{method:'POST',body:JSON.stringify(data)}),()=>raw(`/admin/variants/${id}/inventory/adjust`,{method:'POST',body:JSON.stringify(data)}),()=>raw(`/admin/variants/${id}`,{method:'PATCH',body:JSON.stringify({stock:Math.max(0,Number(data.absoluteQuantity ?? (Number(currentStock||0)+Number(data.delta||0))))})})]),
    importCatalog:(rows,dryRun)=>raw('/admin/catalog/import',{method:'POST',body:JSON.stringify({rows,dryRun})}),
    orders:()=>raw('/admin/orders'), updateOrderStatus:(id,status)=>raw(`/admin/orders/${id}/status`,{method:'PATCH',body:JSON.stringify({status})}),
    payments:()=>raw('/admin/payments'), receiptUrl:id=>raw(`/admin/payments/${id}/receipt-url`),
    approvePayment:id=>raw(`/admin/payments/${id}/approve`,{method:'POST'}),
    rejectPayment:(id,reason)=>raw(`/admin/payments/${id}/reject`,{method:'POST',body:JSON.stringify({reason,needsResubmission:true})}),
    audit:()=>raw('/admin/audit-logs')
  };

  function appRoot(html) { $('#app').innerHTML = html; }
  function loginView(error='') {
    appRoot(`<section class="login"><form class="login-card" id="login-form">
      <div class="login-logo">A</div><h1>AdminStore</h1><p>مدیریت ساده و امن فروشگاه Store</p>
      ${error ? `<div class="login-error">${esc(error)}</div>` : ''}
      <label class="field"><span>شماره موبایل مدیر</span><input id="mobile" inputmode="numeric" autocomplete="username" placeholder="09xxxxxxxxx" required></label>
      <label class="field"><span>رمز عبور</span><input id="password" type="password" autocomplete="current-password" required></label>
      <button class="btn primary full" id="login-btn">ورود به مدیریت</button>
      <div class="login-note">اتصال امن: ${esc(API_HOST)}</div>
    </form></section>`);
    $('#login-form').addEventListener('submit', async e => {
      e.preventDefault(); haptic();
      const btn=$('#login-btn'); btn.disabled=true; btn.textContent='در حال ورود…';
      try {
        const r=await api.login($('#mobile').value.trim(), $('#password').value);
        setToken(r.accessToken);
        me = await api.me();
        await showShell('dashboard');
      } catch (e) { loginView(errorFa(e.code || e.message)); }
    });
  }

  function primaryNavItems() {
    return [
      {id:'dashboard', icon:'⌂', label:'خانه', visible:true},
      {id:'products', icon:'▦', label:'محصولات', visible:canAccessPage('products')},
      {id:'orders', icon:'▤', label:'سفارش‌ها', visible:canAccessPage('orders')},
      {id:'payments', icon:'✓', label:'پرداخت', visible:canAccessPage('payments')},
      {id:'more', icon:'☰', label:'بیشتر', visible:true}
    ].filter(x=>x.visible);
  }
  function shellTemplate() {
    const navItems=primaryNavItems();
    return `<div class="shell">
      <header class="topbar"><div class="brand"><div class="brand-mark">A</div><div><strong>AdminStore</strong><small>${esc(me?.displayName || 'مدیریت فروشگاه')}</small></div></div>
      <div class="top-actions"><button class="icon-btn" id="refresh-btn" aria-label="به‌روزرسانی">↻</button><button class="icon-btn" id="more-top" aria-label="بیشتر">⋮</button></div></header>
      <main class="main" id="content"></main>
      <nav class="bottom-nav" style="--nav-count:${navItems.length}">
        ${navItems.map(x=>navButton(x.id,x.icon,x.label)).join('')}
      </nav>
      <div id="more-menu"></div>
    </div>`;
  }
  function navButton(id, ico, label) { return `<button class="nav-btn ${page===id?'active':''}" data-page="${id}"><span class="ico">${ico}</span><span>${label}</span></button>`; }

  async function showShell(next='dashboard') {
    page=next; moreOpen=false; appRoot(shellTemplate()); bindShell(); await loadPage(page);
  }
  function bindShell() {
    $$('.nav-btn').forEach(b=>b.addEventListener('click',()=>{haptic(); const p=b.dataset.page; if(p==='more') toggleMore(); else navigate(p);}));
    $('#refresh-btn')?.addEventListener('click',()=>{haptic(); loadPage(page,true)});
    $('#more-top')?.addEventListener('click',()=>{haptic(); toggleMore()});
  }
  function moreItems() {
    return [
      {id:'inventory', icon:'▥', label:'موجودی'},
      {id:'catalog', icon:'◫', label:'کاتالوگ'},
      {id:'customers', icon:'👥', label:'مشتریان'},
      {id:'import', icon:'⇧', label:'ورود CSV'},
      {id:'audit', icon:'☷', label:'گزارش عملیات'},
      {id:'account', icon:'⚙', label:'حساب و سیستم'},
      {id:'products', icon:'＋', label:'محصولات'}
    ].filter(x=>canAccessPage(x.id));
  }
  function updateNav() { $$('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.page===page || (b.dataset.page==='more'&&['inventory','catalog','customers','import','audit','account'].includes(page)))); }
  async function navigate(p) { page=p; moreOpen=false; renderMore(); updateNav(); await loadPage(p); }
  function toggleMore(){moreOpen=!moreOpen;renderMore();}
  function renderMore(){
    const host=$('#more-menu'); if(!host)return;
    const items=moreItems();
    host.innerHTML=moreOpen?`<div class="more-menu"><div class="more-grid">
      ${items.map(x=>`<button data-more="${x.id}">${x.icon}<b>${esc(x.label)}</b></button>`).join('')}<button id="close-more">×<b>بستن</b></button>
    </div></div>`:'';
    $$('[data-more]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.more)));
    $('#close-more')?.addEventListener('click',()=>toggleMore());
  }

  const pageLabels = {dashboard:'داشبورد',products:'محصولات',inventory:'موجودی',catalog:'کاتالوگ',orders:'سفارش‌ها',payments:'پرداخت‌ها',customers:'مشتریان',import:'ورود CSV',audit:'گزارش عملیات',account:'حساب و سیستم'};
  function forbiddenView(target=page) {
    const rule=Authz.pageAccess[target];
    const needed=[...(rule?.any||[]),...(rule?.all||[])];
    $('#content').innerHTML=head('دسترسی محدود',`اجازه ورود به «${pageLabels[target]||target}» را ندارید.`)+`<div class="forbidden"><div class="forbidden-code">403</div><h2>دسترسی مجاز نیست</h2><p>این حساب Permission لازم برای مشاهده یا مدیریت این بخش را ندارد.</p>${needed.length?`<div class="permission-needed">نیازمند: ${needed.map(esc).join(' یا ')}</div>`:''}<button class="btn primary" id="back-dashboard">بازگشت به داشبورد</button></div>`;
    $('#back-dashboard')?.addEventListener('click',()=>navigate('dashboard'));
  }

  function head(title, sub, action='') { return `<div class="page-head"><div><h1>${esc(title)}</h1><p>${esc(sub)}</p></div>${action}</div>`; }
  function loading(title='در حال دریافت اطلاعات…'){ $('#content').innerHTML=head(title,'')+`<div class="loading"><div class="spinner"></div><span>کمی صبر کنید</span></div>`; }
  function pageError(e){
    if(e.status===403){ forbiddenView(page); return; }
    $('#content').innerHTML += `<div class="error-box">${esc(errorFa(e.code||e.message))}</div>`;
    if(e.status===401){setToken(''); setTimeout(()=>loginView('برای ادامه دوباره وارد شوید.'),700);}
  }

  async function loadPage(p, force=false) {
    moreOpen=false; renderMore(); updateNav();
    if(!canAccessPage(p)){ forbiddenView(p); return; }
    try {
      if(p==='dashboard') return loadDashboard();
      if(p==='products') return loadProducts(force);
      if(p==='inventory') return loadInventory(force);
      if(p==='catalog') return loadCatalog(force);
      if(p==='orders') return loadOrders(force);
      if(p==='payments') return loadPayments(force);
      if(p==='customers') return loadCustomers(force);
      if(p==='import') return renderImport();
      if(p==='audit') return loadAudit(force);
      if(p==='account') return loadAccount();
    } catch(e){pageError(e)}
  }

  async function loadDashboard(){
    loading('داشبورد');
    try{
      const d=await api.dashboard(); cache.dashboard=d;
      $('#content').innerHTML=head('داشبورد','وضعیت امروز فروشگاه')+`<div class="cards">
        <div class="metric"><span>فروش امروز</span><b>${money(d.salesToday)}</b></div><div class="metric"><span>سفارش امروز</span><b>${fa(d.ordersToday)}</b></div>
        <div class="metric"><span>پرداخت برای بررسی</span><b>${fa(d.pendingPayments)}</b></div><div class="metric"><span>کم‌موجود</span><b>${fa(d.lowStock)}</b></div>
      </div><div class="panel"><h2>کارهای مهم</h2>${d.pendingPayments?`<div class="notice warn">${fa(d.pendingPayments)} پرداخت منتظر بررسی است.</div>`:`<div class="notice">پرداخت معوقی برای بررسی ندارید.</div>`}
      ${d.lowStock?`<div class="notice warn" style="margin-top:8px">${fa(d.lowStock)} واریانت کم‌موجود است.</div>`:''}</div>`;
    }catch(e){pageError(e)}
  }

  const productViewState = {page:1,limit:20,search:'',status:'all',brand:'all',category:'all',sort:'newest'};
  const inventoryViewState = {search:'',status:'all'};

  function entityId(x){ return String(x?.id ?? x?.serverId ?? x?._id ?? x?.slug ?? x?.name ?? ''); }
  function entityName(x){ return typeof x==='string' ? x : String(x?.name ?? x?.title ?? x?.label ?? x?.slug ?? ''); }
  function normalizeEntities(payload, keys=[]){ return listPayload(payload,keys).items.filter(Boolean); }
  function uniqueEntities(rows){
    const m=new Map(); rows.forEach(x=>{const name=entityName(x).trim();if(!name)return;const id=entityId(x)||name.toLowerCase();if(!m.has(id))m.set(id,typeof x==='string'?{id:name,name}:x)});return [...m.values()];
  }
  function deriveCatalog(products=[]){
    const brands=[],categories=[],attributes=[];
    products.forEach(p=>{
      if(p.brand) brands.push(typeof p.brand==='string'?{id:p.brand,name:p.brand}:p.brand);
      if(p.category) categories.push(p.category);
      if(p.categoryId && !p.category) categories.push({id:p.categoryId,name:p.categoryName||p.categoryTitle||String(p.categoryId)});
      (p.variants||[]).forEach(v=>{
        const attrs=v.attributes||v.options||{};
        if(Array.isArray(attrs)) attrs.forEach(a=>attributes.push({id:a.id||a.name,name:a.name||a.label,values:a.values||[a.value].filter(Boolean)}));
        else Object.keys(attrs||{}).forEach(k=>attributes.push({id:k,name:k,values:[attrs[k]]}));
      });
    });
    return {brands:uniqueEntities(brands),categories:uniqueEntities(categories),attributes:uniqueEntities(attributes)};
  }
  async function ensureCatalog(force=false){
    if(cache.catalog && !force) return cache.catalog;
    if(!cache.products.length){
      try{const r=await api.products({limit:200});cache.products=listPayload(r,['products']).items}catch(_){}
    }
    const derived=deriveCatalog(cache.products);
    const [cr,br,ar]=await Promise.all([api.categories(),api.brands(),api.attributes()]);
    cache.catalog={
      categories:uniqueEntities([...normalizeEntities(cr,['categories']),...derived.categories]),
      brands:uniqueEntities([...normalizeEntities(br,['brands']),...derived.brands]),
      attributes:uniqueEntities([...normalizeEntities(ar,['attributes']),...derived.attributes])
    };
    return cache.catalog;
  }

  async function loadProducts(force=false){
    loading('محصولات');
    try{
      await ensureCatalog(force);
      const params={page:productViewState.page,limit:productViewState.limit,search:productViewState.search,status:productViewState.status,brand:productViewState.brand,categoryId:productViewState.category,sort:productViewState.sort};
      const payload=await api.products(params);
      const parsed=listPayload(payload,['products']);
      cache.products=parsed.items; cache.productMeta=parsed.meta;
      renderProducts(cache.products,parsed.meta);
    }catch(e){pageError(e)}
  }
  function productMatches(p){
    const q=productViewState.search.trim().toLowerCase();
    const variants=p.variants||[];
    const txt=`${p.name||''} ${entityName(p.brand)} ${entityName(p.category)} ${variants.map(v=>v.sku).join(' ')}`.toLowerCase();
    const totalStock=variants.reduce((a,v)=>a+Number(v.stock||0),0);
    if(q && !txt.includes(q))return false;
    if(productViewState.status==='active'&&!p.active)return false;
    if(productViewState.status==='inactive'&&p.active)return false;
    if(productViewState.status==='low'&&!variants.some(v=>Number(v.stock||0)>0&&Number(v.stock||0)<=3))return false;
    if(productViewState.status==='out'&&totalStock>0)return false;
    if(productViewState.brand!=='all' && ![entityId(p.brand),entityName(p.brand)].includes(productViewState.brand))return false;
    if(productViewState.category!=='all' && ![entityId(p.category),String(p.categoryId||'')].includes(productViewState.category))return false;
    return true;
  }
  function sortProducts(rows){
    const out=[...rows];
    if(productViewState.sort==='name')out.sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'fa'));
    if(productViewState.sort==='stock')out.sort((a,b)=>(b.variants||[]).reduce((s,v)=>s+Number(v.stock||0),0)-(a.variants||[]).reduce((s,v)=>s+Number(v.stock||0),0));
    if(productViewState.sort==='price')out.sort((a,b)=>Math.min(...(a.variants||[{price:a.price||0}]).map(v=>Number(v.price||0)))-Math.min(...(b.variants||[{price:b.price||0}]).map(v=>Number(v.price||0))));
    return out;
  }
  function productFiltersHtml(){
    const c=cache.catalog||{brands:[],categories:[]};
    return `<div class="toolbar catalog-toolbar"><input class="search" id="product-q" value="${esc(productViewState.search)}" placeholder="جستجوی نام یا SKU"><select class="select" id="product-state"><option value="all">همه وضعیت‌ها</option><option value="active">فعال</option><option value="inactive">غیرفعال</option><option value="low">کم‌موجود</option><option value="out">ناموجود</option></select><select class="select" id="product-brand"><option value="all">همه برندها</option>${c.brands.map(x=>`<option value="${esc(entityId(x))}">${esc(entityName(x))}</option>`).join('')}</select><select class="select" id="product-category"><option value="all">همه دسته‌ها</option>${c.categories.map(x=>`<option value="${esc(entityId(x))}">${esc(entityName(x))}</option>`).join('')}</select><select class="select" id="product-sort"><option value="newest">جدیدترین</option><option value="name">نام</option><option value="stock">موجودی</option><option value="price">قیمت</option></select></div>`;
  }
  function renderProducts(rows,meta=null){
    const createAction=can(P.PRODUCTS_CREATE)?`<button class="btn primary small" id="new-product">＋ محصول</button>`:'';
    $('#content').innerHTML=head('محصولات','کاتالوگ، واریانت، تصویر، قیمت و وضعیت',createAction)+productFiltersHtml()+`<div class="list" id="products-list"></div><div id="products-pagination"></div>`;
    $('#product-state').value=productViewState.status;$('#product-brand').value=productViewState.brand;$('#product-category').value=productViewState.category;$('#product-sort').value=productViewState.sort;
    const serverPaged=!!meta;
    let filtered=sortProducts(rows.filter(productMatches));
    if(!serverPaged){const from=(productViewState.page-1)*productViewState.limit;filtered=filtered.slice(from,from+productViewState.limit)}
    $('#products-list').innerHTML=filtered.length?filtered.map(productCard).join(''):`<div class="empty">محصولی پیدا نشد.</div>`;
    const totalPages=Number(meta?.totalPages||meta?.pages||(!serverPaged?Math.max(1,Math.ceil(rows.filter(productMatches).length/productViewState.limit)):1));
    renderPager($('#products-pagination'),productViewState.page,totalPages,p=>{productViewState.page=p;loadProducts(true)});
    $$('[data-product-view]').forEach(b=>b.addEventListener('click',()=>openProductById(b.dataset.productView,false)));
    $$('[data-edit-product]').forEach(b=>b.addEventListener('click',()=>openProductById(b.dataset.editProduct,true)));
    let t;$('#product-q').addEventListener('input',e=>{clearTimeout(t);t=setTimeout(()=>{productViewState.search=e.target.value.trim();productViewState.page=1;loadProducts(true)},350)});
    [['product-state','status'],['product-brand','brand'],['product-category','category'],['product-sort','sort']].forEach(([id,k])=>$('#'+id).addEventListener('change',e=>{productViewState[k]=e.target.value;productViewState.page=1;loadProducts(true)}));
    $('#new-product')?.addEventListener('click',openCreateProduct);
  }
  function renderPager(host,current,total,onPage){
    if(!host||total<=1){if(host)host.innerHTML='';return}
    host.innerHTML=`<div class="pager"><button class="btn small ghost" id="page-prev" ${current<=1?'disabled':''}>قبلی</button><span>صفحه ${fa(current)} از ${fa(total)}</span><button class="btn small ghost" id="page-next" ${current>=total?'disabled':''}>بعدی</button></div>`;
    $('#page-prev')?.addEventListener('click',()=>onPage(current-1));$('#page-next')?.addEventListener('click',()=>onPage(current+1));
  }
  function productImages(p){return Array.isArray(p.images)?p.images:Array.isArray(p.gallery)?p.gallery:[]}
  function imageRef(img){return String(img?.id??img?.serverId??img?._id??img?.url??'')}
  function imageUrl(img){return absoluteAssetUrl(typeof img==='string'?img:(img?.url||img?.src||img?.path||''))}
  function productCard(p){
    const variants=p.variants||[],stock=variants.reduce((s,v)=>s+Number(v.stock||0),0),prices=variants.map(v=>Number(v.price||0)).filter(Number.isFinite),min=prices.length?Math.min(...prices):Number(p.price||0),img=productImages(p)[0],pid=productId(p);
    return `<article class="item product-item"><div class="product-row">${imageUrl(img)?`<img class="product-thumb" src="${esc(imageUrl(img))}" alt="">`:`<div class="product-thumb placeholder">▦</div>`}<div class="product-grow"><div class="item-top"><div><h3>${esc(p.name)}</h3><div class="item-meta"><span>${esc(entityName(p.brand)||'Trust')}</span><span>${fa(variants.length)} واریانت</span><span>موجودی ${fa(stock)}</span>${entityName(p.category)?`<span>${esc(entityName(p.category))}</span>`:''}</div></div><span class="badge ${p.active?'ok':'danger'}">${p.active?'فعال':'غیرفعال'}</span></div><div class="item-actions"><span class="money">${money(min)}</span><button class="btn small ghost" data-product-view="${esc(pid)}">جزئیات</button>${can(P.PRODUCTS_UPDATE)?`<button class="btn small" data-edit-product="${esc(pid)}">ویرایش</button>`:''}</div></div></div></article>`;
  }
  async function openProductById(id,edit=false){
    let p=cache.products.find(x=>productId(x)===String(id));
    try{p=await api.product(id)}catch(e){if(!endpointMissing(e))return toast(errorFa(e.code||e.message),'error')}
    if(!p)return toast('محصول پیدا نشد.','error');
    openProduct(p,edit);
  }
  function catalogSelect(kind,current=''){
    const rows=cache.catalog?.[kind]||[];
    return `<option value="">—</option>${rows.map(x=>`<option value="${esc(entityId(x))}" ${String(current)===entityId(x)?'selected':''}>${esc(entityName(x))}</option>`).join('')}`;
  }
  function productGallery(p,editable){
    const imgs=productImages(p),pid=productId(p);
    return `<div class="gallery">${imgs.length?imgs.map((img,i)=>`<div class="gallery-item"><img src="${esc(imageUrl(img))}" alt=""><div class="gallery-actions">${editable?`<button type="button" class="mini-btn" data-main-image="${esc(imageRef(img))}" title="تصویر اصلی">★</button><button type="button" class="mini-btn danger-text" data-delete-image="${esc(imageRef(img))}" title="حذف">×</button>`:''}</div>${(img.isMain||img.main||i===0)?'<span class="main-image-tag">اصلی</span>':''}</div>`).join(''):'<div class="empty compact">هنوز تصویری ثبت نشده است.</div>'}</div>${editable?`<label class="upload-box"><input id="product-image-file" type="file" accept="image/*" hidden><span>＋ افزودن تصویر</span></label>`:''}`;
  }
  function openProduct(p,edit=false){
    const editable=edit&&can(P.PRODUCTS_UPDATE),pid=productId(p),brandCurrent=entityId(p.brand)||String(p.brandId||''),catCurrent=entityId(p.category)||String(p.categoryId||'');
    if(edit&&!requirePermission(P.PRODUCTS_UPDATE))return;
    openModal(editable?'ویرایش محصول':'جزئیات محصول',`<div class="product-detail-head">${productGallery(p,editable)}</div><form id="edit-product-form"><label class="field"><span>نام محصول</span><input id="ep-name" value="${esc(p.name)}" ${editable?'':'disabled'} required></label><div class="grid2"><label class="field"><span>Slug</span><input id="ep-slug" dir="ltr" value="${esc(p.slug||'')}" ${editable?'':'disabled'}></label><label class="field"><span>برند</span><select id="ep-brand" ${editable?'':'disabled'}>${catalogSelect('brands',brandCurrent)}</select></label><label class="field"><span>دسته‌بندی</span><select id="ep-category" ${editable?'':'disabled'}>${catalogSelect('categories',catCurrent)}</select></label><label class="field"><span>فعال</span><select id="ep-active" ${editable?'':'disabled'}><option value="1" ${p.active?'selected':''}>بله</option><option value="0" ${!p.active?'selected':''}>خیر</option></select></label><label class="field"><span>محصول جدید</span><select id="ep-new" ${editable?'':'disabled'}><option value="1" ${p.isNew?'selected':''}>بله</option><option value="0" ${!p.isNew?'selected':''}>خیر</option></select></label></div><label class="field"><span>توضیح کوتاه</span><textarea id="ep-short" ${editable?'':'disabled'}>${esc(p.shortDescription||'')}</textarea></label>${editable?`<button class="btn primary full">ذخیره اطلاعات محصول</button>`:''}</form><div class="divider"></div><div class="section-title"><h3>واریانت‌ها</h3>${can(P.VARIANTS_CREATE)&&editable?`<button type="button" class="btn small" id="add-variant">＋ واریانت</button>`:''}</div>${(p.variants||[]).map(v=>variantForm(v,pid,editable)).join('')||'<div class="empty compact">واریانتی ندارد.</div>'}${editable&&can(P.PRODUCTS_DELETE)?`<div class="danger-zone"><b>آرشیو محصول</b><p>اگر حذف مستقیم در بک‌اند فعال نباشد، محصول غیرفعال و آرشیو می‌شود.</p><button type="button" class="btn danger" id="archive-product">آرشیو / حذف</button></div>`:''}`);
    if(editable){
      $('#edit-product-form').addEventListener('submit',async e=>{e.preventDefault();const bid=$('#ep-brand').value,cid=$('#ep-category').value,bobj=(cache.catalog?.brands||[]).find(x=>entityId(x)===bid);const data={name:$('#ep-name').value.trim(),slug:$('#ep-slug').value.trim()||undefined,brand:entityName(bobj)||undefined,brandId:bid||undefined,categoryId:cid||undefined,shortDescription:$('#ep-short').value.trim(),active:$('#ep-active').value==='1',isNew:$('#ep-new').value==='1'};try{await api.updateProduct(pid,data);toast('محصول ذخیره شد.');closeModal();cache.products=[];cache.catalog=null;loadProducts(true)}catch(e){toast(errorFa(e.code||e.message),'error')}});
      bindVariantActions(p,pid);
      $('#add-variant')?.addEventListener('click',()=>openCreateVariant(p));
      $('#archive-product')?.addEventListener('click',async()=>{if(!requirePermission(P.PRODUCTS_DELETE))return;if(!confirm('این محصول آرشیو/حذف شود؟'))return;try{await api.archiveProduct(pid);toast('محصول آرشیو شد.');closeModal();cache.products=[];loadProducts(true)}catch(e){toast(errorFa(e.code||e.message),'error')}});
      $('#product-image-file')?.addEventListener('change',async e=>{const f=e.target.files?.[0];if(!f)return;if(f.size>8*1024*1024)return toast('حجم تصویر باید کمتر از ۸ مگابایت باشد.','error');try{await api.uploadProductImage(pid,f);toast('تصویر اضافه شد.');closeModal();cache.products=[];loadProducts(true)}catch(err){toast(errorFa(err.code||err.message),'error')}});
      $$('[data-delete-image]').forEach(b=>b.addEventListener('click',async()=>{if(!confirm('تصویر حذف شود؟'))return;try{await api.deleteProductImage(pid,b.dataset.deleteImage);toast('تصویر حذف شد.');closeModal();cache.products=[];loadProducts(true)}catch(e){toast(errorFa(e.code||e.message),'error')}}));
      $$('[data-main-image]').forEach(b=>b.addEventListener('click',async()=>{try{await api.setMainProductImage(pid,b.dataset.mainImage);toast('تصویر اصلی تغییر کرد.');closeModal();cache.products=[];loadProducts(true)}catch(e){toast(errorFa(e.code||e.message),'error')}}));
    }
  }
  function variantForm(v,pid,editable){
    const id=variantId(v);return `<div class="variant" data-variant-box="${esc(id)}"><div class="section-title"><h4>${esc(v.label||v.title||'اصلی')}</h4><span class="sku">${esc(v.sku||'—')}</span></div><div class="grid2"><label class="field"><span>SKU</span><input class="v-sku" dir="ltr" value="${esc(v.sku||'')}" ${editable?'':'disabled'}></label><label class="field"><span>عنوان</span><input class="v-title" value="${esc(v.label||v.title||'اصلی')}" ${editable?'':'disabled'}></label><label class="field"><span>قیمت</span><input class="v-price" type="number" min="0" value="${Number(v.price||0)}" ${editable?'':'disabled'}></label><label class="field"><span>قیمت قبلی</span><input class="v-compare" type="number" min="0" value="${v.compareAtPrice??''}" ${editable?'':'disabled'}></label><label class="field"><span>موجودی</span><input class="v-stock" value="${Number(v.stock||0)}" disabled></label><label class="field"><span>وضعیت</span><select class="v-active" ${editable?'':'disabled'}><option value="1" ${v.active?'selected':''}>فعال</option><option value="0" ${!v.active?'selected':''}>غیرفعال</option></select></label></div>${editable?`<div class="item-actions"><button type="button" class="btn small" data-save-variant="${esc(id)}">ذخیره واریانت</button>${can(P.INVENTORY_UPDATE)?`<button type="button" class="btn small ghost" data-adjust-variant="${esc(id)}">اصلاح موجودی</button>`:''}${can(P.VARIANTS_DELETE)?`<button type="button" class="btn small danger" data-delete-variant="${esc(id)}">حذف</button>`:''}</div>`:''}</div>`;
  }
  function bindVariantActions(p,pid){
    $$('[data-save-variant]').forEach(b=>b.addEventListener('click',async()=>{const id=b.dataset.saveVariant,box=$$('[data-variant-box]').find(x=>x.dataset.variantBox===id),sku=$('.v-sku',box).value.trim();if(!await skuAvailable(sku,id))return toast('این SKU قبلاً استفاده شده است.','error');try{await api.updateVariant(id,{sku,title:$('.v-title',box).value.trim()||'اصلی',price:Number($('.v-price',box).value),compareAtPrice:$('.v-compare',box).value?Number($('.v-compare',box).value):null,active:$('.v-active',box).value==='1'});toast('واریانت ذخیره شد.');cache.products=[]}catch(e){toast(errorFa(e.code||e.message),'error')}}));
    $$('[data-adjust-variant]').forEach(b=>b.addEventListener('click',()=>{const v=(p.variants||[]).find(x=>variantId(x)===b.dataset.adjustVariant);if(v)openInventoryAdjust(v,p)}));
    $$('[data-delete-variant]').forEach(b=>b.addEventListener('click',async()=>{if(!confirm('این واریانت حذف شود؟'))return;try{await api.deleteVariant(pid,b.dataset.deleteVariant);toast('واریانت حذف شد.');closeModal();cache.products=[];loadProducts(true)}catch(e){toast(errorFa(e.code||e.message),'error')}}));
  }
  async function skuAvailable(sku,excludeId=''){
    if(!sku)return false;
    const remote=await api.validateSku(sku,excludeId);if(remote!==null){if(typeof remote==='boolean')return remote; if('available' in remote)return !!remote.available; if('exists' in remote)return !remote.exists}
    return !cache.products.some(p=>(p.variants||[]).some(v=>String(v.sku||'').toLowerCase()===sku.toLowerCase()&&variantId(v)!==String(excludeId)));
  }
  function openCreateVariant(p){
    if(!requirePermission(P.VARIANTS_CREATE))return;const pid=productId(p);
    openModal('واریانت جدید',`<form id="create-variant-form"><div class="grid2"><label class="field"><span>SKU</span><input id="nv-sku" dir="ltr" required></label><label class="field"><span>عنوان</span><input id="nv-title" value="اصلی" required></label><label class="field"><span>قیمت</span><input id="nv-price" type="number" min="0" required></label><label class="field"><span>قیمت قبلی</span><input id="nv-compare" type="number" min="0"></label><label class="field"><span>موجودی اولیه</span><input id="nv-stock" type="number" min="0" value="0"></label><label class="field"><span>فعال</span><select id="nv-active"><option value="1">بله</option><option value="0">خیر</option></select></label></div><button class="btn primary full">ساخت واریانت</button></form>`);
    $('#create-variant-form').addEventListener('submit',async e=>{e.preventDefault();const sku=$('#nv-sku').value.trim();if(!await skuAvailable(sku))return toast('این SKU قبلاً استفاده شده است.','error');const data={sku,title:$('#nv-title').value.trim()||'اصلی',price:Number($('#nv-price').value),compareAtPrice:$('#nv-compare').value?Number($('#nv-compare').value):null,stock:Number($('#nv-stock').value||0),active:$('#nv-active').value==='1'};try{await api.createVariant(pid,data);toast('واریانت ساخته شد.');closeModal();cache.products=[];loadProducts(true)}catch(e){toast(errorFa(e.code||e.message),'error')}});
  }
  async function openCreateProduct(){
    if(!requirePermission(P.PRODUCTS_CREATE))return;await ensureCatalog();
    openModal('محصول جدید',`<form id="create-product-form"><label class="field"><span>نام محصول</span><input id="cp-name" required></label><label class="field"><span>Slug انگلیسی</span><input id="cp-slug" dir="ltr" required placeholder="trust-product"></label><div class="grid2"><label class="field"><span>برند</span><select id="cp-brand">${catalogSelect('brands','')}</select></label><label class="field"><span>دسته‌بندی</span><select id="cp-category">${catalogSelect('categories','')}</select></label><label class="field"><span>SKU</span><input id="cp-sku" dir="ltr" required></label><label class="field"><span>عنوان واریانت</span><input id="cp-variant" value="اصلی"></label><label class="field"><span>قیمت</span><input id="cp-price" type="number" min="0" required></label><label class="field"><span>قیمت قبلی</span><input id="cp-compare" type="number" min="0"></label><label class="field"><span>موجودی اولیه</span><input id="cp-stock" type="number" min="0" value="0"></label></div><label class="field"><span>توضیح کوتاه</span><textarea id="cp-short"></textarea></label><button class="btn primary full">ساخت محصول</button></form>`);
    $('#create-product-form').addEventListener('submit',async e=>{e.preventDefault();const sku=$('#cp-sku').value.trim();if(!await skuAvailable(sku))return toast('این SKU قبلاً استفاده شده است.','error');const bid=$('#cp-brand').value,bobj=(cache.catalog?.brands||[]).find(x=>entityId(x)===bid),data={name:$('#cp-name').value.trim(),slug:$('#cp-slug').value.trim(),brand:entityName(bobj)||'Trust',brandId:bid||undefined,categoryId:$('#cp-category').value||undefined,shortDescription:$('#cp-short').value.trim(),active:true,variants:[{sku,title:$('#cp-variant').value.trim()||'اصلی',price:Number($('#cp-price').value),stock:Number($('#cp-stock').value||0),active:true}]};if($('#cp-compare').value)data.variants[0].compareAtPrice=Number($('#cp-compare').value);try{await api.createProduct(data);toast('محصول ساخته شد.');closeModal();cache.products=[];cache.catalog=null;loadProducts(true)}catch(e){toast(errorFa(e.code||e.message),'error')}});
  }

  async function loadCatalog(force=false){
    loading('کاتالوگ');try{const c=await ensureCatalog(force);renderCatalog(c)}catch(e){pageError(e)}
  }
  function renderCatalog(c){
    const manage=can(P.CATALOG_MANAGE);
    $('#content').innerHTML=head('کاتالوگ','دسته‌بندی‌ها، برندها و ویژگی‌های محصول')+`<div class="catalog-sections">${catalogSection('categories','دسته‌بندی‌ها',c.categories,manage)}${catalogSection('brands','برندها',c.brands,manage)}${catalogSection('attributes','ویژگی‌ها',c.attributes,manage)}</div>`;
    $$('[data-catalog-add]').forEach(b=>b.addEventListener('click',()=>openCatalogEntity(b.dataset.catalogAdd,null)));
    $$('[data-catalog-edit]').forEach(b=>b.addEventListener('click',()=>{const kind=b.dataset.catalogEdit,row=(c[kind]||[]).find(x=>entityId(x)===b.dataset.id);openCatalogEntity(kind,row)}));
    $$('[data-catalog-delete]').forEach(b=>b.addEventListener('click',()=>deleteCatalogEntity(b.dataset.catalogDelete,b.dataset.id)));
  }
  function catalogSection(kind,title,rows,manage){return `<section class="panel catalog-panel"><div class="section-title"><h2>${title}</h2>${manage?`<button class="btn small" data-catalog-add="${kind}">＋ افزودن</button>`:''}</div><div class="chip-list">${rows.length?rows.map(x=>`<div class="catalog-chip"><span>${esc(entityName(x))}</span>${manage?`<span><button class="mini-btn" data-catalog-edit="${kind}" data-id="${esc(entityId(x))}">✎</button><button class="mini-btn danger-text" data-catalog-delete="${kind}" data-id="${esc(entityId(x))}">×</button></span>`:''}</div>`).join(''):'<div class="empty compact">موردی ثبت نشده است.</div>'}</div></section>`}
  function openCatalogEntity(kind,row){
    if(!requirePermission(P.CATALOG_MANAGE))return;const singular={categories:'دسته‌بندی',brands:'برند',attributes:'ویژگی'}[kind]||'مورد';
    openModal(`${row?'ویرایش':'افزودن'} ${singular}`,`<form id="catalog-entity-form"><label class="field"><span>نام</span><input id="ce-name" value="${esc(entityName(row)||'')}" required></label><label class="field"><span>Slug / Key</span><input id="ce-slug" dir="ltr" value="${esc(row?.slug||row?.key||'')}"></label>${kind==='attributes'?`<label class="field"><span>مقادیر (با کاما جدا کنید)</span><input id="ce-values" value="${esc((row?.values||[]).map(entityName).join(', '))}"></label>`:''}<button class="btn primary full">ذخیره</button></form>`);
    $('#catalog-entity-form').addEventListener('submit',async e=>{e.preventDefault();const data={name:$('#ce-name').value.trim(),slug:$('#ce-slug').value.trim()||undefined};if(kind==='attributes')data.values=$('#ce-values').value.split(',').map(x=>x.trim()).filter(Boolean);try{const id=entityId(row);if(kind==='categories')await(id?api.updateCategory(id,data):api.createCategory(data));if(kind==='brands')await(id?api.updateBrand(id,data):api.createBrand(data));if(kind==='attributes')await(id?api.updateAttribute(id,data):api.createAttribute(data));toast(`${singular} ذخیره شد.`);closeModal();cache.catalog=null;loadCatalog(true)}catch(e){toast(errorFa(e.code||e.message),'error')}});
  }
  async function deleteCatalogEntity(kind,id){
    if(!requirePermission(P.CATALOG_MANAGE))return;if(!confirm('این مورد حذف شود؟'))return;try{if(kind==='categories')await api.deleteCategory(id);if(kind==='brands')await api.deleteBrand(id);if(kind==='attributes')await api.deleteAttribute(id);toast('حذف شد.');cache.catalog=null;loadCatalog(true)}catch(e){toast(errorFa(e.code||e.message),'error')}
  }

  function deriveInventory(products=[]){
    const rows=[];products.forEach(p=>(p.variants||[]).forEach(v=>rows.push({id:variantId(v),variantId:variantId(v),productId:productId(p),productName:p.name,sku:v.sku,label:v.label||v.title||'اصلی',stock:Number(v.stock||0),active:v.active!==false,updatedAt:v.updatedAt||p.updatedAt,product:p,variant:v})));return rows;
  }
  async function loadInventory(force=false){
    loading('موجودی');try{
      let remote=await api.inventory({search:inventoryViewState.search,status:inventoryViewState.status});
      if(remote!==null){cache.inventory=listPayload(remote,['inventory']).items.map(x=>({...x,id:String(x.variantId||x.id||''),stock:Number(x.stock??x.quantity??0)}))}
      else {if(force||!cache.products.length){const r=await api.products({limit:500});cache.products=listPayload(r,['products']).items}cache.inventory=deriveInventory(cache.products)}
      renderInventory(cache.inventory);
    }catch(e){pageError(e)}
  }
  function inventoryStatus(stock){return stock<=0?'out':stock<=3?'low':'ok'}
  function renderInventory(rows){
    const total=rows.reduce((s,x)=>s+Number(x.stock||0),0),low=rows.filter(x=>inventoryStatus(Number(x.stock||0))==='low').length,out=rows.filter(x=>Number(x.stock||0)<=0).length;
    $('#content').innerHTML=head('موجودی','کنترل موجودی و تاریخچه تغییرات')+`<div class="cards inventory-metrics"><div class="metric"><span>کل واحد موجود</span><b>${fa(total)}</b></div><div class="metric"><span>واریانت‌ها</span><b>${fa(rows.length)}</b></div><div class="metric"><span>کم‌موجود</span><b>${fa(low)}</b></div><div class="metric"><span>ناموجود</span><b>${fa(out)}</b></div></div><div class="toolbar"><input class="search" id="inventory-q" value="${esc(inventoryViewState.search)}" placeholder="نام محصول یا SKU"><select class="select" id="inventory-state"><option value="all">همه</option><option value="ok">موجود</option><option value="low">کم‌موجود</option><option value="out">ناموجود</option></select></div><div class="list" id="inventory-list"></div>`;
    $('#inventory-state').value=inventoryViewState.status;
    const draw=()=>{const q=$('#inventory-q').value.trim().toLowerCase(),st=$('#inventory-state').value,f=rows.filter(x=>(!q||`${x.productName||x.product?.name||''} ${x.sku||''}`.toLowerCase().includes(q))&&(st==='all'||inventoryStatus(Number(x.stock||0))===st));$('#inventory-list').innerHTML=f.length?f.map(inventoryCard).join(''):'<div class="empty">رکوردی پیدا نشد.</div>';$$('[data-inventory-adjust]').forEach(b=>b.addEventListener('click',()=>{const x=rows.find(r=>String(r.variantId||r.id)===b.dataset.inventoryAdjust);if(x)openInventoryAdjust(x.variant||x,x.product||{name:x.productName,serverId:x.productId})}));$$('[data-inventory-history]').forEach(b=>b.addEventListener('click',()=>openInventoryHistory(b.dataset.inventoryHistory,rows.find(r=>String(r.variantId||r.id)===b.dataset.inventoryHistory))));};
    $('#inventory-q').addEventListener('input',draw);$('#inventory-state').addEventListener('change',draw);draw();
  }
  function inventoryCard(x){const st=inventoryStatus(Number(x.stock||0)),id=String(x.variantId||x.id||'');return `<article class="item"><div class="item-top"><div><h3>${esc(x.productName||x.product?.name||'محصول')}</h3><div class="item-meta"><span>${esc(x.sku||'—')}</span><span>${esc(x.label||x.variant?.label||x.variant?.title||'اصلی')}</span>${x.updatedAt?`<span>${dateFa(x.updatedAt)}</span>`:''}</div></div><span class="stock-pill ${st}">${fa(x.stock)}</span></div><div class="item-actions">${can(P.INVENTORY_UPDATE)?`<button class="btn small" data-inventory-adjust="${esc(id)}">اصلاح موجودی</button>`:''}<button class="btn small ghost" data-inventory-history="${esc(id)}">تاریخچه</button></div></article>`}
  function openInventoryAdjust(v,p){
    if(!requirePermission(P.INVENTORY_UPDATE))return;const id=variantId(v)||String(v.id||''),current=Number(v.stock??v.quantity??0);
    openModal('اصلاح موجودی',`<div class="notice">${esc(p?.name||'محصول')} · ${esc(v.sku||'—')} · موجودی فعلی: ${fa(current)}</div><form id="inventory-adjust-form" style="margin-top:12px"><label class="field"><span>نوع تغییر</span><select id="ia-type"><option value="increase">افزایش</option><option value="decrease">کاهش</option><option value="set">تنظیم عدد نهایی</option></select></label><label class="field"><span>تعداد</span><input id="ia-qty" type="number" min="0" required></label><label class="field"><span>علت</span><textarea id="ia-reason" placeholder="مثلاً ورود بار جدید، اصلاح شمارش، خرابی کالا" required></textarea></label><div id="ia-preview" class="notice"></div><button class="btn primary full" style="margin-top:10px">ثبت تغییر موجودی</button></form>`);
    const preview=()=>{const type=$('#ia-type').value,n=Math.max(0,Number($('#ia-qty').value||0)),next=type==='set'?n:type==='decrease'?Math.max(0,current-n):current+n;$('#ia-preview').textContent=`موجودی بعد از ثبت: ${fa(next)}`;return next};$('#ia-type').addEventListener('change',preview);$('#ia-qty').addEventListener('input',preview);preview();
    $('#inventory-adjust-form').addEventListener('submit',async e=>{e.preventDefault();const type=$('#ia-type').value,n=Math.max(0,Number($('#ia-qty').value||0)),reason=$('#ia-reason').value.trim();if(!reason)return toast('علت تغییر موجودی را بنویسید.','error');const next=preview(),delta=next-current;try{await api.adjustInventory(id,{type,quantity:n,delta,absoluteQuantity:next,reason},current);toast('موجودی به‌روزرسانی شد.');closeModal();cache.inventory=[];cache.products=[];if(page==='inventory')loadInventory(true);else loadProducts(true)}catch(e){toast(errorFa(e.code||e.message),'error')}});
  }
  async function openInventoryHistory(id,row){
    openModal('تاریخچه موجودی','<div class="loading"><div class="spinner"></div><span>در حال دریافت…</span></div>');try{const payload=await api.inventoryHistory(id);if(payload===null){$('#modal-root .modal').innerHTML=`<div class="modal-head"><h2>تاریخچه موجودی</h2><button class="modal-close" id="modal-close">×</button></div><div class="notice warn">Endpoint تاریخچه موجودی در بک‌اند فعال نیست. تغییر موجودی همچنان از مسیر امن Adjustment انجام می‌شود.</div>`;$('#modal-close').addEventListener('click',closeModal);return}const rows=listPayload(payload,['history','transactions']).items;$('#modal-root .modal').innerHTML=`<div class="modal-head"><h2>تاریخچه موجودی</h2><button class="modal-close" id="modal-close">×</button></div><div class="panel"><div class="subtle" style="margin-bottom:10px">${esc(row?.productName||'')} · ${esc(row?.sku||'')}</div>${rows.length?rows.map(h=>`<div class="audit-item"><b>${Number(h.quantity??h.delta??0)>0?'+':''}${fa(h.quantity??h.delta??0)} · ${esc(h.reason||h.type||'تغییر موجودی')}</b><small>${dateFa(h.createdAt||h.date)}${h.adminUser?.displayName?` · ${esc(h.adminUser.displayName)}`:''}</small></div>`).join(''):'<div class="empty compact">تاریخچه‌ای ثبت نشده است.</div>'}</div>`;$('#modal-close').addEventListener('click',closeModal)}catch(e){toast(errorFa(e.code||e.message),'error');closeModal()}
  }

  async function loadOrders(force=false){loading('سفارش‌ها');try{if(force||!cache.orders.length)cache.orders=await api.orders();renderOrders(cache.orders)}catch(e){pageError(e)}}
  function renderOrders(rows){$('#content').innerHTML=head('سفارش‌ها','پیگیری و تغییر وضعیت سفارش')+`<div class="toolbar"><input class="search" id="order-q" placeholder="شماره سفارش یا موبایل"><select class="select" id="order-state"><option value="all">همه وضعیت‌ها</option>${['AWAITING_PAYMENT','PAYMENT_REVIEW','PAID','PREPARING','SHIPPED','DELIVERED','CANCELLED','RETURNED'].map(s=>`<option value="${s}">${statusFa[s]}</option>`).join('')}</select></div><div class="list" id="orders-list"></div>`;const draw=()=>{const q=$('#order-q').value.trim(),st=$('#order-state').value;const f=rows.filter(o=>(!q||String(o.orderNumber).includes(q)||(o.user?.mobile||'').includes(q))&&(st==='all'||o.status===st));$('#orders-list').innerHTML=f.length?f.map(orderCard).join(''):'<div class="empty">سفارشی پیدا نشد.</div>';$$('[data-order]').forEach(b=>b.addEventListener('click',()=>openOrder(rows.find(x=>x.id===b.dataset.order))));};$('#order-q').addEventListener('input',draw);$('#order-state').addEventListener('change',draw);draw()}
  function orderCard(o){return `<article class="item"><div class="item-top"><div><h3>سفارش #${fa(o.orderNumber)}</h3><div class="item-meta"><span>${esc(o.user?.mobile||'—')}</span><span>${dateFa(o.createdAt)}</span></div></div>${statusBadge(o.status)}</div><div class="item-actions"><span class="money">${money(o.finalTotal)}</span><button class="btn small" data-order="${esc(o.id)}">جزئیات و اقدام</button></div></article>`;}
  const transitions={DRAFT:['AWAITING_PAYMENT'],AWAITING_PAYMENT:['CANCELLED'],PAYMENT_SUBMITTED:['PAYMENT_REVIEW','CANCELLED'],PAYMENT_REVIEW:['AWAITING_PAYMENT','PAID','CANCELLED'],PAID:['PREPARING','CANCELLED'],PREPARING:['SHIPPED','CANCELLED'],SHIPPED:['DELIVERED'],DELIVERED:['RETURNED'],CANCELLED:[],RETURNED:[]};
  function openOrder(o){const addr=o.addressSnapshot||{},ship=o.shippingSnapshot||{};const opts=can(P.ORDERS_UPDATE)?(transitions[o.status]||[]).map(s=>`<option value="${s}">${statusFa[s]||s}</option>`).join(''):'';openModal(`سفارش #${fa(o.orderNumber)}`,`<div class="kv"><div>وضعیت</div><div>${statusBadge(o.status)}</div><div>مشتری</div><div>${esc([o.user?.firstName,o.user?.lastName].filter(Boolean).join(' ')||'—')} · ${esc(o.user?.mobile||'—')}</div><div>مبلغ نهایی</div><div class="money">${money(o.finalTotal)}</div><div>ثبت</div><div>${dateFa(o.createdAt)}</div><div>گیرنده</div><div>${esc(addr.recipientName||'—')}</div><div>آدرس</div><div>${esc([addr.province,addr.city,addr.addressLine].filter(Boolean).join('، ')||'—')}</div><div>ارسال</div><div>${esc(ship.title||ship.carrier||'—')}</div></div>${opts?`<div class="divider"></div><label class="field"><span>تغییر وضعیت</span><select id="order-next">${opts}</select></label><button class="btn primary full" id="order-update">ثبت وضعیت جدید</button>`:`<div class="notice" style="margin-top:15px">برای وضعیت فعلی اقدام بعدی تعریف نشده است.</div>`}`);$('#order-update')?.addEventListener('click',async()=>{if(!requirePermission(P.ORDERS_UPDATE))return;const next=$('#order-next').value;if(!confirm(`وضعیت به «${statusFa[next]||next}» تغییر کند؟`))return;try{await api.updateOrderStatus(o.id,next);toast('وضعیت سفارش تغییر کرد.');closeModal();cache.orders=[];loadOrders(true)}catch(e){toast(errorFa(e.code||e.message),'error')}})}

  async function loadPayments(force=false){loading('پرداخت‌ها');try{if(force||!cache.payments.length)cache.payments=await api.payments();renderPayments(cache.payments)}catch(e){pageError(e)}}
  function renderPayments(rows){$('#content').innerHTML=head('پرداخت‌ها','بررسی رسیدهای کارت‌به‌کارت')+`<div class="toolbar"><select class="select" id="pay-state"><option value="all">همه</option><option value="REVIEW">نیازمند بررسی</option><option value="APPROVED">تأیید شده</option><option value="NEEDS_RESUBMISSION">ارسال مجدد</option><option value="REJECTED">رد شده</option></select></div><div class="list" id="payments-list"></div>`;const draw=()=>{const st=$('#pay-state').value,f=rows.filter(p=>st==='all'||p.status===st);$('#payments-list').innerHTML=f.length?f.map(paymentCard).join(''):'<div class="empty">پرداختی وجود ندارد.</div>';$$('[data-payment]').forEach(b=>b.addEventListener('click',()=>openPayment(rows.find(x=>x.id===b.dataset.payment))));};$('#pay-state').addEventListener('change',draw);draw()}
  function paymentCard(p){return `<article class="item"><div class="item-top"><div><h3>سفارش #${fa(p.order?.orderNumber)}</h3><div class="item-meta"><span>${esc(p.order?.user?.mobile||'—')}</span><span>${dateFa(p.submittedAt||p.createdAt)}</span></div></div>${statusBadge(p.status)}</div><div class="item-actions"><span class="money">${money(p.amount)}</span><button class="btn small" data-payment="${esc(p.id)}">بررسی</button></div></article>`;}
  function openPayment(p){openModal(`پرداخت سفارش #${fa(p.order?.orderNumber)}`,`<div class="kv"><div>وضعیت</div><div>${statusBadge(p.status)}</div><div>مبلغ</div><div class="money">${money(p.amount)}</div><div>شماره پیگیری</div><div>${esc(p.referenceNumber||'—')}</div><div>ثبت رسید</div><div>${dateFa(p.submittedAt)}</div>${p.rejectReason?`<div>علت رد</div><div>${esc(p.rejectReason)}</div>`:''}</div><div class="divider"></div><div class="item-actions"><button class="btn ghost" id="receipt">مشاهده رسید</button>${p.status==='REVIEW'&&can(P.PAYMENTS_REVIEW)?`<button class="btn primary" id="approve">تأیید پرداخت</button><button class="btn danger" id="reject">رد / ارسال مجدد</button>`:''}</div>`);$('#receipt').addEventListener('click',async()=>{try{const r=await api.receiptUrl(p.id);openUrl(r.url)}catch(e){toast(errorFa(e.code||e.message),'error')}});$('#approve')?.addEventListener('click',async()=>{if(!requirePermission(P.PAYMENTS_REVIEW))return;if(!confirm('پرداخت تأیید شود؟ این کار موجودی را قطعی کم می‌کند.'))return;try{await api.approvePayment(p.id);toast('پرداخت تأیید شد.');closeModal();cache.payments=[];cache.orders=[];loadPayments(true)}catch(e){toast(errorFa(e.code||e.message),'error')}});$('#reject')?.addEventListener('click',()=>{if(requirePermission(P.PAYMENTS_REVIEW))rejectPaymentModal(p)})}
  function rejectPaymentModal(p){openModal('رد پرداخت',`<p class="subtle">علت را برای مشتری بنویسید. سفارش دوباره در انتظار پرداخت قرار می‌گیرد.</p><label class="field"><span>علت رد</span><textarea id="reject-reason" placeholder="مثلاً تصویر رسید خوانا نیست"></textarea></label><button class="btn danger full" id="reject-submit">ثبت و درخواست ارسال مجدد</button>`);$('#reject-submit').addEventListener('click',async()=>{const reason=$('#reject-reason').value.trim();if(reason.length<3)return toast('علت رد را وارد کنید.','error');try{await api.rejectPayment(p.id,reason);toast('پرداخت رد شد.');closeModal();cache.payments=[];cache.orders=[];loadPayments(true)}catch(e){toast(errorFa(e.code||e.message),'error')}})}

  async function loadCustomers(force=false){loading('مشتریان');try{if(force||!cache.orders.length)cache.orders=await api.orders();const map=new Map();cache.orders.forEach(o=>{const u=o.user||{};const k=u.id||u.mobile;if(!k)return;const x=map.get(k)||{...u,orders:0,total:0,last:null};x.orders++;if(['PAID','PREPARING','SHIPPED','DELIVERED'].includes(o.status))x.total+=Number(o.finalTotal||0);if(!x.last||new Date(o.createdAt)>new Date(x.last))x.last=o.createdAt;map.set(k,x)});const rows=[...map.values()];$('#content').innerHTML=head('مشتریان','خلاصه مشتریان بر اساس سفارش‌های ثبت‌شده')+`<div class="toolbar"><input class="search" id="customer-q" placeholder="جستجوی موبایل یا نام"></div><div class="list" id="customers-list"></div>`;const draw=()=>{const q=$('#customer-q').value.trim().toLowerCase(),f=rows.filter(u=>`${u.mobile} ${u.firstName||''} ${u.lastName||''}`.toLowerCase().includes(q));$('#customers-list').innerHTML=f.length?f.map(u=>`<article class="item"><div class="item-top"><div><h3>${esc([u.firstName,u.lastName].filter(Boolean).join(' ')||u.mobile)}</h3><div class="item-meta"><span>${esc(u.mobile||'—')}</span><span>${fa(u.orders)} سفارش</span></div></div></div><div class="item-actions"><span class="money">${money(u.total)}</span><span class="subtle">آخرین: ${dateFa(u.last)}</span></div></article>`).join(''):'<div class="empty">مشتری پیدا نشد.</div>'};$('#customer-q').addEventListener('input',draw);draw()}catch(e){pageError(e)}}

  function renderImport(){if(!requireAnyPermission([P.CATALOG_IMPORT,P.PRODUCTS_CREATE]))return forbiddenView('import');page='import';$('#content').innerHTML=head('ورود CSV','ورود گروهی محصولات و موجودی')+`<div class="panel"><h2>فایل CSV</h2><p class="subtle">برای واردکردن گروهی محصولات، CSV با ستون‌های زیر انتخاب کنید. ابتدا «بررسی» و سپس «ثبت نهایی» انجام می‌شود.</p><div class="csv-help">name,slug,sku,variantTitle,price,compareAtPrice,stock,brand</div><div style="height:10px"></div><input id="csv-file" type="file" accept=".csv,text/csv"><div id="csv-info" class="subtle" style="margin-top:10px"></div><div class="item-actions"><button class="btn" id="csv-check" disabled>بررسی فایل</button><button class="btn primary" id="csv-commit" disabled>ثبت نهایی</button></div><pre id="csv-result" class="csv-help hidden"></pre></div>`;let rows=[];$('#csv-file').addEventListener('change',async e=>{const f=e.target.files?.[0];if(!f)return;rows=parseCSV(await f.text());$('#csv-info').textContent=`${fa(rows.length)} ردیف خوانده شد.`;$('#csv-check').disabled=!rows.length;$('#csv-commit').disabled=!rows.length});$('#csv-check').addEventListener('click',async()=>{try{const r=await api.importCatalog(rows,true);showImportResult(r)}catch(e){toast(errorFa(e.code||e.message),'error')}});$('#csv-commit').addEventListener('click',async()=>{if(!confirm(`${rows.length} ردیف در دیتابیس ثبت شود؟`))return;try{const r=await api.importCatalog(rows,false);showImportResult(r);cache.products=[];toast('ورود کاتالوگ انجام شد.')}catch(e){toast(errorFa(e.code||e.message),'error')}})}
  function parseCSV(text){const lines=text.replace(/^\uFEFF/,'').split(/\r?\n/).filter(x=>x.trim());if(lines.length<2)return[];const split=line=>{const out=[];let cur='',q=false;for(let i=0;i<line.length;i++){const c=line[i];if(c==='"'){if(q&&line[i+1]==='"'){cur+='"';i++}else q=!q}else if(c===','&&!q){out.push(cur.trim());cur=''}else cur+=c}out.push(cur.trim());return out};const h=split(lines[0]);return lines.slice(1).map(line=>{const v=split(line),o={};h.forEach((k,i)=>o[k]=v[i]??'');return {name:o.name,slug:o.slug,sku:o.sku,variantTitle:o.variantTitle||'اصلی',price:Number(o.price||0),compareAtPrice:o.compareAtPrice?Number(o.compareAtPrice):undefined,stock:Number(o.stock||0),brand:o.brand||'Trust'}}).filter(r=>r.name&&r.slug&&r.sku)}
  function showImportResult(r){const el=$('#csv-result');el.classList.remove('hidden');el.textContent=JSON.stringify(r,null,2)}

  async function loadAudit(force=false){loading('گزارش عملیات');try{if(force||!cache.audit.length)cache.audit=await api.audit();$('#content').innerHTML=head('گزارش عملیات','آخرین فعالیت‌های مدیریتی')+`<div class="panel">${cache.audit.length?cache.audit.map(a=>`<div class="audit-item"><b>${esc(a.action)} · ${esc(a.entityType)}</b><small>${dateFa(a.createdAt)} · ${esc(a.adminUser?.displayName||a.adminUser?.mobile||'سیستم')}</small></div>`).join(''):'<div class="empty">گزارشی ثبت نشده است.</div>'}</div>`}catch(e){pageError(e)}}

  async function loadAccount(){
    loading('حساب و سیستم');
    let health=null;
    try{me=await api.me()}catch(e){return pageError(e)}
    try{const r=await fetch(HEALTH_URL,{cache:'no-store'});health=r.ok?await r.json():null}catch(_){health=null}
    const permissions=Authz.list(me);
    const role=Authz.roleName(me);
    $('#content').innerHTML=head('حساب و سیستم','وضعیت اتصال، نقش و دسترسی‌های مدیر')+`<div class="panel"><h2>مدیر واردشده</h2><div class="kv"><div>نام</div><div>${esc(me?.displayName||'—')}</div><div>موبایل</div><div>${esc(me?.mobile||'—')}</div><div>نقش</div><div>${esc(role||'—')}${Authz.isSuperAdmin(me)?' · Super Admin':''}</div><div>دسترسی‌ها</div><div>${Authz.isSuperAdmin(me)?'همه دسترسی‌ها':`${fa(permissions.length)} مورد`}</div></div>${permissions.length?`<div class="permission-list">${permissions.map(x=>`<span>${esc(x)}</span>`).join('')}</div>`:''}</div><div class="panel"><h2>وضعیت سرویس</h2><div class="kv"><div>API</div><div class="${health?'health-ok':'health-bad'}">${health?'متصل':'عدم اتصال'}</div><div>Database</div><div>${esc(health?.database||'—')}</div><div>Version</div><div>${esc(health?.version||'—')}</div><div>Admin App</div><div>${esc(APP_VERSION)}</div></div></div><button class="btn danger full" id="logout">خروج از حساب</button>`;
    $('#logout').addEventListener('click',async()=>{if(!confirm('از حساب مدیر خارج شوید؟'))return;try{await api.logout()}catch(_){}setToken('');me=null;cache={dashboard:null,products:[],productMeta:null,catalog:null,inventory:[],inventoryHistory:{},orders:[],payments:[],audit:[]};loginView()})
  }

  function openModal(title, body){modalOpen=true;$('#modal-root').innerHTML=`<div class="modal-wrap" id="modal-wrap"><section class="modal"><div class="modal-head"><h2>${esc(title)}</h2><button class="modal-close" id="modal-close">×</button></div>${body}</section></div>`;$('#modal-close').addEventListener('click',closeModal);$('#modal-wrap').addEventListener('click',e=>{if(e.target.id==='modal-wrap')closeModal()})}
  function closeModal(){modalOpen=false;$('#modal-root').innerHTML=''}
  window.AdminStoreBack=()=>{if(modalOpen){closeModal();return true}if(moreOpen){toggleMore();return true}if(page!=='dashboard'){navigate('dashboard');return true}return false};

  async function init(){loginView();try{me=await api.me();await showShell('dashboard')}catch(_){setToken('');loginView()}}
  init();
})();
