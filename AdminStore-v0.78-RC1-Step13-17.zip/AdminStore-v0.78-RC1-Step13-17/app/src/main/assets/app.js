(() => {
  'use strict';

  const CONFIG = window.AdminStoreConfig || {};
  const nativeValue = (name) => {
    try {
      const value = window.NativeBridge?.[name]?.();
      return typeof value === 'string' && value.trim() ? value.trim() : '';
    } catch (_) { return ''; }
  };
  const API_BASE = (nativeValue('apiBaseUrl') || CONFIG.apiBase || '').replace(/\/+$/, '');
  const HEALTH_URL = nativeValue('healthUrl') || CONFIG.healthUrl || '';
  const APP_VERSION = nativeValue('appVersion') || CONFIG.appVersion || 'dev';
  const API_HOST = (() => { try { return new URL(API_BASE).host; } catch (_) { return API_BASE || 'نامشخص'; } })();
  const TOKEN_KEY = 'adminstore.access';
  let token = sessionStorage.getItem(TOKEN_KEY) || '';
  let me = null;
  let page = 'dashboard';
  let cache = { dashboard:null, products:[], productMeta:null, catalog:null, inventory:[], inventoryHistory:{}, orders:[], payments:[], customers:[], customerMeta:null, marketing:null, admins:[], roles:[], reports:null, settings:null, capabilities:null, audit:[] };
  let moreOpen = false;
  let modalOpen = false;

  const Authz = window.AdminStorePermissions;
  if (!Authz) throw new Error('AdminStorePermissions is required');
  const Contract = window.AdminStoreApiContract;
  if (!Contract) throw new Error('AdminStoreApiContract is required');
  const Runtime = window.AdminStoreApiRuntime;
  if (!Runtime) throw new Error('AdminStoreApiRuntime is required');
  const E = Contract.endpoints;
  const P = Authz.P;
  const can = permission => Authz.has(me, permission);
  const canAny = permissions => Authz.hasAny(me, permissions);
  const canAccessPage = target => Authz.canAccessPage(me, target);
  const requirePermission = (permission, message='برای این عملیات دسترسی کافی ندارید.') => {
    if (can(permission)) return true;
    toast(message, 'error');
    return false;
  };
  const requireAnyPermission = (permissions, message='برای این عملیات دسترسی کافی ندارید.') => {
    if (canAny(permissions)) return true;
    toast(message, 'error');
    return false;
  };

  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const esc = (v='') => String(v).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const fa = n => new Intl.NumberFormat('fa-IR').format(Number(n || 0));
  const money = n => `${fa(n)} تومان`;
  const dateFa = v => v ? new Date(v).toLocaleString('fa-IR') : '—';
  const haptic = () => { try { window.NativeBridge?.haptic(); } catch (_) {} };
  const openUrl = url => { try { if (window.NativeBridge?.openUrl) window.NativeBridge.openUrl(url); else window.open(url, '_blank'); } catch (_) {} };

  const statusFa = {
    DRAFT:'پیش‌نویس', PENDING:'در انتظار تأیید', AWAITING_PAYMENT:'در انتظار پرداخت', PAYMENT_SUBMITTED:'رسید ارسال شده', PAYMENT_REVIEW:'بررسی پرداخت',
    CONFIRMED:'تأیید شده', PAID:'پرداخت شده', PROCESSING:'در حال پردازش', PREPARING:'در حال آماده‌سازی', SHIPPED:'ارسال شده', DELIVERED:'تحویل شده',
    CANCELLED:'لغو شده', RETURNED:'مرجوعی', REFUNDED:'بازپرداخت شده', PARTIALLY_REFUNDED:'بازپرداخت جزئی',
    CREATED:'ایجاد شده', REVIEW:'نیازمند بررسی', PENDING_REVIEW:'نیازمند بررسی', APPROVED:'تأیید شده', REJECTED:'رد شده', NEEDS_RESUBMISSION:'ارسال مجدد رسید', FAILED:'ناموفق',
    ACTIVE:'فعال', INACTIVE:'غیرفعال', BLOCKED:'مسدود', PUBLISHED:'منتشر شده', SCHEDULED:'زمان‌بندی شده', EXPIRED:'منقضی', DISABLED:'غیرفعال'
  };
  const statusClass = s => ['APPROVED','PAID','CONFIRMED','DELIVERED','ACTIVE'].includes(s) ? 'ok' : ['REVIEW','PENDING_REVIEW','PAYMENT_REVIEW','PROCESSING','PREPARING','SHIPPED','NEEDS_RESUBMISSION','PARTIALLY_REFUNDED'].includes(s) ? 'warn' : ['REJECTED','FAILED','CANCELLED','RETURNED','REFUNDED','BLOCKED','INACTIVE'].includes(s) ? 'danger' : '';
  const statusBadge = s => `<span class="badge ${statusClass(s)}">${esc(statusFa[s] || s || '—')}</span>`;

  function toast(msg, type='ok') {
    const el = $('#toast');
    el.textContent = msg;
    el.className = `toast show ${type === 'error' ? 'error' : ''}`;
    clearTimeout(toast._t);
    toast._t = setTimeout(() => el.className = 'toast', 2800);
  }


  function setBusy(button, busy, label='در حال انجام…') {
    if(!button) return;
    if(busy){button.dataset.oldText=button.textContent;button.disabled=true;button.textContent=label;}
    else{button.disabled=false;button.textContent=button.dataset.oldText||button.textContent;delete button.dataset.oldText;}
  }
  async function runBusy(button, fn, label='در حال انجام…') {
    if(button?.disabled) return;
    setBusy(button,true,label);
    try{return await fn();}finally{setBusy(button,false);}
  }
  function networkState(){return navigator.onLine?'online':'offline'}
  function updateNetworkStatus(){const el=$('#network-status');if(!el)return;const online=navigator.onLine;el.className=`network-status ${online?'ok':'bad'}`;el.textContent=online?'آنلاین':'آفلاین'}

  const errorFa = code => ({
    INVALID_ADMIN_CREDENTIALS:'شماره موبایل یا رمز عبور نادرست است.', UNAUTHORIZED_ADMIN:'نشست مدیر منقضی شده است.', REFRESH_REQUIRED:'لطفاً دوباره وارد شوید.',
    SESSION_EXPIRED:'نشست شما منقضی شده است.', FORBIDDEN:'برای این عملیات دسترسی کافی ندارید.', HTTP_403:'برای این عملیات دسترسی کافی ندارید.', VALIDATION_ERROR:'اطلاعات واردشده معتبر نیست.',
    PRODUCT_NOT_FOUND:'محصول پیدا نشد.', VARIANT_NOT_FOUND:'واریانت پیدا نشد.', SKU_EXISTS:'این SKU قبلاً ثبت شده است.', INVENTORY_NOT_FOUND:'رکورد موجودی پیدا نشد.', INVALID_STOCK_ADJUSTMENT:'تغییر موجودی معتبر نیست.', ENDPOINT_NOT_AVAILABLE:'این قابلیت هنوز در بک‌اند فعال نشده است.', ORDER_NOT_FOUND:'سفارش پیدا نشد.', INVALID_ORDER_TRANSITION:'این تغییر وضعیت مجاز نیست.',
    PAYMENT_NOT_FOUND:'پرداخت پیدا نشد.', PAYMENT_NOT_REVIEWABLE:'این پرداخت قابل بررسی نیست.', RECEIPT_NOT_FOUND:'رسید برای این پرداخت ثبت نشده است.', REFUND_NOT_ALLOWED:'بازپرداخت برای این پرداخت مجاز نیست.', REFUND_AMOUNT_INVALID:'مبلغ بازپرداخت معتبر نیست.', CUSTOMER_NOT_FOUND:'مشتری پیدا نشد.', CUSTOMER_UPDATE_NOT_ALLOWED:'ویرایش این مشتری مجاز نیست.', SHIPPING_UPDATE_NOT_ALLOWED:'اطلاعات ارسال در این وضعیت قابل ویرایش نیست.',
    STORAGE_NOT_CONFIGURED:'فضای ذخیره‌سازی رسید هنوز تنظیم نشده است.', STOCK_CHANGED:'موجودی محصول تغییر کرده است.', NETWORK:'اتصال به سرور برقرار نشد.', REQUEST_TIMEOUT:'پاسخ سرور بیش از حد طول کشید. دوباره تلاش کنید.', API_CONFIG:'آدرس API تنظیم نشده است.', COUPON_NOT_FOUND:'کد تخفیف پیدا نشد.', REVIEW_NOT_FOUND:'نظر پیدا نشد.', BANNER_NOT_FOUND:'بنر پیدا نشد.', ADMIN_NOT_FOUND:'مدیر پیدا نشد.', SETTINGS_UPDATE_FAILED:'ذخیره تنظیمات انجام نشد.'
  }[code] || code || 'خطای نامشخص');

  const http = Runtime.createClient({
    baseUrl: API_BASE,
    timeoutMs: Number(CONFIG.requestTimeoutMs || 20000),
    getToken: () => token,
    setToken: value => setToken(value),
    onRefreshAdmin: admin => {
      me = {
        ...(me || {}),
        ...admin,
        permissions: admin.permissions ?? me?.permissions,
        role: admin.role ?? me?.role
      };
    },
    refreshPath: E.auth.refresh,
    noRefreshPaths: [E.auth.login, E.auth.refresh, E.auth.logout]
  });
  const refreshSession = () => http.refreshSession();
  const raw = (path, options={}, retry=true) => http.raw(path, options, retry);

  function setToken(v) { token = v || ''; token ? sessionStorage.setItem(TOKEN_KEY, token) : sessionStorage.removeItem(TOKEN_KEY); }
  const qs = params => {
    const q = new URLSearchParams();
    Object.entries(params || {}).forEach(([k,v]) => { if(v !== undefined && v !== null && v !== '' && v !== 'all') q.set(k, String(v)); });
    const out=q.toString(); return out ? `?${out}` : '';
  };
  const productId = p => String(p?.serverId ?? p?.id ?? p?._id ?? '');
  const variantId = v => String(v?.id ?? v?.serverId ?? v?._id ?? '');
  const endpointMissing = e => [404,405,501].includes(Number(e?.status));
  async function firstAvailable(requests) {
    let last=null;
    for (const fn of requests) {
      try { return await fn(); }
      catch(e) { last=e; if(!endpointMissing(e)) throw e; }
    }
    const e=last || new Error('ENDPOINT_NOT_AVAILABLE'); e.code='ENDPOINT_NOT_AVAILABLE'; throw e;
  }
  async function optionalRequest(requests, fallback=null) {
    try { return await firstAvailable(requests); }
    catch(e) { if(endpointMissing(e) || e.code==='ENDPOINT_NOT_AVAILABLE') return fallback; throw e; }
  }
  async function optionalModuleRequest(requests, fallback=null) {
    try { return await firstAvailable(requests); }
    catch(e) { if(endpointMissing(e) || e.code==='ENDPOINT_NOT_AVAILABLE' || Number(e.status)===403) return fallback; throw e; }
  }
  function listPayload(payload, keys=[]) {
    if(Array.isArray(payload)) return {items:payload, meta:null};
    const root=payload?.data && !Array.isArray(payload.data) && typeof payload.data==='object' ? payload.data : payload;
    const candidates=[Array.isArray(payload?.data)?payload.data:null,root?.items,root?.results,...keys.map(k=>root?.[k]),...keys.map(k=>payload?.[k])];
    const items=candidates.find(Array.isArray) || [];
    return {items, meta:root?.meta || root?.pagination || payload?.meta || payload?.pagination || null};
  }
  function absoluteAssetUrl(url='') {
    if(!url) return '';
    try { return new URL(url, API_BASE.replace(/\/api\/v\d+\/?$/, '/') || location.href).href; } catch(_) { return url; }
  }
  const api = {
    login:(mobile,password)=>raw(E.auth.login,{method:'POST',body:JSON.stringify({mobile,password})}),
    me:()=>raw(E.auth.me), logout:()=>raw(E.auth.logout,{method:'POST'}),
    dashboard:()=>raw(E.dashboard),
    products:(params={})=>raw(E.products.list+qs(params)),
    product:async id=>{const r=await firstAvailable([()=>raw(E.products.detail(id))]);return r?.data && !Array.isArray(r.data) ? r.data : r},
    createProduct:data=>raw(E.products.list,{method:'POST',body:JSON.stringify(data)}),
    updateProduct:(id,data)=>raw(E.products.detail(id),{method:'PATCH',body:JSON.stringify(data)}),
    archiveProduct:id=>firstAvailable([()=>raw(E.products.detail(id),{method:'DELETE'}),()=>raw(E.products.detail(id),{method:'PATCH',body:JSON.stringify({active:false,archived:true})})]),
    updateVariant:(id,data)=>raw(E.products.variantDirect(id),{method:'PATCH',body:JSON.stringify(data)}),
    createVariant:(productId,data)=>firstAvailable([()=>raw(E.products.variants(productId),{method:'POST',body:JSON.stringify(data)}),()=>raw('/admin/variants',{method:'POST',body:JSON.stringify({...data,productId})})]),
    deleteVariant:(productId,id)=>firstAvailable([()=>raw(E.products.variant(productId,id),{method:'DELETE'}),()=>raw(E.products.variantDirect(id),{method:'DELETE'})]),
    validateSku:(sku,excludeId='')=>optionalRequest([()=>raw(E.products.validateSku+qs({sku,excludeId}))],null),
    categories:()=>optionalRequest([()=>raw('/admin/categories')],[]),
    brands:()=>optionalRequest([()=>raw('/admin/brands')],[]),
    attributes:()=>optionalRequest([()=>raw('/admin/attributes')],[]),
    createCategory:data=>firstAvailable([()=>raw('/admin/categories',{method:'POST',body:JSON.stringify(data)})]),
    updateCategory:(id,data)=>raw(`/admin/categories/${id}`,{method:'PATCH',body:JSON.stringify(data)}),
    deleteCategory:id=>raw(`/admin/categories/${id}`,{method:'DELETE'}),
    createBrand:data=>firstAvailable([()=>raw('/admin/brands',{method:'POST',body:JSON.stringify(data)})]),
    updateBrand:(id,data)=>raw(`/admin/brands/${id}`,{method:'PATCH',body:JSON.stringify(data)}),
    deleteBrand:id=>raw(`/admin/brands/${id}`,{method:'DELETE'}),
    createAttribute:data=>firstAvailable([()=>raw('/admin/attributes',{method:'POST',body:JSON.stringify(data)})]),
    updateAttribute:(id,data)=>raw(`/admin/attributes/${id}`,{method:'PATCH',body:JSON.stringify(data)}),
    deleteAttribute:id=>raw(`/admin/attributes/${id}`,{method:'DELETE'}),
    uploadProductImage:(id,file)=>{const fd=new FormData();fd.append('file',file);return firstAvailable([()=>raw(E.products.images(id),{method:'POST',body:fd}),()=>raw(`/admin/products/${id}/image`,{method:'POST',body:fd})])},
    deleteProductImage:(id,imageId)=>firstAvailable([()=>raw(E.products.image(id,imageId),{method:'DELETE'}),()=>raw(`/admin/product-images/${imageId}`,{method:'DELETE'})]),
    setMainProductImage:(id,imageId)=>firstAvailable([()=>raw(E.products.image(id,imageId),{method:'PATCH',body:JSON.stringify({isMain:true})}),()=>raw(`/admin/products/${id}/main-image`,{method:'PATCH',body:JSON.stringify({imageId})})]),
    inventory:(params={})=>optionalRequest([()=>raw(E.inventory.list+qs(params))],null),
    inventoryHistory:id=>optionalRequest([()=>raw(E.inventory.history(id)),()=>raw(`/admin/variants/${id}/inventory-history`)],null),
    adjustInventory:(id,data,currentStock)=>firstAvailable([()=>raw(E.inventory.adjust(id),{method:'POST',body:JSON.stringify(data)}),()=>raw(`/admin/variants/${id}/inventory/adjust`,{method:'POST',body:JSON.stringify(data)}),()=>raw(E.products.variantDirect(id),{method:'PATCH',body:JSON.stringify({stock:Math.max(0,Number(data.absoluteQuantity ?? (Number(currentStock||0)+Number(data.delta||0))))})})]),
    importCatalog:(rows,dryRun)=>raw(E.products.import,{method:'POST',body:JSON.stringify({rows,dryRun})}),
    orders:(params={})=>raw(E.orders.list+qs(params)),
    order:id=>optionalRequest([()=>raw(E.orders.detail(id))],null),
    orderTimeline:id=>optionalRequest([()=>raw(E.orders.timeline(id)),()=>raw(`/admin/orders/${id}/history`)],null),
    updateOrderStatus:(id,status,reason='')=>raw(E.orders.status(id),{method:'PATCH',body:JSON.stringify({status,...(reason?{reason}:{})})}),
    updateShipping:(id,data)=>firstAvailable([()=>raw(E.orders.shipping(id),{method:'PATCH',body:JSON.stringify(data)}),()=>raw(E.orders.shipping(id),{method:'POST',body:JSON.stringify(data)})]),
    cancelOrder:(id,data)=>firstAvailable([()=>raw(E.orders.cancel(id),{method:'POST',body:JSON.stringify(data)}),()=>raw(`/admin/orders/${id}/status`,{method:'PATCH',body:JSON.stringify({status:'CANCELLED',...data})})]),
    payments:(params={})=>raw(E.payments.list+qs(params)),
    payment:id=>optionalRequest([()=>raw(E.payments.detail(id))],null),
    paymentHistory:id=>optionalRequest([()=>raw(E.payments.history(id)),()=>raw(`/admin/payments/${id}/timeline`)],null),
    receiptUrl:id=>raw(E.payments.receiptUrl(id)),
    approvePayment:id=>raw(E.payments.approve(id),{method:'POST'}),
    rejectPayment:(id,reason)=>raw(E.payments.reject(id),{method:'POST',body:JSON.stringify({reason,needsResubmission:false})}),
    requestPaymentResubmission:(id,reason)=>firstAvailable([()=>raw(E.payments.resubmission(id),{method:'POST',body:JSON.stringify({reason})}),()=>raw(`/admin/payments/${id}/reject`,{method:'POST',body:JSON.stringify({reason,needsResubmission:true})})]),
    refundPayment:(id,data)=>firstAvailable([()=>raw(E.payments.refund(id),{method:'POST',body:JSON.stringify(data)}),()=>raw(`/admin/payments/${id}/refunds`,{method:'POST',body:JSON.stringify(data)})]),
    customers:(params={})=>optionalRequest([()=>raw(E.customers.list+qs(params))],null),
    customer:id=>optionalRequest([()=>raw(E.customers.detail(id))],null),
    customerOrders:id=>optionalRequest([()=>raw(E.customers.orders(id))],null),
    customerPayments:id=>optionalRequest([()=>raw(E.customers.payments(id))],null),
    updateCustomerStatus:(id,status)=>firstAvailable([()=>raw(E.customers.status(id),{method:'PATCH',body:JSON.stringify({status})}),()=>raw(`/admin/customers/${id}`,{method:'PATCH',body:JSON.stringify({status})})]),
    addCustomerNote:(id,note)=>optionalRequest([()=>raw(E.customers.notes(id),{method:'POST',body:JSON.stringify({note})}),()=>raw(`/admin/customers/${id}`,{method:'PATCH',body:JSON.stringify({adminNote:note})})],null),

    coupons:(params={})=>optionalModuleRequest([()=>raw('/admin/coupons'+qs(params))],null),
    createCoupon:data=>firstAvailable([()=>raw('/admin/coupons',{method:'POST',body:JSON.stringify(data)})]),
    updateCoupon:(id,data)=>raw(`/admin/coupons/${id}`,{method:'PATCH',body:JSON.stringify(data)}),
    deleteCoupon:id=>raw(`/admin/coupons/${id}`,{method:'DELETE'}),
    reviews:(params={})=>optionalModuleRequest([()=>raw('/admin/reviews'+qs(params))],null),
    updateReviewStatus:(id,status)=>firstAvailable([()=>raw(`/admin/reviews/${id}/status`,{method:'PATCH',body:JSON.stringify({status})}),()=>raw(`/admin/reviews/${id}`,{method:'PATCH',body:JSON.stringify({status})})]),
    deleteReview:id=>raw(`/admin/reviews/${id}`,{method:'DELETE'}),
    banners:(params={})=>optionalModuleRequest([()=>raw('/admin/banners'+qs(params))],null),
    createBanner:data=>raw('/admin/banners',{method:'POST',body:JSON.stringify(data)}),
    updateBanner:(id,data)=>raw(`/admin/banners/${id}`,{method:'PATCH',body:JSON.stringify(data)}),
    deleteBanner:id=>raw(`/admin/banners/${id}`,{method:'DELETE'}),
    campaigns:(params={})=>optionalModuleRequest([()=>raw('/admin/campaigns'+qs(params))],null),
    createCampaign:data=>raw('/admin/campaigns',{method:'POST',body:JSON.stringify(data)}),
    updateCampaign:(id,data)=>raw(`/admin/campaigns/${id}`,{method:'PATCH',body:JSON.stringify(data)}),
    deleteCampaign:id=>raw(`/admin/campaigns/${id}`,{method:'DELETE'}),

    admins:(params={})=>optionalModuleRequest([()=>raw('/admin/admins'+qs(params)),()=>raw('/admin/users/admins'+qs(params))],null),
    createAdmin:data=>firstAvailable([()=>raw('/admin/admins',{method:'POST',body:JSON.stringify(data)}),()=>raw('/admin/users/admins',{method:'POST',body:JSON.stringify(data)})]),
    updateAdmin:(id,data)=>firstAvailable([()=>raw(`/admin/admins/${id}`,{method:'PATCH',body:JSON.stringify(data)}),()=>raw(`/admin/users/admins/${id}`,{method:'PATCH',body:JSON.stringify(data)})]),
    roles:()=>optionalModuleRequest([()=>raw('/admin/roles')],null),
    permissions:()=>optionalModuleRequest([()=>raw('/admin/permissions')],null),
    createRole:data=>raw('/admin/roles',{method:'POST',body:JSON.stringify(data)}),
    updateRole:(id,data)=>raw(`/admin/roles/${id}`,{method:'PATCH',body:JSON.stringify(data)}),
    reports:(params={})=>optionalModuleRequest([()=>raw('/admin/reports/summary'+qs(params)),()=>raw('/admin/reports'+qs(params))],null),
    settings:()=>optionalModuleRequest([()=>raw('/admin/settings'),()=>raw('/admin/store/settings')],null),
    updateSettings:data=>firstAvailable([()=>raw('/admin/settings',{method:'PATCH',body:JSON.stringify(data)}),()=>raw('/admin/store/settings',{method:'PATCH',body:JSON.stringify(data)})]),
    capabilities:()=>optionalModuleRequest([()=>raw('/admin/capabilities'),()=>raw('/admin/features')],null),
    probe:async path=>{try{await raw(path);return {status:'ok'}}catch(e){return {status:e.status===403?'forbidden':endpointMissing(e)?'missing':'error',code:e.code,statusCode:e.status}}},
    audit:(params={})=>raw('/admin/audit-logs'+qs(params))
  };

  function appRoot(html) { $('#app').innerHTML = html; }
  function loginView(error='') {
    appRoot(`<section class="login"><form class="login-card" id="login-form">
      <div class="login-logo">A</div><h1>AdminStore</h1><p>مدیریت ساده و امن فروشگاه Store</p>
      ${error ? `<div class="login-error">${esc(error)}</div>` : ''}
      <label class="field"><span>شماره موبایل مدیر</span><input id="mobile" inputmode="numeric" autocomplete="username" placeholder="09xxxxxxxxx" required></label>
      <label class="field"><span>رمز عبور</span><input id="password" type="password" autocomplete="current-password" required></label>
      <button class="btn primary full" id="login-btn">ورود به مدیریت</button>
      <div class="login-note">اتصال امن: ${esc(API_HOST)}</div>
    </form></section>`);
    $('#login-form').addEventListener('submit', async e => {
      e.preventDefault(); haptic();
      const btn=$('#login-btn'); btn.disabled=true; btn.textContent='در حال ورود…';
      try {
        const r=await api.login($('#mobile').value.trim(), $('#password').value);
        setToken(r.accessToken);
        me = await api.me();
        await showShell('dashboard');
      } catch (e) { loginView(errorFa(e.code || e.message)); }
    });
  }

  function primaryNavItems() {
    return [
      {id:'dashboard', icon:'⌂', label:'خانه', visible:true},
      {id:'products', icon:'▦', label:'محصولات', visible:canAccessPage('products')},
      {id:'orders', icon:'▤', label:'سفارش‌ها', visible:canAccessPage('orders')},
      {id:'payments', icon:'✓', label:'پرداخت', visible:canAccessPage('payments')},
      {id:'more', icon:'☰', label:'بیشتر', visible:true}
    ].filter(x=>x.visible);
  }
  function shellTemplate() {
    const navItems=primaryNavItems();
    return `<div class="shell">
      <header class="topbar"><div class="brand"><div class="brand-mark">A</div><div><strong>AdminStore</strong><small>${esc(me?.displayName || 'مدیریت فروشگاه')}</small></div></div>
      <div class="top-actions"><span class="network-status" id="network-status"></span><button class="icon-btn" id="refresh-btn" aria-label="به‌روزرسانی">↻</button><button class="icon-btn" id="more-top" aria-label="بیشتر">⋮</button></div></header>
      <main class="main" id="content"></main>
      <nav class="bottom-nav" style="--nav-count:${navItems.length}">
        ${navItems.map(x=>navButton(x.id,x.icon,x.label)).join('')}
      </nav>
      <div id="more-menu"></div>
    </div>`;
  }
  function navButton(id, ico, label) { return `<button class="nav-btn ${page===id?'active':''}" data-page="${id}"><span class="ico">${ico}</span><span>${label}</span></button>`; }

  async function showShell(next='dashboard') {
    page=next; moreOpen=false; appRoot(shellTemplate()); bindShell(); await loadPage(page);
  }
  function bindShell() {
    $$('.nav-btn').forEach(b=>b.addEventListener('click',()=>{haptic(); const p=b.dataset.page; if(p==='more') toggleMore(); else navigate(p);}));
    $('#refresh-btn')?.addEventListener('click',()=>{haptic(); loadPage(page,true)});
    $('#more-top')?.addEventListener('click',()=>{haptic(); toggleMore()});
    updateNetworkStatus();
    window.ononline=()=>{updateNetworkStatus();toast('اتصال اینترنت برقرار شد.');};
    window.onoffline=()=>{updateNetworkStatus();toast('اتصال اینترنت قطع است.','error');};
  }
  function moreItems() {
    return [
      {id:'inventory', icon:'▥', label:'موجودی'},
      {id:'catalog', icon:'◫', label:'کاتالوگ'},
      {id:'customers', icon:'👥', label:'مشتریان'},
      {id:'marketing', icon:'✦', label:'بازاریابی'},
      {id:'reports', icon:'▥', label:'گزارش‌ها'},
      {id:'administration', icon:'♙', label:'مدیران و نقش‌ها'},
      {id:'settings', icon:'⚙', label:'تنظیمات فروشگاه'},
      {id:'import', icon:'⇧', label:'ورود CSV'},
      {id:'audit', icon:'☷', label:'گزارش عملیات'},
      {id:'diagnostics', icon:'⌁', label:'سازگاری API'},
      {id:'account', icon:'◎', label:'حساب و سیستم'},
      {id:'products', icon:'＋', label:'محصولات'}
    ].filter(x=>canAccessPage(x.id));
  }
  function updateNav() { $$('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.page===page || (b.dataset.page==='more'&&['inventory','catalog','customers','marketing','reports','administration','settings','import','audit','diagnostics','account'].includes(page)))); }
  async function navigate(p) { page=p; moreOpen=false; renderMore(); updateNav(); await loadPage(p); }
  function toggleMore(){moreOpen=!moreOpen;renderMore();}
  function renderMore(){
    const host=$('#more-menu'); if(!host)return;
    const items=moreItems();
    host.innerHTML=moreOpen?`<div class="more-menu"><div class="more-grid">
      ${items.map(x=>`<button data-more="${x.id}">${x.icon}<b>${esc(x.label)}</b></button>`).join('')}<button id="close-more">×<b>بستن</b></button>
    </div></div>`:'';
    $$('[data-more]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.more)));
    $('#close-more')?.addEventListener('click',()=>toggleMore());
  }

  const pageLabels = {dashboard:'داشبورد',products:'محصولات',inventory:'موجودی',catalog:'کاتالوگ',orders:'سفارش‌ها',payments:'پرداخت‌ها',customers:'مشتریان',marketing:'بازاریابی و محتوا',reports:'گزارش‌ها',administration:'مدیران و نقش‌ها',settings:'تنظیمات فروشگاه',import:'ورود CSV',audit:'گزارش عملیات',diagnostics:'سازگاری API',account:'حساب و سیستم'};
  function forbiddenView(target=page) {
    const rule=Authz.pageAccess[target];
    const needed=[...(rule?.any||[]),...(rule?.all||[])];
    $('#content').innerHTML=head('دسترسی محدود',`اجازه ورود به «${pageLabels[target]||target}» را ندارید.`)+`<div class="forbidden"><div class="forbidden-code">403</div><h2>دسترسی مجاز نیست</h2><p>این حساب Permission لازم برای مشاهده یا مدیریت این بخش را ندارد.</p>${needed.length?`<div class="permission-needed">نیازمند: ${needed.map(esc).join(' یا ')}</div>`:''}<button class="btn primary" id="back-dashboard">بازگشت به داشبورد</button></div>`;
    $('#back-dashboard')?.addEventListener('click',()=>navigate('dashboard'));
  }

  function head(title, sub, action='') { return `<div class="page-head"><div><h1>${esc(title)}</h1><p>${esc(sub)}</p></div>${action}</div>`; }
  function loading(title='در حال دریافت اطلاعات…'){ $('#content').innerHTML=head(title,'')+`<div class="loading"><div class="spinner"></div><span>کمی صبر کنید</span></div>`; }
  function pageError(e){
    if(e.status===403){ forbiddenView(page); return; }
    $('#content').innerHTML += `<div class="error-box"><b>${esc(errorFa(e.code||e.message))}</b><button class="btn small ghost" id="retry-page" style="margin-right:8px">تلاش دوباره</button></div>`;
    $('#retry-page')?.addEventListener('click',()=>loadPage(page,true));
    if(e.status===401){setToken(''); setTimeout(()=>loginView('برای ادامه دوباره وارد شوید.'),700);}
  }

  async function loadPage(p, force=false) {
    moreOpen=false; renderMore(); updateNav();
    if(!canAccessPage(p)){ forbiddenView(p); return; }
    try {
      if(p==='dashboard') return loadDashboard();
      if(p==='products') return loadProducts(force);
      if(p==='inventory') return loadInventory(force);
      if(p==='catalog') return loadCatalog(force);
      if(p==='orders') return loadOrders(force);
      if(p==='payments') return loadPayments(force);
      if(p==='customers') return loadCustomers(force);
      if(p==='marketing') return loadMarketing(force);
      if(p==='reports') return loadReports(force);
      if(p==='administration') return loadAdministration(force);
      if(p==='settings') return loadSettings(force);
      if(p==='import') return renderImport();
      if(p==='audit') return loadAudit(force);
      if(p==='diagnostics') return loadDiagnostics(force);
      if(p==='account') return loadAccount();
    } catch(e){pageError(e)}
  }

  async function loadDashboard(){
    loading('داشبورد');
    try{
      const d=await api.dashboard(); cache.dashboard=d;
      $('#content').innerHTML=head('داشبورد','وضعیت امروز فروشگاه')+`<div class="cards">
        <div class="metric"><span>فروش امروز</span><b>${money(d.salesToday)}</b></div><div class="metric"><span>سفارش امروز</span><b>${fa(d.ordersToday)}</b></div>
        <div class="metric"><span>پرداخت برای بررسی</span><b>${fa(d.pendingPayments)}</b></div><div class="metric"><span>کم‌موجود</span><b>${fa(d.lowStock)}</b></div>
      </div><div class="panel"><h2>کارهای مهم</h2>${d.pendingPayments?`<div class="notice warn">${fa(d.pendingPayments)} پرداخت منتظر بررسی است.</div>`:`<div class="notice">پرداخت معوقی برای بررسی ندارید.</div>`}
      ${d.lowStock?`<div class="notice warn" style="margin-top:8px">${fa(d.lowStock)} واریانت کم‌موجود است.</div>`:''}</div>`;
    }catch(e){pageError(e)}
  }

  const productViewState = {page:1,limit:20,search:'',status:'all',brand:'all',category:'all',sort:'newest'};
  const inventoryViewState = {search:'',status:'all'};

  function entityId(x){ return String(x?.id ?? x?.serverId ?? x?._id ?? x?.slug ?? x?.name ?? ''); }
  function entityName(x){ return typeof x==='string' ? x : String(x?.name ?? x?.title ?? x?.label ?? x?.slug ?? ''); }
  function normalizeEntities(payload, keys=[]){ return listPayload(payload,keys).items.filter(Boolean); }
  function uniqueEntities(rows){
    const m=new Map(); rows.forEach(x=>{const name=entityName(x).trim();if(!name)return;const id=entityId(x)||name.toLowerCase();if(!m.has(id))m.set(id,typeof x==='string'?{id:name,name}:x)});return [...m.values()];
  }
  function deriveCatalog(products=[]){
    const brands=[],categories=[],attributes=[];
    products.forEach(p=>{
      if(p.brand) brands.push(typeof p.brand==='string'?{id:p.brand,name:p.brand}:p.brand);
      if(p.category) categories.push(p.category);
      if(p.categoryId && !p.category) categories.push({id:p.categoryId,name:p.categoryName||p.categoryTitle||String(p.categoryId)});
      (p.variants||[]).forEach(v=>{
        const attrs=v.attributes||v.options||{};
        if(Array.isArray(attrs)) attrs.forEach(a=>attributes.push({id:a.id||a.name,name:a.name||a.label,values:a.values||[a.value].filter(Boolean)}));
        else Object.keys(attrs||{}).forEach(k=>attributes.push({id:k,name:k,values:[attrs[k]]}));
      });
    });
    return {brands:uniqueEntities(brands),categories:uniqueEntities(categories),attributes:uniqueEntities(attributes)};
  }
  async function ensureCatalog(force=false){
    if(cache.catalog && !force) return cache.catalog;
    if(!cache.products.length){
      try{const r=await api.products({limit:200});cache.products=listPayload(r,['products']).items}catch(_){}
    }
    const derived=deriveCatalog(cache.products);
    const [cr,br,ar]=await Promise.all([api.categories(),api.brands(),api.attributes()]);
    cache.catalog={
      categories:uniqueEntities([...normalizeEntities(cr,['categories']),...derived.categories]),
      brands:uniqueEntities([...normalizeEntities(br,['brands']),...derived.brands]),
      attributes:uniqueEntities([...normalizeEntities(ar,['attributes']),...derived.attributes])
    };
    return cache.catalog;
  }

  async function loadProducts(force=false){
    loading('محصولات');
    try{
      await ensureCatalog(force);
      const params={page:productViewState.page,limit:productViewState.limit,search:productViewState.search,status:productViewState.status,brand:productViewState.brand,categoryId:productViewState.category,sort:productViewState.sort};
      const payload=await api.products(params);
      const parsed=listPayload(payload,['products']);
      cache.products=parsed.items; cache.productMeta=parsed.meta;
      renderProducts(cache.products,parsed.meta);
    }catch(e){pageError(e)}
  }
  function productMatches(p){
    const q=productViewState.search.trim().toLowerCase();
    const variants=p.variants||[];
    const txt=`${p.name||''} ${entityName(p.brand)} ${entityName(p.category)} ${variants.map(v=>v.sku).join(' ')}`.toLowerCase();
    const totalStock=variants.reduce((a,v)=>a+Number(v.stock||0),0);
    if(q && !txt.includes(q))return false;
    if(productViewState.status==='active'&&!p.active)return false;
    if(productViewState.status==='inactive'&&p.active)return false;
    if(productViewState.status==='low'&&!variants.some(v=>Number(v.stock||0)>0&&Number(v.stock||0)<=3))return false;
    if(productViewState.status==='out'&&totalStock>0)return false;
    if(productViewState.brand!=='all' && ![entityId(p.brand),entityName(p.brand)].includes(productViewState.brand))return false;
    if(productViewState.category!=='all' && ![entityId(p.category),String(p.categoryId||'')].includes(productViewState.category))return false;
    return true;
  }
  function sortProducts(rows){
    const out=[...rows];
    if(productViewState.sort==='name')out.sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'fa'));
    if(productViewState.sort==='stock')out.sort((a,b)=>(b.variants||[]).reduce((s,v)=>s+Number(v.stock||0),0)-(a.variants||[]).reduce((s,v)=>s+Number(v.stock||0),0));
    if(productViewState.sort==='price')out.sort((a,b)=>Math.min(...(a.variants||[{price:a.price||0}]).map(v=>Number(v.price||0)))-Math.min(...(b.variants||[{price:b.price||0}]).map(v=>Number(v.price||0))));
    return out;
  }
  function productFiltersHtml(){
    const c=cache.catalog||{brands:[],categories:[]};
    return `<div class="toolbar catalog-toolbar"><input class="search" id="product-q" value="${esc(productViewState.search)}" placeholder="جستجوی نام یا SKU"><select class="select" id="product-state"><option value="all">همه وضعیت‌ها</option><option value="active">فعال</option><option value="inactive">غیرفعال</option><option value="low">کم‌موجود</option><option value="out">ناموجود</option></select><select class="select" id="product-brand"><option value="all">همه برندها</option>${c.brands.map(x=>`<option value="${esc(entityId(x))}">${esc(entityName(x))}</option>`).join('')}</select><select class="select" id="product-category"><option value="all">همه دسته‌ها</option>${c.categories.map(x=>`<option value="${esc(entityId(x))}">${esc(entityName(x))}</option>`).join('')}</select><select class="select" id="product-sort"><option value="newest">جدیدترین</option><option value="name">نام</option><option value="stock">موجودی</option><option value="price">قیمت</option></select></div>`;
  }
  function renderProducts(rows,meta=null){
    const createAction=can(P.PRODUCTS_CREATE)?`<button class="btn primary small" id="new-product">＋ محصول</button>`:'';
    $('#content').innerHTML=head('محصولات','کاتالوگ، واریانت، تصویر، قیمت و وضعیت',createAction)+productFiltersHtml()+`<div class="list" id="products-list"></div><div id="products-pagination"></div>`;
    $('#product-state').value=productViewState.status;$('#product-brand').value=productViewState.brand;$('#product-category').value=productViewState.category;$('#product-sort').value=productViewState.sort;
    const serverPaged=!!meta;
    let filtered=sortProducts(rows.filter(productMatches));
    if(!serverPaged){const from=(productViewState.page-1)*productViewState.limit;filtered=filtered.slice(from,from+productViewState.limit)}
    $('#products-list').innerHTML=filtered.length?filtered.map(productCard).join(''):`<div class="empty">محصولی پیدا نشد.</div>`;
    const totalPages=Number(meta?.totalPages||meta?.pages||(!serverPaged?Math.max(1,Math.ceil(rows.filter(productMatches).length/productViewState.limit)):1));
    renderPager($('#products-pagination'),productViewState.page,totalPages,p=>{productViewState.page=p;loadProducts(true)});
    $$('[data-product-view]').forEach(b=>b.addEventListener('click',()=>openProductById(b.dataset.productView,false)));
    $$('[data-edit-product]').forEach(b=>b.addEventListener('click',()=>openProductById(b.dataset.editProduct,true)));
    let t;$('#product-q').addEventListener('input',e=>{clearTimeout(t);t=setTimeout(()=>{productViewState.search=e.target.value.trim();productViewState.page=1;loadProducts(true)},350)});
    [['product-state','status'],['product-brand','brand'],['product-category','category'],['product-sort','sort']].forEach(([id,k])=>$('#'+id).addEventListener('change',e=>{productViewState[k]=e.target.value;productViewState.page=1;loadProducts(true)}));
    $('#new-product')?.addEventListener('click',openCreateProduct);
  }
  function renderPager(host,current,total,onPage){
    if(!host||total<=1){if(host)host.innerHTML='';return}
    host.innerHTML=`<div class="pager"><button class="btn small ghost" id="page-prev" ${current<=1?'disabled':''}>قبلی</button><span>صفحه ${fa(current)} از ${fa(total)}</span><button class="btn small ghost" id="page-next" ${current>=total?'disabled':''}>بعدی</button></div>`;
    $('#page-prev')?.addEventListener('click',()=>onPage(current-1));$('#page-next')?.addEventListener('click',()=>onPage(current+1));
  }
  function productImages(p){return Array.isArray(p.images)?p.images:Array.isArray(p.gallery)?p.gallery:[]}
  function imageRef(img){return String(img?.id??img?.serverId??img?._id??img?.url??'')}
  function imageUrl(img){return absoluteAssetUrl(typeof img==='string'?img:(img?.url||img?.src||img?.path||''))}
  function productCard(p){
    const variants=p.variants||[],stock=variants.reduce((s,v)=>s+Number(v.stock||0),0),prices=variants.map(v=>Number(v.price||0)).filter(Number.isFinite),min=prices.length?Math.min(...prices):Number(p.price||0),img=productImages(p)[0],pid=productId(p);
    return `<article class="item product-item"><div class="product-row">${imageUrl(img)?`<img class="product-thumb" src="${esc(imageUrl(img))}" alt="">`:`<div class="product-thumb placeholder">▦</div>`}<div class="product-grow"><div class="item-top"><div><h3>${esc(p.name)}</h3><div class="item-meta"><span>${esc(entityName(p.brand)||'Trust')}</span><span>${fa(variants.length)} واریانت</span><span>موجودی ${fa(stock)}</span>${entityName(p.category)?`<span>${esc(entityName(p.category))}</span>`:''}</div></div><span class="badge ${p.active?'ok':'danger'}">${p.active?'فعال':'غیرفعال'}</span></div><div class="item-actions"><span class="money">${money(min)}</span><button class="btn small ghost" data-product-view="${esc(pid)}">جزئیات</button>${can(P.PRODUCTS_UPDATE)?`<button class="btn small" data-edit-product="${esc(pid)}">ویرایش</button>`:''}</div></div></div></article>`;
  }
  async function openProductById(id,edit=false){
    let p=cache.products.find(x=>productId(x)===String(id));
    try{p=await api.product(id)}catch(e){if(!endpointMissing(e))return toast(errorFa(e.code||e.message),'error')}
    if(!p)return toast('محصول پیدا نشد.','error');
    openProduct(p,edit);
  }
  function catalogSelect(kind,current=''){
    const rows=cache.catalog?.[kind]||[];
    return `<option value="">—</option>${rows.map(x=>`<option value="${esc(entityId(x))}" ${String(current)===entityId(x)?'selected':''}>${esc(entityName(x))}</option>`).join('')}`;
  }
  function productGallery(p,editable){
    const imgs=productImages(p),pid=productId(p);
    return `<div class="gallery">${imgs.length?imgs.map((img,i)=>`<div class="gallery-item"><img src="${esc(imageUrl(img))}" alt=""><div class="gallery-actions">${editable?`<button type="button" class="mini-btn" data-main-image="${esc(imageRef(img))}" title="تصویر اصلی">★</button><button type="button" class="mini-btn danger-text" data-delete-image="${esc(imageRef(img))}" title="حذف">×</button>`:''}</div>${(img.isMain||img.main||i===0)?'<span class="main-image-tag">اصلی</span>':''}</div>`).join(''):'<div class="empty compact">هنوز تصویری ثبت نشده است.</div>'}</div>${editable?`<label class="upload-box"><input id="product-image-file" type="file" accept="image/*" hidden><span>＋ افزودن تصویر</span></label>`:''}`;
  }
  function openProduct(p,edit=false){
    const editable=edit&&can(P.PRODUCTS_UPDATE),pid=productId(p),brandCurrent=entityId(p.brand)||String(p.brandId||''),catCurrent=entityId(p.category)||String(p.categoryId||'');
    if(edit&&!requirePermission(P.PRODUCTS_UPDATE))return;
    openModal(editable?'ویرایش محصول':'جزئیات محصول',`<div class="product-detail-head">${productGallery(p,editable)}</div><form id="edit-product-form"><label class="field"><span>نام محصول</span><input id="ep-name" value="${esc(p.name)}" ${editable?'':'disabled'} required></label><div class="grid2"><label class="field"><span>Slug</span><input id="ep-slug" dir="ltr" value="${esc(p.slug||'')}" ${editable?'':'disabled'}></label><label class="field"><span>برند</span><select id="ep-brand" ${editable?'':'disabled'}>${catalogSelect('brands',brandCurrent)}</select></label><label class="field"><span>دسته‌بندی</span><select id="ep-category" ${editable?'':'disabled'}>${catalogSelect('categories',catCurrent)}</select></label><label class="field"><span>فعال</span><select id="ep-active" ${editable?'':'disabled'}><option value="1" ${p.active?'selected':''}>بله</option><option value="0" ${!p.active?'selected':''}>خیر</option></select></label><label class="field"><span>محصول جدید</span><select id="ep-new" ${editable?'':'disabled'}><option value="1" ${p.isNew?'selected':''}>بله</option><option value="0" ${!p.isNew?'selected':''}>خیر</option></select></label></div><label class="field"><span>توضیح کوتاه</span><textarea id="ep-short" ${editable?'':'disabled'}>${esc(p.shortDescription||'')}</textarea></label>${editable?`<button class="btn primary full">ذخیره اطلاعات محصول</button>`:''}</form><div class="divider"></div><div class="section-title"><h3>واریانت‌ها</h3>${can(P.VARIANTS_CREATE)&&editable?`<button type="button" class="btn small" id="add-variant">＋ واریانت</button>`:''}</div>${(p.variants||[]).map(v=>variantForm(v,pid,editable)).join('')||'<div class="empty compact">واریانتی ندارد.</div>'}${editable&&can(P.PRODUCTS_DELETE)?`<div class="danger-zone"><b>آرشیو محصول</b><p>اگر حذف مستقیم در بک‌اند فعال نباشد، محصول غیرفعال و آرشیو می‌شود.</p><button type="button" class="btn danger" id="archive-product">آرشیو / حذف</button></div>`:''}`);
    if(editable){
      $('#edit-product-form').addEventListener('submit',async e=>{e.preventDefault();const bid=$('#ep-brand').value,cid=$('#ep-category').value,bobj=(cache.catalog?.brands||[]).find(x=>entityId(x)===bid);const data={name:$('#ep-name').value.trim(),slug:$('#ep-slug').value.trim()||undefined,brand:entityName(bobj)||undefined,brandId:bid||undefined,categoryId:cid||undefined,shortDescription:$('#ep-short').value.trim(),active:$('#ep-active').value==='1',isNew:$('#ep-new').value==='1'};try{await api.updateProduct(pid,data);toast('محصول ذخیره شد.');closeModal();cache.products=[];cache.catalog=null;loadProducts(true)}catch(e){toast(errorFa(e.code||e.message),'error')}});
      bindVariantActions(p,pid);
      $('#add-variant')?.addEventListener('click',()=>openCreateVariant(p));
      $('#archive-product')?.addEventListener('click',async()=>{if(!requirePermission(P.PRODUCTS_DELETE))return;if(!confirm('این محصول آرشیو/حذف شود؟'))return;try{await api.archiveProduct(pid);toast('محصول آرشیو شد.');closeModal();cache.products=[];loadProducts(true)}catch(e){toast(errorFa(e.code||e.message),'error')}});
      $('#product-image-file')?.addEventListener('change',async e=>{const f=e.target.files?.[0];if(!f)return;if(f.size>8*1024*1024)return toast('حجم تصویر باید کمتر از ۸ مگابایت باشد.','error');try{await api.uploadProductImage(pid,f);toast('تصویر اضافه شد.');closeModal();cache.products=[];loadProducts(true)}catch(err){toast(errorFa(err.code||err.message),'error')}});
      $$('[data-delete-image]').forEach(b=>b.addEventListener('click',async()=>{if(!confirm('تصویر حذف شود؟'))return;try{await api.deleteProductImage(pid,b.dataset.deleteImage);toast('تصویر حذف شد.');closeModal();cache.products=[];loadProducts(true)}catch(e){toast(errorFa(e.code||e.message),'error')}}));
      $$('[data-main-image]').forEach(b=>b.addEventListener('click',async()=>{try{await api.setMainProductImage(pid,b.dataset.mainImage);toast('تصویر اصلی تغییر کرد.');closeModal();cache.products=[];loadProducts(true)}catch(e){toast(errorFa(e.code||e.message),'error')}}));
    }
  }
  function variantForm(v,pid,editable){
    const id=variantId(v);return `<div class="variant" data-variant-box="${esc(id)}"><div class="section-title"><h4>${esc(v.label||v.title||'اصلی')}</h4><span class="sku">${esc(v.sku||'—')}</span></div><div class="grid2"><label class="field"><span>SKU</span><input class="v-sku" dir="ltr" value="${esc(v.sku||'')}" ${editable?'':'disabled'}></label><label class="field"><span>عنوان</span><input class="v-title" value="${esc(v.label||v.title||'اصلی')}" ${editable?'':'disabled'}></label><label class="field"><span>قیمت</span><input class="v-price" type="number" min="0" value="${Number(v.price||0)}" ${editable?'':'disabled'}></label><label class="field"><span>قیمت قبلی</span><input class="v-compare" type="number" min="0" value="${v.compareAtPrice??''}" ${editable?'':'disabled'}></label><label class="field"><span>موجودی</span><input class="v-stock" value="${Number(v.stock||0)}" disabled></label><label class="field"><span>وضعیت</span><select class="v-active" ${editable?'':'disabled'}><option value="1" ${v.active?'selected':''}>فعال</option><option value="0" ${!v.active?'selected':''}>غیرفعال</option></select></label></div>${editable?`<div class="item-actions"><button type="button" class="btn small" data-save-variant="${esc(id)}">ذخیره واریانت</button>${can(P.INVENTORY_UPDATE)?`<button type="button" class="btn small ghost" data-adjust-variant="${esc(id)}">اصلاح موجودی</button>`:''}${can(P.VARIANTS_DELETE)?`<button type="button" class="btn small danger" data-delete-variant="${esc(id)}">حذف</button>`:''}</div>`:''}</div>`;
  }
  function bindVariantActions(p,pid){
    $$('[data-save-variant]').forEach(b=>b.addEventListener('click',async()=>{const id=b.dataset.saveVariant,box=$$('[data-variant-box]').find(x=>x.dataset.variantBox===id),sku=$('.v-sku',box).value.trim();if(!await skuAvailable(sku,id))return toast('این SKU قبلاً استفاده شده است.','error');try{await api.updateVariant(id,{sku,title:$('.v-title',box).value.trim()||'اصلی',price:Number($('.v-price',box).value),compareAtPrice:$('.v-compare',box).value?Number($('.v-compare',box).value):null,active:$('.v-active',box).value==='1'});toast('واریانت ذخیره شد.');cache.products=[]}catch(e){toast(errorFa(e.code||e.message),'error')}}));
    $$('[data-adjust-variant]').forEach(b=>b.addEventListener('click',()=>{const v=(p.variants||[]).find(x=>variantId(x)===b.dataset.adjustVariant);if(v)openInventoryAdjust(v,p)}));
    $$('[data-delete-variant]').forEach(b=>b.addEventListener('click',async()=>{if(!confirm('این واریانت حذف شود؟'))return;try{await api.deleteVariant(pid,b.dataset.deleteVariant);toast('واریانت حذف شد.');closeModal();cache.products=[];loadProducts(true)}catch(e){toast(errorFa(e.code||e.message),'error')}}));
  }
  async function skuAvailable(sku,excludeId=''){
    if(!sku)return false;
    const remote=await api.validateSku(sku,excludeId);if(remote!==null){if(typeof remote==='boolean')return remote; if('available' in remote)return !!remote.available; if('exists' in remote)return !remote.exists}
    return !cache.products.some(p=>(p.variants||[]).some(v=>String(v.sku||'').toLowerCase()===sku.toLowerCase()&&variantId(v)!==String(excludeId)));
  }
  function openCreateVariant(p){
    if(!requirePermission(P.VARIANTS_CREATE))return;const pid=productId(p);
    openModal('واریانت جدید',`<form id="create-variant-form"><div class="grid2"><label class="field"><span>SKU</span><input id="nv-sku" dir="ltr" required></label><label class="field"><span>عنوان</span><input id="nv-title" value="اصلی" required></label><label class="field"><span>قیمت</span><input id="nv-price" type="number" min="0" required></label><label class="field"><span>قیمت قبلی</span><input id="nv-compare" type="number" min="0"></label><label class="field"><span>موجودی اولیه</span><input id="nv-stock" type="number" min="0" value="0"></label><label class="field"><span>فعال</span><select id="nv-active"><option value="1">بله</option><option value="0">خیر</option></select></label></div><button class="btn primary full">ساخت واریانت</button></form>`);
    $('#create-variant-form').addEventListener('submit',async e=>{e.preventDefault();const sku=$('#nv-sku').value.trim();if(!await skuAvailable(sku))return toast('این SKU قبلاً استفاده شده است.','error');const data={sku,title:$('#nv-title').value.trim()||'اصلی',price:Number($('#nv-price').value),compareAtPrice:$('#nv-compare').value?Number($('#nv-compare').value):null,stock:Number($('#nv-stock').value||0),active:$('#nv-active').value==='1'};try{await api.createVariant(pid,data);toast('واریانت ساخته شد.');closeModal();cache.products=[];loadProducts(true)}catch(e){toast(errorFa(e.code||e.message),'error')}});
  }
  async function openCreateProduct(){
    if(!requirePermission(P.PRODUCTS_CREATE))return;await ensureCatalog();
    openModal('محصول جدید',`<form id="create-product-form"><label class="field"><span>نام محصول</span><input id="cp-name" required></label><label class="field"><span>Slug انگلیسی</span><input id="cp-slug" dir="ltr" required placeholder="trust-product"></label><div class="grid2"><label class="field"><span>برند</span><select id="cp-brand">${catalogSelect('brands','')}</select></label><label class="field"><span>دسته‌بندی</span><select id="cp-category">${catalogSelect('categories','')}</select></label><label class="field"><span>SKU</span><input id="cp-sku" dir="ltr" required></label><label class="field"><span>عنوان واریانت</span><input id="cp-variant" value="اصلی"></label><label class="field"><span>قیمت</span><input id="cp-price" type="number" min="0" required></label><label class="field"><span>قیمت قبلی</span><input id="cp-compare" type="number" min="0"></label><label class="field"><span>موجودی اولیه</span><input id="cp-stock" type="number" min="0" value="0"></label></div><label class="field"><span>توضیح کوتاه</span><textarea id="cp-short"></textarea></label><button class="btn primary full">ساخت محصول</button></form>`);
    $('#create-product-form').addEventListener('submit',async e=>{e.preventDefault();const sku=$('#cp-sku').value.trim();if(!await skuAvailable(sku))return toast('این SKU قبلاً استفاده شده است.','error');const bid=$('#cp-brand').value,bobj=(cache.catalog?.brands||[]).find(x=>entityId(x)===bid),data={name:$('#cp-name').value.trim(),slug:$('#cp-slug').value.trim(),brand:entityName(bobj)||'Trust',brandId:bid||undefined,categoryId:$('#cp-category').value||undefined,shortDescription:$('#cp-short').value.trim(),active:true,variants:[{sku,title:$('#cp-variant').value.trim()||'اصلی',price:Number($('#cp-price').value),stock:Number($('#cp-stock').value||0),active:true}]};if($('#cp-compare').value)data.variants[0].compareAtPrice=Number($('#cp-compare').value);try{await api.createProduct(data);toast('محصول ساخته شد.');closeModal();cache.products=[];cache.catalog=null;loadProducts(true)}catch(e){toast(errorFa(e.code||e.message),'error')}});
  }

  async function loadCatalog(force=false){
    loading('کاتالوگ');try{const c=await ensureCatalog(force);renderCatalog(c)}catch(e){pageError(e)}
  }
  function renderCatalog(c){
    const manage=can(P.CATALOG_MANAGE);
    $('#content').innerHTML=head('کاتالوگ','دسته‌بندی‌ها، برندها و ویژگی‌های محصول')+`<div class="catalog-sections">${catalogSection('categories','دسته‌بندی‌ها',c.categories,manage)}${catalogSection('brands','برندها',c.brands,manage)}${catalogSection('attributes','ویژگی‌ها',c.attributes,manage)}</div>`;
    $$('[data-catalog-add]').forEach(b=>b.addEventListener('click',()=>openCatalogEntity(b.dataset.catalogAdd,null)));
    $$('[data-catalog-edit]').forEach(b=>b.addEventListener('click',()=>{const kind=b.dataset.catalogEdit,row=(c[kind]||[]).find(x=>entityId(x)===b.dataset.id);openCatalogEntity(kind,row)}));
    $$('[data-catalog-delete]').forEach(b=>b.addEventListener('click',()=>deleteCatalogEntity(b.dataset.catalogDelete,b.dataset.id)));
  }
  function catalogSection(kind,title,rows,manage){return `<section class="panel catalog-panel"><div class="section-title"><h2>${title}</h2>${manage?`<button class="btn small" data-catalog-add="${kind}">＋ افزودن</button>`:''}</div><div class="chip-list">${rows.length?rows.map(x=>`<div class="catalog-chip"><span>${esc(entityName(x))}</span>${manage?`<span><button class="mini-btn" data-catalog-edit="${kind}" data-id="${esc(entityId(x))}">✎</button><button class="mini-btn danger-text" data-catalog-delete="${kind}" data-id="${esc(entityId(x))}">×</button></span>`:''}</div>`).join(''):'<div class="empty compact">موردی ثبت نشده است.</div>'}</div></section>`}
  function openCatalogEntity(kind,row){
    if(!requirePermission(P.CATALOG_MANAGE))return;const singular={categories:'دسته‌بندی',brands:'برند',attributes:'ویژگی'}[kind]||'مورد';
    openModal(`${row?'ویرایش':'افزودن'} ${singular}`,`<form id="catalog-entity-form"><label class="field"><span>نام</span><input id="ce-name" value="${esc(entityName(row)||'')}" required></label><label class="field"><span>Slug / Key</span><input id="ce-slug" dir="ltr" value="${esc(row?.slug||row?.key||'')}"></label>${kind==='attributes'?`<label class="field"><span>مقادیر (با کاما جدا کنید)</span><input id="ce-values" value="${esc((row?.values||[]).map(entityName).join(', '))}"></label>`:''}<button class="btn primary full">ذخیره</button></form>`);
    $('#catalog-entity-form').addEventListener('submit',async e=>{e.preventDefault();const data={name:$('#ce-name').value.trim(),slug:$('#ce-slug').value.trim()||undefined};if(kind==='attributes')data.values=$('#ce-values').value.split(',').map(x=>x.trim()).filter(Boolean);try{const id=entityId(row);if(kind==='categories')await(id?api.updateCategory(id,data):api.createCategory(data));if(kind==='brands')await(id?api.updateBrand(id,data):api.createBrand(data));if(kind==='attributes')await(id?api.updateAttribute(id,data):api.createAttribute(data));toast(`${singular} ذخیره شد.`);closeModal();cache.catalog=null;loadCatalog(true)}catch(e){toast(errorFa(e.code||e.message),'error')}});
  }
  async function deleteCatalogEntity(kind,id){
    if(!requirePermission(P.CATALOG_MANAGE))return;if(!confirm('این مورد حذف شود؟'))return;try{if(kind==='categories')await api.deleteCategory(id);if(kind==='brands')await api.deleteBrand(id);if(kind==='attributes')await api.deleteAttribute(id);toast('حذف شد.');cache.catalog=null;loadCatalog(true)}catch(e){toast(errorFa(e.code||e.message),'error')}
  }

  function deriveInventory(products=[]){
    const rows=[];products.forEach(p=>(p.variants||[]).forEach(v=>rows.push({id:variantId(v),variantId:variantId(v),productId:productId(p),productName:p.name,sku:v.sku,label:v.label||v.title||'اصلی',stock:Number(v.stock||0),active:v.active!==false,updatedAt:v.updatedAt||p.updatedAt,product:p,variant:v})));return rows;
  }
  async function loadInventory(force=false){
    loading('موجودی');try{
      let remote=await api.inventory({search:inventoryViewState.search,status:inventoryViewState.status});
      if(remote!==null){cache.inventory=listPayload(remote,['inventory']).items.map(x=>({...x,id:String(x.variantId||x.id||''),stock:Number(x.stock??x.quantity??0)}))}
      else {if(force||!cache.products.length){const r=await api.products({limit:500});cache.products=listPayload(r,['products']).items}cache.inventory=deriveInventory(cache.products)}
      renderInventory(cache.inventory);
    }catch(e){pageError(e)}
  }
  function inventoryStatus(stock){return stock<=0?'out':stock<=3?'low':'ok'}
  function renderInventory(rows){
    const total=rows.reduce((s,x)=>s+Number(x.stock||0),0),low=rows.filter(x=>inventoryStatus(Number(x.stock||0))==='low').length,out=rows.filter(x=>Number(x.stock||0)<=0).length;
    $('#content').innerHTML=head('موجودی','کنترل موجودی و تاریخچه تغییرات')+`<div class="cards inventory-metrics"><div class="metric"><span>کل واحد موجود</span><b>${fa(total)}</b></div><div class="metric"><span>واریانت‌ها</span><b>${fa(rows.length)}</b></div><div class="metric"><span>کم‌موجود</span><b>${fa(low)}</b></div><div class="metric"><span>ناموجود</span><b>${fa(out)}</b></div></div><div class="toolbar"><input class="search" id="inventory-q" value="${esc(inventoryViewState.search)}" placeholder="نام محصول یا SKU"><select class="select" id="inventory-state"><option value="all">همه</option><option value="ok">موجود</option><option value="low">کم‌موجود</option><option value="out">ناموجود</option></select></div><div class="list" id="inventory-list"></div>`;
    $('#inventory-state').value=inventoryViewState.status;
    const draw=()=>{const q=$('#inventory-q').value.trim().toLowerCase(),st=$('#inventory-state').value,f=rows.filter(x=>(!q||`${x.productName||x.product?.name||''} ${x.sku||''}`.toLowerCase().includes(q))&&(st==='all'||inventoryStatus(Number(x.stock||0))===st));$('#inventory-list').innerHTML=f.length?f.map(inventoryCard).join(''):'<div class="empty">رکوردی پیدا نشد.</div>';$$('[data-inventory-adjust]').forEach(b=>b.addEventListener('click',()=>{const x=rows.find(r=>String(r.variantId||r.id)===b.dataset.inventoryAdjust);if(x)openInventoryAdjust(x.variant||x,x.product||{name:x.productName,serverId:x.productId})}));$$('[data-inventory-history]').forEach(b=>b.addEventListener('click',()=>openInventoryHistory(b.dataset.inventoryHistory,rows.find(r=>String(r.variantId||r.id)===b.dataset.inventoryHistory))));};
    $('#inventory-q').addEventListener('input',draw);$('#inventory-state').addEventListener('change',draw);draw();
  }
  function inventoryCard(x){const st=inventoryStatus(Number(x.stock||0)),id=String(x.variantId||x.id||'');return `<article class="item"><div class="item-top"><div><h3>${esc(x.productName||x.product?.name||'محصول')}</h3><div class="item-meta"><span>${esc(x.sku||'—')}</span><span>${esc(x.label||x.variant?.label||x.variant?.title||'اصلی')}</span>${x.updatedAt?`<span>${dateFa(x.updatedAt)}</span>`:''}</div></div><span class="stock-pill ${st}">${fa(x.stock)}</span></div><div class="item-actions">${can(P.INVENTORY_UPDATE)?`<button class="btn small" data-inventory-adjust="${esc(id)}">اصلاح موجودی</button>`:''}<button class="btn small ghost" data-inventory-history="${esc(id)}">تاریخچه</button></div></article>`}
  function openInventoryAdjust(v,p){
    if(!requirePermission(P.INVENTORY_UPDATE))return;const id=variantId(v)||String(v.id||''),current=Number(v.stock??v.quantity??0);
    openModal('اصلاح موجودی',`<div class="notice">${esc(p?.name||'محصول')} · ${esc(v.sku||'—')} · موجودی فعلی: ${fa(current)}</div><form id="inventory-adjust-form" style="margin-top:12px"><label class="field"><span>نوع تغییر</span><select id="ia-type"><option value="increase">افزایش</option><option value="decrease">کاهش</option><option value="set">تنظیم عدد نهایی</option></select></label><label class="field"><span>تعداد</span><input id="ia-qty" type="number" min="0" required></label><label class="field"><span>علت</span><textarea id="ia-reason" placeholder="مثلاً ورود بار جدید، اصلاح شمارش، خرابی کالا" required></textarea></label><div id="ia-preview" class="notice"></div><button class="btn primary full" style="margin-top:10px">ثبت تغییر موجودی</button></form>`);
    const preview=()=>{const type=$('#ia-type').value,n=Math.max(0,Number($('#ia-qty').value||0)),next=type==='set'?n:type==='decrease'?Math.max(0,current-n):current+n;$('#ia-preview').textContent=`موجودی بعد از ثبت: ${fa(next)}`;return next};$('#ia-type').addEventListener('change',preview);$('#ia-qty').addEventListener('input',preview);preview();
    $('#inventory-adjust-form').addEventListener('submit',async e=>{e.preventDefault();const type=$('#ia-type').value,n=Math.max(0,Number($('#ia-qty').value||0)),reason=$('#ia-reason').value.trim();if(!reason)return toast('علت تغییر موجودی را بنویسید.','error');const next=preview(),delta=next-current;try{await api.adjustInventory(id,{type,quantity:n,delta,absoluteQuantity:next,reason},current);toast('موجودی به‌روزرسانی شد.');closeModal();cache.inventory=[];cache.products=[];if(page==='inventory')loadInventory(true);else loadProducts(true)}catch(e){toast(errorFa(e.code||e.message),'error')}});
  }
  async function openInventoryHistory(id,row){
    openModal('تاریخچه موجودی','<div class="loading"><div class="spinner"></div><span>در حال دریافت…</span></div>');try{const payload=await api.inventoryHistory(id);if(payload===null){$('#modal-root .modal').innerHTML=`<div class="modal-head"><h2>تاریخچه موجودی</h2><button class="modal-close" id="modal-close">×</button></div><div class="notice warn">Endpoint تاریخچه موجودی در بک‌اند فعال نیست. تغییر موجودی همچنان از مسیر امن Adjustment انجام می‌شود.</div>`;$('#modal-close').addEventListener('click',closeModal);return}const rows=listPayload(payload,['history','transactions']).items;$('#modal-root .modal').innerHTML=`<div class="modal-head"><h2>تاریخچه موجودی</h2><button class="modal-close" id="modal-close">×</button></div><div class="panel"><div class="subtle" style="margin-bottom:10px">${esc(row?.productName||'')} · ${esc(row?.sku||'')}</div>${rows.length?rows.map(h=>`<div class="audit-item"><b>${Number(h.quantity??h.delta??0)>0?'+':''}${fa(h.quantity??h.delta??0)} · ${esc(h.reason||h.type||'تغییر موجودی')}</b><small>${dateFa(h.createdAt||h.date)}${h.adminUser?.displayName?` · ${esc(h.adminUser.displayName)}`:''}</small></div>`).join(''):'<div class="empty compact">تاریخچه‌ای ثبت نشده است.</div>'}</div>`;$('#modal-close').addEventListener('click',closeModal)}catch(e){toast(errorFa(e.code||e.message),'error');closeModal()}
  }

  const orderViewState={search:'',status:'all'};
  const paymentViewState={search:'',status:'all'};
  const customerViewState={search:'',status:'all',page:1,limit:20};

  const orderTransitions={
    DRAFT:['AWAITING_PAYMENT','CANCELLED'],PENDING:['CONFIRMED','CANCELLED'],AWAITING_PAYMENT:['CANCELLED'],PAYMENT_SUBMITTED:['PAYMENT_REVIEW','CANCELLED'],PAYMENT_REVIEW:['AWAITING_PAYMENT','PAID','CANCELLED'],
    CONFIRMED:['PROCESSING','CANCELLED'],PAID:['PREPARING','CANCELLED'],PROCESSING:['SHIPPED','CANCELLED'],PREPARING:['SHIPPED','CANCELLED'],SHIPPED:['DELIVERED'],DELIVERED:['RETURNED'],CANCELLED:[],RETURNED:[],REFUNDED:[]
  };
  const orderId=o=>String(o?.id??o?.serverId??o?._id??'');
  const paymentId=p=>String(p?.id??p?.serverId??p?._id??'');
  const customerId=c=>String(c?.id??c?.serverId??c?._id??c?.userId??'');
  const customerName=c=>[c?.firstName,c?.lastName].filter(Boolean).join(' ')||c?.displayName||c?.name||c?.mobile||'مشتری';
  const orderItems=o=>Array.isArray(o?.items)?o.items:Array.isArray(o?.orderItems)?o.orderItems:[];
  const orderAddress=o=>o?.addressSnapshot||o?.shippingAddress||o?.address||{};
  const orderShipping=o=>o?.shippingSnapshot||o?.shipping||{};
  const orderPayment=o=>o?.payment||o?.latestPayment||null;
  const eventLabel=e=>statusFa[e?.status||e?.type||e?.event||e?.action]||e?.title||e?.label||e?.type||e?.action||'رویداد';
  function timelineRows(payload,o){
    const rows=listPayload(payload||{},['timeline','history','events','statusHistory']).items;
    if(rows.length)return rows;
    const own=[...(Array.isArray(o?.timeline)?o.timeline:[]),...(Array.isArray(o?.statusHistory)?o.statusHistory:[])];
    if(own.length)return own;
    const fallback=[];if(o?.createdAt)fallback.push({type:'CREATED',createdAt:o.createdAt});if(o?.status)fallback.push({status:o.status,createdAt:o.updatedAt||o.createdAt});return fallback;
  }
  function timelineHtml(rows=[]){return `<div class="timeline">${rows.length?rows.map(e=>`<div class="timeline-row"><span class="timeline-dot"></span><div><b>${esc(eventLabel(e))}</b><small>${dateFa(e.createdAt||e.date||e.at||e.timestamp)}${e.adminUser?.displayName?` · ${esc(e.adminUser.displayName)}`:''}${e.reason?` · ${esc(e.reason)}`:''}</small></div></div>`).join(''):'<div class="empty compact">تاریخچه‌ای ثبت نشده است.</div>'}</div>`}

  async function loadOrders(force=false){
    loading('سفارش‌ها');
    try{
      const payload=await api.orders({search:orderViewState.search,status:orderViewState.status,limit:100});
      const parsed=listPayload(payload,['orders']);cache.orders=parsed.items;renderOrders(cache.orders,parsed.meta);
    }catch(e){pageError(e)}
  }
  function renderOrders(rows,meta=null){
    const states=['PENDING','AWAITING_PAYMENT','PAYMENT_REVIEW','CONFIRMED','PAID','PROCESSING','PREPARING','SHIPPED','DELIVERED','CANCELLED','RETURNED','REFUNDED'];
    $('#content').innerHTML=head('سفارش‌ها','پرداخت، آماده‌سازی، ارسال و تحویل در یک مسیر')+`<div class="toolbar"><input class="search" id="order-q" value="${esc(orderViewState.search)}" placeholder="شماره سفارش، نام یا موبایل"><select class="select" id="order-state"><option value="all">همه وضعیت‌ها</option>${states.map(s=>`<option value="${s}">${statusFa[s]}</option>`).join('')}</select></div><div class="list" id="orders-list"></div>`;
    $('#order-state').value=orderViewState.status;
    const draw=()=>{const q=$('#order-q').value.trim().toLowerCase(),st=$('#order-state').value;const f=rows.filter(o=>(!q||`${o.orderNumber||''} ${o.user?.mobile||o.customer?.mobile||''} ${customerName(o.user||o.customer||{})}`.toLowerCase().includes(q))&&(st==='all'||o.status===st));$('#orders-list').innerHTML=f.length?f.map(orderCard).join(''):'<div class="empty">سفارشی پیدا نشد.</div>';$$('[data-order]').forEach(b=>b.addEventListener('click',()=>openOrder(f.find(x=>orderId(x)===b.dataset.order)||rows.find(x=>orderId(x)===b.dataset.order))));};
    $('#order-q').addEventListener('input',()=>{orderViewState.search=$('#order-q').value;draw()});$('#order-state').addEventListener('change',()=>{orderViewState.status=$('#order-state').value;draw()});draw();
  }
  function orderCard(o){const u=o.user||o.customer||{},ship=orderShipping(o);return `<article class="item"><div class="item-top"><div><h3>سفارش #${fa(o.orderNumber||o.number||0)}</h3><div class="item-meta"><span>${esc(customerName(u))}</span><span>${esc(u.mobile||'—')}</span><span>${dateFa(o.createdAt)}</span>${ship.trackingCode?`<span>رهگیری: ${esc(ship.trackingCode)}</span>`:''}</div></div>${statusBadge(o.status)}</div><div class="item-actions"><span class="money">${money(o.finalTotal??o.total??0)}</span><button class="btn small" data-order="${esc(orderId(o))}">جزئیات و اقدام</button></div></article>`}
  async function openOrder(base){
    if(!base)return;openModal(`سفارش #${fa(base.orderNumber||base.number||0)}`,'<div class="loading"><div class="spinner"></div><span>در حال دریافت جزئیات…</span></div>');
    try{
      const id=orderId(base),detail=await api.order(id),o=detail?.data||detail||base;const timelinePayload=await api.orderTimeline(id);const addr=orderAddress(o),ship=orderShipping(o),pay=orderPayment(o),items=orderItems(o),u=o.user||o.customer||{};const nexts=orderTransitions[o.status]||[];
      const itemHtml=items.length?items.map(i=>`<div class="order-line"><div><b>${esc(i.productName||i.product?.name||i.name||'محصول')}</b><small>${esc(i.variantTitle||i.variant?.title||i.sku||'')}</small></div><div><b>${fa(i.quantity||1)} × ${money(i.unitPrice??i.price??0)}</b><small>${money(i.total??((i.quantity||1)*(i.unitPrice??i.price??0)))}</small></div></div>`).join(''):'<div class="empty compact">آیتم‌های سفارش در پاسخ موجود نیست.</div>';
      const shippingEditable=!['DELIVERED','CANCELLED','RETURNED','REFUNDED'].includes(o.status);
      $('#modal-root .modal').innerHTML=`<div class="modal-head"><h2>سفارش #${fa(o.orderNumber||o.number||0)}</h2><button class="modal-close" id="modal-close">×</button></div>
      <div class="kv"><div>وضعیت</div><div>${statusBadge(o.status)}</div><div>مشتری</div><div>${esc(customerName(u))} · ${esc(u.mobile||'—')}</div><div>مبلغ نهایی</div><div class="money">${money(o.finalTotal??o.total??0)}</div><div>ثبت</div><div>${dateFa(o.createdAt)}</div><div>گیرنده</div><div>${esc(addr.recipientName||customerName(u)||'—')}</div><div>آدرس</div><div>${esc([addr.province,addr.city,addr.addressLine||addr.address].filter(Boolean).join('، ')||'—')}</div><div>پرداخت</div><div>${pay?statusBadge(pay.status):'—'}</div></div>
      <div class="divider"></div><div class="section-title"><h3>اقلام سفارش</h3><span class="subtle">${fa(items.length)} مورد</span></div><div class="order-lines">${itemHtml}</div>
      <div class="divider"></div><div class="section-title"><h3>ارسال</h3>${can(P.ORDERS_SHIPPING)&&shippingEditable?'<button class="btn small" id="shipping-edit">ثبت / ویرایش ارسال</button>':''}</div><div class="kv shipping-kv"><div>روش</div><div>${esc(ship.title||ship.method||ship.carrier||'—')}</div><div>شرکت / پست</div><div>${esc(ship.carrier||'—')}</div><div>کد رهگیری</div><div class="ltr-value">${esc(ship.trackingCode||'—')}</div><div>هزینه ارسال</div><div>${money(ship.cost??ship.shippingCost??o.shippingCost??0)}</div><div>تاریخ ارسال</div><div>${dateFa(ship.shippedAt||o.shippedAt)}</div></div>
      ${nexts.length&&can(P.ORDERS_UPDATE)?`<div class="divider"></div><label class="field"><span>اقدام بعدی سفارش</span><select id="order-next">${nexts.filter(x=>x!=='CANCELLED').map(x=>`<option value="${x}">${statusFa[x]||x}</option>`).join('')}</select></label>${nexts.some(x=>x!=='CANCELLED')?'<button class="btn primary full" id="order-update">ثبت وضعیت جدید</button>':''}`:''}
      ${can(P.ORDERS_CANCEL)&&!['SHIPPED','DELIVERED','CANCELLED','RETURNED','REFUNDED'].includes(o.status)?'<button class="btn danger full order-cancel-btn" id="order-cancel">لغو سفارش</button>':''}
      <div class="divider"></div><h3 class="modal-section-heading">تاریخچه سفارش</h3>${timelineHtml(timelineRows(timelinePayload,o))}`;
      $('#modal-close').addEventListener('click',closeModal);
      $('#order-update')?.addEventListener('click',async()=>{if(!requirePermission(P.ORDERS_UPDATE))return;const next=$('#order-next').value;if(!next)return;if(!confirm(`وضعیت به «${statusFa[next]||next}» تغییر کند؟`))return;try{await api.updateOrderStatus(id,next);toast('وضعیت سفارش تغییر کرد.');closeModal();cache.orders=[];cache.payments=[];loadOrders(true)}catch(e){toast(errorFa(e.code||e.message),'error')}});
      $('#shipping-edit')?.addEventListener('click',()=>openShippingModal(o));
      $('#order-cancel')?.addEventListener('click',()=>openCancelOrderModal(o));
    }catch(e){toast(errorFa(e.code||e.message),'error');closeModal()}
  }
  function openShippingModal(o){
    if(!requirePermission(P.ORDERS_SHIPPING))return;const id=orderId(o),ship=orderShipping(o);openModal('اطلاعات ارسال',`<form id="shipping-form"><label class="field"><span>روش / شرکت ارسال</span><input id="ship-carrier" value="${esc(ship.carrier||ship.title||'')}" placeholder="مثلاً پست پیشتاز"></label><label class="field"><span>کد رهگیری</span><input id="ship-code" class="ltr-value" value="${esc(ship.trackingCode||'')}" placeholder="Tracking code"></label><label class="field"><span>هزینه ارسال</span><input id="ship-cost" type="number" min="0" value="${Number(ship.cost??ship.shippingCost??o.shippingCost??0)}"></label><label class="field"><span>یادداشت ارسال</span><textarea id="ship-note" placeholder="اختیاری">${esc(ship.note||'')}</textarea></label><button class="btn primary full">ثبت اطلاعات ارسال</button></form>`);$('#shipping-form').addEventListener('submit',async e=>{e.preventDefault();const data={carrier:$('#ship-carrier').value.trim(),trackingCode:$('#ship-code').value.trim(),shippingCost:Number($('#ship-cost').value||0),note:$('#ship-note').value.trim()};if(!data.carrier&&!data.trackingCode)return toast('حداقل روش ارسال یا کد رهگیری را وارد کنید.','error');try{await api.updateShipping(id,data);toast('اطلاعات ارسال ثبت شد.');closeModal();cache.orders=[];loadOrders(true)}catch(e){toast(errorFa(e.code||e.message),'error')}})}
  function openCancelOrderModal(o){
    if(!requirePermission(P.ORDERS_CANCEL))return;openModal('لغو سفارش',`<div class="notice warn">لغو فقط برای سفارش ارسال‌نشده انجام شود. بعد از ارسال باید از مسیر مرجوعی استفاده شود.</div><form id="cancel-order-form" style="margin-top:12px"><label class="field"><span>دلیل لغو</span><textarea id="cancel-reason" required placeholder="مثلاً درخواست مشتری"></textarea></label><label class="field"><span>یادداشت مدیر</span><textarea id="cancel-note" placeholder="اختیاری"></textarea></label><button class="btn danger full">تأیید لغو سفارش</button></form>`);$('#cancel-order-form').addEventListener('submit',async e=>{e.preventDefault();const reason=$('#cancel-reason').value.trim(),note=$('#cancel-note').value.trim();if(reason.length<3)return toast('دلیل لغو را کامل وارد کنید.','error');if(!confirm('این سفارش لغو شود؟'))return;try{await api.cancelOrder(orderId(o),{reason,note});toast('سفارش لغو شد.');closeModal();cache.orders=[];cache.payments=[];loadOrders(true)}catch(e){toast(errorFa(e.code||e.message),'error')}})}

  async function loadPayments(force=false){
    loading('پرداخت‌ها');try{const payload=await api.payments({search:paymentViewState.search,status:paymentViewState.status,limit:100});const parsed=listPayload(payload,['payments']);cache.payments=parsed.items;renderPayments(cache.payments,parsed.meta)}catch(e){pageError(e)}
  }
  function renderPayments(rows,meta=null){
    const states=['REVIEW','PENDING_REVIEW','APPROVED','NEEDS_RESUBMISSION','REJECTED','PARTIALLY_REFUNDED','REFUNDED','FAILED'];
    $('#content').innerHTML=head('پرداخت‌ها','بررسی رسید، درخواست ارسال مجدد و بازپرداخت')+`<div class="toolbar"><input class="search" id="pay-q" value="${esc(paymentViewState.search)}" placeholder="شماره سفارش، موبایل یا پیگیری"><select class="select" id="pay-state"><option value="all">همه</option>${states.map(s=>`<option value="${s}">${statusFa[s]}</option>`).join('')}</select></div><div class="list" id="payments-list"></div>`;$('#pay-state').value=paymentViewState.status;
    const draw=()=>{const st=$('#pay-state').value,q=$('#pay-q').value.trim().toLowerCase(),f=rows.filter(p=>(st==='all'||p.status===st)&&(!q||`${p.order?.orderNumber||''} ${p.order?.user?.mobile||p.customer?.mobile||''} ${p.referenceNumber||''}`.toLowerCase().includes(q)));$('#payments-list').innerHTML=f.length?f.map(paymentCard).join(''):'<div class="empty">پرداختی وجود ندارد.</div>';$$('[data-payment]').forEach(b=>b.addEventListener('click',()=>openPayment(f.find(x=>paymentId(x)===b.dataset.payment)||rows.find(x=>paymentId(x)===b.dataset.payment))));};$('#pay-q').addEventListener('input',()=>{paymentViewState.search=$('#pay-q').value;draw()});$('#pay-state').addEventListener('change',()=>{paymentViewState.status=$('#pay-state').value;draw()});draw();
  }
  function paymentCard(p){const order=p.order||{},u=order.user||p.customer||{};return `<article class="item"><div class="item-top"><div><h3>سفارش #${fa(order.orderNumber||p.orderNumber||0)}</h3><div class="item-meta"><span>${esc(u.mobile||'—')}</span><span>${esc(p.referenceNumber||'بدون شماره پیگیری')}</span><span>${dateFa(p.submittedAt||p.createdAt)}</span></div></div>${statusBadge(p.status)}</div><div class="item-actions"><span class="money">${money(p.amount)}</span><button class="btn small" data-payment="${esc(paymentId(p))}">جزئیات</button></div></article>`}
  async function openPayment(base){
    if(!base)return;openModal('جزئیات پرداخت','<div class="loading"><div class="spinner"></div><span>در حال دریافت…</span></div>');try{const id=paymentId(base),detail=await api.payment(id),p=detail?.data||detail||base,historyPayload=await api.paymentHistory(id),order=p.order||{},u=order.user||p.customer||{};const reviewable=['REVIEW','PENDING_REVIEW'].includes(p.status),refundable=['APPROVED','PAID','PARTIALLY_REFUNDED'].includes(p.status)&&Number(p.refundableAmount??p.amount??0)>0;
      $('#modal-root .modal').innerHTML=`<div class="modal-head"><h2>پرداخت سفارش #${fa(order.orderNumber||p.orderNumber||0)}</h2><button class="modal-close" id="modal-close">×</button></div><div class="kv"><div>وضعیت</div><div>${statusBadge(p.status)}</div><div>مشتری</div><div>${esc(customerName(u))} · ${esc(u.mobile||'—')}</div><div>مبلغ</div><div class="money">${money(p.amount)}</div><div>بازپرداخت‌شده</div><div>${money(p.refundedAmount||0)}</div><div>قابل بازپرداخت</div><div>${money(p.refundableAmount??Math.max(0,Number(p.amount||0)-Number(p.refundedAmount||0)))}</div><div>شماره پیگیری</div><div class="ltr-value">${esc(p.referenceNumber||'—')}</div><div>ثبت رسید</div><div>${dateFa(p.submittedAt||p.createdAt)}</div>${p.rejectReason?`<div>علت رد</div><div>${esc(p.rejectReason)}</div>`:''}</div><div class="divider"></div><div class="item-actions"><button class="btn ghost" id="receipt">مشاهده رسید</button>${reviewable&&can(P.PAYMENTS_REVIEW)?'<button class="btn primary" id="approve">تأیید پرداخت</button><button class="btn" id="resubmit">ارسال مجدد رسید</button><button class="btn danger" id="reject">رد نهایی</button>':''}${refundable&&can(P.PAYMENTS_REFUND)?'<button class="btn danger" id="refund">بازپرداخت</button>':''}</div><div class="divider"></div><h3 class="modal-section-heading">تاریخچه پرداخت</h3>${timelineHtml(timelineRows(historyPayload,p))}`;
      $('#modal-close').addEventListener('click',closeModal);$('#receipt').addEventListener('click',async()=>{try{const r=await api.receiptUrl(id);openUrl(typeof r==='string'?r:r?.url)}catch(e){toast(errorFa(e.code||e.message),'error')}});
      $('#approve')?.addEventListener('click',async()=>{if(!requirePermission(P.PAYMENTS_REVIEW))return;if(!confirm('پرداخت تأیید شود؟ در صورت Pending بودن سفارش، Backend می‌تواند آن را Confirm کند.'))return;try{await api.approvePayment(id);toast('پرداخت تأیید شد.');closeModal();cache.payments=[];cache.orders=[];loadPayments(true)}catch(e){toast(errorFa(e.code||e.message),'error')}});
      $('#resubmit')?.addEventListener('click',()=>paymentDecisionModal(p,'resubmit'));$('#reject')?.addEventListener('click',()=>paymentDecisionModal(p,'reject'));$('#refund')?.addEventListener('click',()=>refundPaymentModal(p));
    }catch(e){toast(errorFa(e.code||e.message),'error');closeModal()}
  }
  function paymentDecisionModal(p,mode){
    if(!requirePermission(P.PAYMENTS_REVIEW))return;const resubmit=mode==='resubmit';openModal(resubmit?'درخواست ارسال مجدد رسید':'رد پرداخت',`<p class="subtle">${resubmit?'دلیل برای مشتری نمایش داده می‌شود تا رسید اصلاح‌شده ارسال کند.':'رد نهایی پرداخت نیازمند دلیل است.'}</p><form id="payment-decision-form"><label class="field"><span>دلیل</span><textarea id="payment-reason" placeholder="دلیل را بنویسید" required></textarea></label><button class="btn ${resubmit?'primary':'danger'} full">${resubmit?'درخواست ارسال مجدد':'ثبت رد پرداخت'}</button></form>`);$('#payment-decision-form').addEventListener('submit',async e=>{e.preventDefault();const reason=$('#payment-reason').value.trim();if(reason.length<3)return toast('دلیل را وارد کنید.','error');try{if(resubmit)await api.requestPaymentResubmission(paymentId(p),reason);else await api.rejectPayment(paymentId(p),reason);toast(resubmit?'درخواست ارسال مجدد ثبت شد.':'پرداخت رد شد.');closeModal();cache.payments=[];cache.orders=[];loadPayments(true)}catch(e){toast(errorFa(e.code||e.message),'error')}})
  }
  function refundPaymentModal(p){
    if(!requirePermission(P.PAYMENTS_REFUND))return;const max=Math.max(0,Number(p.refundableAmount??Number(p.amount||0)-Number(p.refundedAmount||0)));openModal('بازپرداخت',`<div class="notice warn">حداکثر مبلغ قابل بازپرداخت: ${money(max)}</div><form id="refund-form" style="margin-top:12px"><label class="field"><span>نوع بازپرداخت</span><select id="refund-type"><option value="full">کامل</option><option value="partial">جزئی</option></select></label><label class="field"><span>مبلغ</span><input id="refund-amount" type="number" min="1" max="${max}" value="${max}" required></label><label class="field"><span>دلیل</span><textarea id="refund-reason" required placeholder="دلیل بازپرداخت"></textarea></label><label class="field"><span>یادداشت مدیر</span><textarea id="refund-note" placeholder="اختیاری"></textarea></label><button class="btn danger full">ثبت بازپرداخت</button></form>`);const sync=()=>{if($('#refund-type').value==='full'){$('#refund-amount').value=max;$('#refund-amount').disabled=true}else $('#refund-amount').disabled=false};$('#refund-type').addEventListener('change',sync);sync();$('#refund-form').addEventListener('submit',async e=>{e.preventDefault();const type=$('#refund-type').value,amount=type==='full'?max:Number($('#refund-amount').value||0),reason=$('#refund-reason').value.trim(),note=$('#refund-note').value.trim();if(amount<=0||amount>max)return toast('مبلغ بازپرداخت معتبر نیست.','error');if(reason.length<3)return toast('دلیل بازپرداخت را وارد کنید.','error');if(!confirm(`${money(amount)} بازپرداخت شود؟`))return;try{await api.refundPayment(paymentId(p),{type,amount,reason,note});toast('بازپرداخت ثبت شد.');closeModal();cache.payments=[];cache.orders=[];loadPayments(true)}catch(e){toast(errorFa(e.code||e.message),'error')}})
  }

  function deriveCustomersFromOrders(rows=[]){const map=new Map();rows.forEach(o=>{const u=o.user||o.customer||{};const k=customerId(u)||u.mobile;if(!k)return;const x=map.get(k)||{...u,id:customerId(u)||k,ordersCount:0,totalSpent:0,lastOrderAt:null,_compat:true};x.ordersCount++;if(['CONFIRMED','PAID','PROCESSING','PREPARING','SHIPPED','DELIVERED'].includes(o.status))x.totalSpent+=Number(o.finalTotal||o.total||0);if(!x.lastOrderAt||new Date(o.createdAt)>new Date(x.lastOrderAt))x.lastOrderAt=o.createdAt;map.set(k,x)});return [...map.values()]}
  async function loadCustomers(force=false){
    loading('مشتریان');try{let payload=await api.customers({page:customerViewState.page,limit:customerViewState.limit,search:customerViewState.search,status:customerViewState.status});let compat=false,parsed;if(payload===null){compat=true;const ordersPayload=await api.orders({limit:200});const orders=listPayload(ordersPayload,['orders']).items;cache.orders=orders;parsed={items:deriveCustomersFromOrders(orders),meta:null}}else parsed=listPayload(payload,['customers','users']);cache.customers=parsed.items;cache.customerMeta=parsed.meta;renderCustomers(parsed.items,parsed.meta,compat)}catch(e){pageError(e)}
  }
  function renderCustomers(rows,meta=null,compat=false){
    $('#content').innerHTML=head('مشتریان','پروفایل، سفارش‌ها، پرداخت‌ها و وضعیت حساب')+`${compat?'<div class="notice warn" style="margin-bottom:12px">Endpoint مشتریان در بک‌اند پاسخ نداد؛ نمایش سازگاری موقت از روی سفارش‌ها فعال است.</div>':''}<div class="toolbar"><input class="search" id="customer-q" value="${esc(customerViewState.search)}" placeholder="نام یا موبایل"><select class="select" id="customer-state"><option value="all">همه وضعیت‌ها</option><option value="ACTIVE">فعال</option><option value="INACTIVE">غیرفعال</option><option value="BLOCKED">مسدود</option></select></div><div class="list" id="customers-list"></div>`;$('#customer-state').value=customerViewState.status;
    const draw=()=>{const q=$('#customer-q').value.trim().toLowerCase(),st=$('#customer-state').value,f=rows.filter(c=>(!q||`${c.mobile||''} ${customerName(c)}`.toLowerCase().includes(q))&&(st==='all'||String(c.status||'ACTIVE').toUpperCase()===st));$('#customers-list').innerHTML=f.length?f.map(customerCard).join(''):'<div class="empty">مشتری پیدا نشد.</div>';$$('[data-customer]').forEach(b=>b.addEventListener('click',()=>openCustomer(f.find(c=>customerId(c)===b.dataset.customer)||rows.find(c=>customerId(c)===b.dataset.customer))));};$('#customer-q').addEventListener('input',()=>{customerViewState.search=$('#customer-q').value;draw()});$('#customer-state').addEventListener('change',()=>{customerViewState.status=$('#customer-state').value;draw()});draw();
  }
  function customerCard(c){const orders=Number(c.ordersCount??c.orderCount??c.orders?.length??0),total=Number(c.totalSpent??c.totalPurchase??c.lifetimeValue??0);return `<article class="item"><div class="item-top"><div><h3>${esc(customerName(c))}</h3><div class="item-meta"><span>${esc(c.mobile||'—')}</span><span>${fa(orders)} سفارش</span><span>آخرین: ${dateFa(c.lastOrderAt||c.lastOrder?.createdAt||c.updatedAt)}</span></div></div>${statusBadge(String(c.status||'ACTIVE').toUpperCase())}</div><div class="item-actions"><span class="money">${money(total)}</span><button class="btn small" data-customer="${esc(customerId(c))}">پروفایل</button></div></article>`}
  async function openCustomer(base){
    if(!base)return;openModal('پروفایل مشتری','<div class="loading"><div class="spinner"></div><span>در حال دریافت…</span></div>');try{const id=customerId(base),detail=id?await api.customer(id):null,c=detail?.data||detail||base;let ordersPayload=id?await api.customerOrders(id):null,paymentsPayload=id?await api.customerPayments(id):null;let orders=listPayload(ordersPayload||{},['orders']).items,payments=listPayload(paymentsPayload||{},['payments']).items;if(!orders.length&&cache.orders.length)orders=cache.orders.filter(o=>customerId(o.user||o.customer||{})===id||(o.user?.mobile||o.customer?.mobile)===c.mobile);if(!payments.length&&cache.payments.length)payments=cache.payments.filter(p=>customerId(p.customer||p.order?.user||{})===id||(p.customer?.mobile||p.order?.user?.mobile)===c.mobile);const addresses=Array.isArray(c.addresses)?c.addresses:(c.address?[c.address]:[]),status=String(c.status||'ACTIVE').toUpperCase(),total=Number(c.totalSpent??c.totalPurchase??orders.filter(o=>['CONFIRMED','PAID','PROCESSING','PREPARING','SHIPPED','DELIVERED'].includes(o.status)).reduce((a,o)=>a+Number(o.finalTotal||o.total||0),0));
      $('#modal-root .modal').innerHTML=`<div class="modal-head"><h2>${esc(customerName(c))}</h2><button class="modal-close" id="modal-close">×</button></div><div class="customer-summary"><div class="metric"><span>مجموع خرید</span><b>${money(total)}</b></div><div class="metric"><span>سفارش‌ها</span><b>${fa(c.ordersCount??orders.length)}</b></div></div><div class="kv"><div>موبایل</div><div class="ltr-value">${esc(c.mobile||'—')}</div><div>ایمیل</div><div>${esc(c.email||'—')}</div><div>عضویت</div><div>${dateFa(c.createdAt||c.registeredAt)}</div><div>وضعیت</div><div>${statusBadge(status)}</div></div>${can(P.CUSTOMERS_UPDATE)?`<div class="divider"></div><label class="field"><span>وضعیت حساب</span><select id="customer-status"><option value="ACTIVE">فعال</option><option value="INACTIVE">غیرفعال</option><option value="BLOCKED">مسدود</option></select></label><button class="btn small" id="customer-status-save">ثبت وضعیت</button><label class="field" style="margin-top:10px"><span>یادداشت مدیر</span><textarea id="customer-note" placeholder="یادداشت پشتیبانی">${esc(c.adminNote||'')}</textarea></label><button class="btn small ghost" id="customer-note-save">ذخیره یادداشت</button>`:''}<div class="divider"></div><h3 class="modal-section-heading">آدرس‌ها</h3>${addresses.length?addresses.map(a=>`<div class="address-box"><b>${esc(a.title||a.recipientName||'آدرس')}</b><span>${esc([a.province,a.city,a.addressLine||a.address].filter(Boolean).join('، '))}</span><small>${esc(a.postalCode||'')}</small></div>`).join(''):'<div class="empty compact">آدرسی در پاسخ موجود نیست.</div>'}<div class="divider"></div><h3 class="modal-section-heading">سفارش‌های اخیر</h3>${orders.length?orders.slice(0,8).map(o=>`<div class="mini-record"><span>سفارش #${fa(o.orderNumber||o.number||0)}</span>${statusBadge(o.status)}<b>${money(o.finalTotal??o.total??0)}</b></div>`).join(''):'<div class="empty compact">سفارشی ثبت نشده است.</div>'}<div class="divider"></div><h3 class="modal-section-heading">پرداخت‌های اخیر</h3>${payments.length?payments.slice(0,8).map(p=>`<div class="mini-record"><span>${dateFa(p.createdAt||p.submittedAt)}</span>${statusBadge(p.status)}<b>${money(p.amount)}</b></div>`).join(''):'<div class="empty compact">پرداختی ثبت نشده است.</div>'}`;
      $('#modal-close').addEventListener('click',closeModal);if($('#customer-status'))$('#customer-status').value=status;$('#customer-status-save')?.addEventListener('click',async()=>{if(!requirePermission(P.CUSTOMERS_UPDATE))return;const next=$('#customer-status').value;if(next===status)return toast('وضعیت تغییری نکرده است.');if(!confirm(`وضعیت مشتری به «${statusFa[next]}» تغییر کند؟`))return;try{await api.updateCustomerStatus(id,next);toast('وضعیت مشتری به‌روزرسانی شد.');closeModal();cache.customers=[];loadCustomers(true)}catch(e){toast(errorFa(e.code||e.message),'error')}});$('#customer-note-save')?.addEventListener('click',async()=>{if(!requirePermission(P.CUSTOMERS_UPDATE))return;const note=$('#customer-note').value.trim();try{const r=await api.addCustomerNote(id,note);if(r===null)toast('Endpoint یادداشت مشتری در بک‌اند فعال نیست.','error');else toast('یادداشت ذخیره شد.')}catch(e){toast(errorFa(e.code||e.message),'error')}})
    }catch(e){toast(errorFa(e.code||e.message),'error');closeModal()}
  }


  // Step 8 — Marketing & Content
  const marketingState={tab:'coupons'};
  const marketingTabs=[['coupons','کد تخفیف'],['reviews','نظرات'],['banners','بنرها'],['campaigns','کمپین‌ها']];
  const marketingId=x=>String(x?.id??x?._id??x?.serverId??'');
  const marketingList=(payload,key)=>listPayload(payload||{},[key]).items;
  async function loadMarketing(force=false){
    loading('بازاریابی و محتوا');
    try{
      if(force||!cache.marketing){
        const [coupons,reviews,banners,campaigns]=await Promise.all([api.coupons({limit:100}),api.reviews({limit:100}),api.banners({limit:100}),api.campaigns({limit:100})]);
        cache.marketing={coupons:marketingList(coupons,'coupons'),reviews:marketingList(reviews,'reviews'),banners:marketingList(banners,'banners'),campaigns:marketingList(campaigns,'campaigns'),available:{coupons:coupons!==null,reviews:reviews!==null,banners:banners!==null,campaigns:campaigns!==null}};
      }
      renderMarketing();
    }catch(e){pageError(e)}
  }
  function unavailableModule(label){return `<div class="empty module-unavailable">${esc(label)} در نسخه فعلی بک‌اند Endpoint فعال ندارد.</div>`}
  function renderMarketing(){
    const m=cache.marketing||{coupons:[],reviews:[],banners:[],campaigns:[],available:{}};
    $('#content').innerHTML=head('بازاریابی و محتوا','تخفیف، نظرات، بنر و کمپین')+`<div class="segmented">${marketingTabs.map(([id,label])=>`<button class="${marketingState.tab===id?'active':''}" data-marketing-tab="${id}">${label}</button>`).join('')}</div><div id="marketing-content"></div>`;
    $$('[data-marketing-tab]').forEach(b=>b.addEventListener('click',()=>{marketingState.tab=b.dataset.marketingTab;renderMarketing()}));
    const host=$('#marketing-content');
    if(marketingState.tab==='coupons'){
      host.innerHTML=`${can(P.MARKETING_MANAGE)?`<div class="toolbar end"><button class="btn primary small" id="new-coupon">＋ کد تخفیف</button></div>`:''}${!m.available.coupons?unavailableModule('کدهای تخفیف'):`<div class="list">${m.coupons.length?m.coupons.map(c=>couponCard(c)).join(''):'<div class="empty">کد تخفیفی ثبت نشده است.</div>'}</div>`}`;
      $('#new-coupon')?.addEventListener('click',()=>openCouponModal());$$('[data-edit-coupon]').forEach(b=>b.addEventListener('click',()=>openCouponModal(m.coupons.find(x=>marketingId(x)===b.dataset.editCoupon))));$$('[data-delete-coupon]').forEach(b=>b.addEventListener('click',()=>deleteCouponAction(b,m.coupons.find(x=>marketingId(x)===b.dataset.deleteCoupon))));
    }else if(marketingState.tab==='reviews'){
      host.innerHTML=!m.available.reviews?unavailableModule('نظرات'):`<div class="list">${m.reviews.length?m.reviews.map(reviewCard).join(''):'<div class="empty">نظری برای بررسی وجود ندارد.</div>'}</div>`;
      $$('[data-review-status]').forEach(b=>b.addEventListener('click',()=>reviewStatusAction(b,m.reviews.find(x=>marketingId(x)===b.dataset.reviewId),b.dataset.reviewStatus)));$$('[data-delete-review]').forEach(b=>b.addEventListener('click',()=>deleteReviewAction(b,m.reviews.find(x=>marketingId(x)===b.dataset.deleteReview))));
    }else if(marketingState.tab==='banners'){
      host.innerHTML=`${can(P.BANNERS_MANAGE)?`<div class="toolbar end"><button class="btn primary small" id="new-banner">＋ بنر</button></div>`:''}${!m.available.banners?unavailableModule('بنرها'):`<div class="list">${m.banners.length?m.banners.map(bannerCard).join(''):'<div class="empty">بنری ثبت نشده است.</div>'}</div>`}`;
      $('#new-banner')?.addEventListener('click',()=>openBannerModal());$$('[data-edit-banner]').forEach(b=>b.addEventListener('click',()=>openBannerModal(m.banners.find(x=>marketingId(x)===b.dataset.editBanner))));$$('[data-delete-banner]').forEach(b=>b.addEventListener('click',()=>deleteBannerAction(b,m.banners.find(x=>marketingId(x)===b.dataset.deleteBanner))));
    }else{
      host.innerHTML=`${can(P.MARKETING_MANAGE)?`<div class="toolbar end"><button class="btn primary small" id="new-campaign">＋ کمپین</button></div>`:''}${!m.available.campaigns?unavailableModule('کمپین‌ها'):`<div class="list">${m.campaigns.length?m.campaigns.map(campaignCard).join(''):'<div class="empty">کمپینی ثبت نشده است.</div>'}</div>`}`;
      $('#new-campaign')?.addEventListener('click',()=>openCampaignModal());$$('[data-edit-campaign]').forEach(b=>b.addEventListener('click',()=>openCampaignModal(m.campaigns.find(x=>marketingId(x)===b.dataset.editCampaign))));$$('[data-delete-campaign]').forEach(b=>b.addEventListener('click',()=>deleteCampaignAction(b,m.campaigns.find(x=>marketingId(x)===b.dataset.deleteCampaign))));
    }
  }
  function couponCard(c){const type=String(c.type||c.discountType||'percentage').toLowerCase(),value=c.value??c.amount??c.percent??0;return `<article class="item"><div class="item-top"><div><h3 class="ltr-value">${esc(c.code||'—')}</h3><div class="item-meta"><span>${type.includes('percent')?`${fa(value)}٪`:money(value)}</span><span>از ${dateFa(c.startsAt||c.startDate)}</span><span>تا ${dateFa(c.expiresAt||c.endDate)}</span></div></div>${statusBadge(c.active===false?'INACTIVE':'ACTIVE')}</div>${can(P.MARKETING_MANAGE)?`<div class="item-actions"><button class="btn small" data-edit-coupon="${esc(marketingId(c))}">ویرایش</button><button class="btn small danger" data-delete-coupon="${esc(marketingId(c))}">حذف</button></div>`:''}</article>`}
  function openCouponModal(c=null){if(!requirePermission(P.MARKETING_MANAGE))return;openModal(c?'ویرایش کد تخفیف':'کد تخفیف جدید',`<form id="coupon-form"><div class="grid2"><label class="field"><span>کد</span><input id="coupon-code" value="${esc(c?.code||'')}" required></label><label class="field"><span>نوع</span><select id="coupon-type"><option value="percentage">درصدی</option><option value="fixed">مبلغ ثابت</option></select></label></div><div class="grid2"><label class="field"><span>مقدار</span><input id="coupon-value" type="number" min="0" value="${esc(c?.value??c?.amount??0)}" required></label><label class="field"><span>حداقل سفارش</span><input id="coupon-min" type="number" min="0" value="${esc(c?.minOrderAmount??0)}"></label></div><div class="grid2"><label class="field"><span>شروع</span><input id="coupon-start" type="datetime-local"></label><label class="field"><span>پایان</span><input id="coupon-end" type="datetime-local"></label></div><label class="field"><span>وضعیت</span><select id="coupon-active"><option value="true">فعال</option><option value="false">غیرفعال</option></select></label><button class="btn primary full" id="coupon-save">ذخیره</button></form>`);$('#coupon-type').value=String(c?.type||c?.discountType||'percentage').toLowerCase();$('#coupon-active').value=String(c?.active!==false);$('#coupon-form').addEventListener('submit',async e=>{e.preventDefault();const btn=$('#coupon-save'),data={code:$('#coupon-code').value.trim().toUpperCase(),type:$('#coupon-type').value,value:Number($('#coupon-value').value||0),minOrderAmount:Number($('#coupon-min').value||0),startsAt:$('#coupon-start').value||undefined,expiresAt:$('#coupon-end').value||undefined,active:$('#coupon-active').value==='true'};try{await runBusy(btn,()=>c?api.updateCoupon(marketingId(c),data):api.createCoupon(data));toast('کد تخفیف ذخیره شد.');closeModal();cache.marketing=null;loadMarketing(true)}catch(err){toast(errorFa(err.code||err.message),'error')}})}
  async function deleteCouponAction(btn,c){if(!requirePermission(P.MARKETING_MANAGE)||!c||!confirm(`کد ${c.code||''} حذف شود؟`))return;try{await runBusy(btn,()=>api.deleteCoupon(marketingId(c)),'حذف…');toast('کد تخفیف حذف شد.');cache.marketing=null;loadMarketing(true)}catch(e){toast(errorFa(e.code||e.message),'error')}}
  function reviewCard(r){const st=String(r.status||'PENDING_REVIEW').toUpperCase();return `<article class="item"><div class="item-top"><div><h3>${esc(r.product?.name||r.productName||'نظر محصول')}</h3><div class="item-meta"><span>${esc(r.customer?.displayName||r.user?.displayName||r.customerName||'کاربر')}</span><span>امتیاز ${fa(r.rating||0)}/۵</span><span>${dateFa(r.createdAt)}</span></div></div>${statusBadge(st)}</div><p class="review-text">${esc(r.comment||r.text||'')}</p>${can(P.REVIEWS_MANAGE)?`<div class="item-actions"><button class="btn small" data-review-id="${esc(marketingId(r))}" data-review-status="APPROVED">تأیید</button><button class="btn small ghost" data-review-id="${esc(marketingId(r))}" data-review-status="REJECTED">رد</button><button class="btn small danger" data-delete-review="${esc(marketingId(r))}">حذف</button></div>`:''}</article>`}
  async function reviewStatusAction(btn,r,status){if(!requirePermission(P.REVIEWS_MANAGE)||!r)return;try{await runBusy(btn,()=>api.updateReviewStatus(marketingId(r),status));toast('وضعیت نظر به‌روزرسانی شد.');cache.marketing=null;loadMarketing(true)}catch(e){toast(errorFa(e.code||e.message),'error')}}
  async function deleteReviewAction(btn,r){if(!requirePermission(P.REVIEWS_MANAGE)||!r||!confirm('این نظر حذف شود؟'))return;try{await runBusy(btn,()=>api.deleteReview(marketingId(r)),'حذف…');toast('نظر حذف شد.');cache.marketing=null;loadMarketing(true)}catch(e){toast(errorFa(e.code||e.message),'error')}}
  function bannerCard(b){const img=absoluteAssetUrl(b.imageMobile||b.image||b.imageUrl||'');return `<article class="item"><div class="product-row">${img?`<img class="product-thumb" src="${esc(img)}">`:'<div class="product-thumb placeholder">▧</div>'}<div class="product-grow"><div class="item-top"><div><h3>${esc(b.title||'بنر')}</h3><div class="item-meta"><span>${esc(b.position||'home')}</span><span>${dateFa(b.startsAt)}</span></div></div>${statusBadge(b.active===false?'INACTIVE':'ACTIVE')}</div>${can(P.BANNERS_MANAGE)?`<div class="item-actions"><button class="btn small" data-edit-banner="${esc(marketingId(b))}">ویرایش</button><button class="btn small danger" data-delete-banner="${esc(marketingId(b))}">حذف</button></div>`:''}</div></div></article>`}
  function openBannerModal(b=null){if(!requirePermission(P.BANNERS_MANAGE))return;openModal(b?'ویرایش بنر':'بنر جدید',`<form id="banner-form"><label class="field"><span>عنوان</span><input id="banner-title" value="${esc(b?.title||'')}" required></label><label class="field"><span>آدرس تصویر</span><input id="banner-image" class="ltr-value" value="${esc(b?.imageMobile||b?.image||b?.imageUrl||'')}" placeholder="https://..."></label><label class="field"><span>لینک مقصد</span><input id="banner-link" class="ltr-value" value="${esc(b?.link||b?.url||'')}"></label><div class="grid2"><label class="field"><span>جایگاه</span><input id="banner-position" value="${esc(b?.position||'home')}" ></label><label class="field"><span>ترتیب</span><input id="banner-order" type="number" value="${esc(b?.sortOrder??0)}"></label></div><label class="field"><span>وضعیت</span><select id="banner-active"><option value="true">فعال</option><option value="false">غیرفعال</option></select></label><button class="btn primary full" id="banner-save">ذخیره</button></form>`);$('#banner-active').value=String(b?.active!==false);$('#banner-form').addEventListener('submit',async e=>{e.preventDefault();const btn=$('#banner-save'),data={title:$('#banner-title').value.trim(),image:$('#banner-image').value.trim(),link:$('#banner-link').value.trim(),position:$('#banner-position').value.trim(),sortOrder:Number($('#banner-order').value||0),active:$('#banner-active').value==='true'};try{await runBusy(btn,()=>b?api.updateBanner(marketingId(b),data):api.createBanner(data));toast('بنر ذخیره شد.');closeModal();cache.marketing=null;loadMarketing(true)}catch(err){toast(errorFa(err.code||err.message),'error')}})}
  async function deleteBannerAction(btn,b){if(!requirePermission(P.BANNERS_MANAGE)||!b||!confirm('بنر حذف شود؟'))return;try{await runBusy(btn,()=>api.deleteBanner(marketingId(b)),'حذف…');toast('بنر حذف شد.');cache.marketing=null;loadMarketing(true)}catch(e){toast(errorFa(e.code||e.message),'error')}}
  function campaignCard(c){return `<article class="item"><div class="item-top"><div><h3>${esc(c.name||c.title||'کمپین')}</h3><div class="item-meta"><span>${dateFa(c.startsAt||c.startDate)}</span><span>تا ${dateFa(c.endsAt||c.endDate)}</span><span>${fa(c.discountPercent||c.discount||0)}٪</span></div></div>${statusBadge(c.active===false?'INACTIVE':'ACTIVE')}</div>${can(P.MARKETING_MANAGE)?`<div class="item-actions"><button class="btn small" data-edit-campaign="${esc(marketingId(c))}">ویرایش</button><button class="btn small danger" data-delete-campaign="${esc(marketingId(c))}">حذف</button></div>`:''}</article>`}
  function openCampaignModal(c=null){if(!requirePermission(P.MARKETING_MANAGE))return;openModal(c?'ویرایش کمپین':'کمپین جدید',`<form id="campaign-form"><label class="field"><span>نام کمپین</span><input id="campaign-name" value="${esc(c?.name||c?.title||'')}" required></label><div class="grid2"><label class="field"><span>تخفیف درصدی</span><input id="campaign-discount" type="number" min="0" max="100" value="${esc(c?.discountPercent??c?.discount??0)}"></label><label class="field"><span>وضعیت</span><select id="campaign-active"><option value="true">فعال</option><option value="false">غیرفعال</option></select></label></div><div class="grid2"><label class="field"><span>شروع</span><input id="campaign-start" type="datetime-local"></label><label class="field"><span>پایان</span><input id="campaign-end" type="datetime-local"></label></div><button class="btn primary full" id="campaign-save">ذخیره</button></form>`);$('#campaign-active').value=String(c?.active!==false);$('#campaign-form').addEventListener('submit',async e=>{e.preventDefault();const btn=$('#campaign-save'),data={name:$('#campaign-name').value.trim(),discountPercent:Number($('#campaign-discount').value||0),startsAt:$('#campaign-start').value||undefined,endsAt:$('#campaign-end').value||undefined,active:$('#campaign-active').value==='true'};try{await runBusy(btn,()=>c?api.updateCampaign(marketingId(c),data):api.createCampaign(data));toast('کمپین ذخیره شد.');closeModal();cache.marketing=null;loadMarketing(true)}catch(err){toast(errorFa(err.code||err.message),'error')}})}
  async function deleteCampaignAction(btn,c){if(!requirePermission(P.MARKETING_MANAGE)||!c||!confirm('کمپین حذف شود؟'))return;try{await runBusy(btn,()=>api.deleteCampaign(marketingId(c)),'حذف…');toast('کمپین حذف شد.');cache.marketing=null;loadMarketing(true)}catch(e){toast(errorFa(e.code||e.message),'error')}}

  // Step 9 — Administration, Reports & Settings
  const adminId=x=>String(x?.id??x?._id??x?.serverId??'');
  async function loadAdministration(force=false){loading('مدیران و نقش‌ها');try{if(force||!cache.admins.length){const [admins,roles]=await Promise.all([api.admins({limit:100}),api.roles()]);cache.admins=listPayload(admins||{},['admins','users']).items;cache.roles=listPayload(roles||{},['roles']).items;}renderAdministration()}catch(e){pageError(e)}}
  function renderAdministration(){const admins=cache.admins||[],roles=cache.roles||[];$('#content').innerHTML=head('مدیران و نقش‌ها','کنترل حساب‌های مدیریتی و سطح دسترسی',can(P.ADMINS_MANAGE)?'<button class="btn primary small" id="new-admin">＋ مدیر</button>':'')+`${!admins.length?'<div class="notice">اگر Endpoint مدیران روی بک‌اند فعال نباشد، این بخش خالی نمایش داده می‌شود.</div>':''}<div class="panel"><div class="section-title"><h2>مدیران</h2><span class="subtle">${fa(admins.length)} حساب</span></div><div class="list compact-list">${admins.length?admins.map(a=>adminCard(a,roles)).join(''):'<div class="empty compact">مدیری ثبت نشده یا Endpoint در دسترس نیست.</div>'}</div></div><div class="panel"><div class="section-title"><h2>نقش‌ها</h2>${can(P.ROLES_MANAGE)?'<button class="btn small" id="new-role">＋ نقش</button>':''}</div>${roles.length?roles.map(roleCard).join(''):'<div class="empty compact">نقشی دریافت نشد.</div>'}</div>`;$('#new-admin')?.addEventListener('click',()=>openAdminModal(null,roles));$('#new-role')?.addEventListener('click',()=>openRoleModal());$$('[data-admin-status]').forEach(b=>b.addEventListener('click',()=>toggleAdminStatus(b,admins.find(a=>adminId(a)===b.dataset.adminStatus))));$$('[data-admin-role]').forEach(s=>s.addEventListener('change',()=>changeAdminRole(s,admins.find(a=>adminId(a)===s.dataset.adminRole),s.value)))}
  function adminCard(a,roles){const role=a.role||a.adminRole,status=String(a.status||'ACTIVE').toUpperCase();return `<article class="item"><div class="item-top"><div><h3>${esc(a.displayName||a.name||a.mobile||'مدیر')}</h3><div class="item-meta"><span class="ltr-value">${esc(a.mobile||a.email||'—')}</span><span>${esc(typeof role==='string'?role:(role?.name||role?.title||'بدون نقش'))}</span></div></div>${statusBadge(status)}</div>${can(P.ADMINS_MANAGE)?`<div class="item-actions"><select class="select mini-select" data-admin-role="${esc(adminId(a))}"><option value="">نقش…</option>${roles.map(r=>`<option value="${esc(adminId(r))}" ${adminId(r)===adminId(role)?'selected':''}>${esc(r.name||r.title)}</option>`).join('')}</select><button class="btn small ${status==='ACTIVE'?'danger':'ghost'}" data-admin-status="${esc(adminId(a))}">${status==='ACTIVE'?'غیرفعال':'فعال'}</button></div>`:''}</article>`}
  function roleCard(r){const perms=Array.isArray(r.permissions)?r.permissions:[];return `<div class="role-row"><div><b>${esc(r.name||r.title||'Role')}</b><small>${fa(perms.length)} دسترسی</small></div><div class="permission-list">${perms.slice(0,8).map(p=>`<span>${esc(typeof p==='string'?p:(p.name||p.code||''))}</span>`).join('')}${perms.length>8?`<span>+${fa(perms.length-8)}</span>`:''}</div></div>`}
  function openAdminModal(a=null,roles=[]){if(!requirePermission(P.ADMINS_MANAGE))return;openModal('مدیر جدید',`<form id="admin-form"><label class="field"><span>نام</span><input id="admin-name" required></label><label class="field"><span>موبایل</span><input id="admin-mobile" inputmode="numeric" required></label><label class="field"><span>رمز اولیه</span><input id="admin-password" type="password" minlength="6" required></label><label class="field"><span>نقش</span><select id="admin-role"><option value="">انتخاب نقش</option>${roles.map(r=>`<option value="${esc(adminId(r))}">${esc(r.name||r.title)}</option>`).join('')}</select></label><button class="btn primary full" id="admin-save">ساخت حساب</button></form>`);$('#admin-form').addEventListener('submit',async e=>{e.preventDefault();const btn=$('#admin-save'),data={displayName:$('#admin-name').value.trim(),mobile:$('#admin-mobile').value.trim(),password:$('#admin-password').value,roleId:$('#admin-role').value||undefined};try{await runBusy(btn,()=>api.createAdmin(data));toast('حساب مدیر ساخته شد.');closeModal();cache.admins=[];loadAdministration(true)}catch(err){toast(errorFa(err.code||err.message),'error')}})}
  async function toggleAdminStatus(btn,a){if(!requirePermission(P.ADMINS_MANAGE)||!a)return;const next=String(a.status||'ACTIVE').toUpperCase()==='ACTIVE'?'INACTIVE':'ACTIVE';if(!confirm(`وضعیت این مدیر به ${statusFa[next]} تغییر کند؟`))return;try{await runBusy(btn,()=>api.updateAdmin(adminId(a),{status:next}));toast('وضعیت مدیر به‌روزرسانی شد.');cache.admins=[];loadAdministration(true)}catch(e){toast(errorFa(e.code||e.message),'error')}}
  async function changeAdminRole(select,a,roleId){if(!requirePermission(P.ADMINS_MANAGE)||!a||!roleId)return;try{select.disabled=true;await api.updateAdmin(adminId(a),{roleId});toast('نقش مدیر به‌روزرسانی شد.')}catch(e){toast(errorFa(e.code||e.message),'error')}finally{select.disabled=false}}
  function openRoleModal(){if(!requirePermission(P.ROLES_MANAGE))return;openModal('نقش جدید',`<form id="role-form"><label class="field"><span>نام نقش</span><input id="role-name" required></label><label class="field"><span>Permissionها</span><textarea id="role-permissions" class="ltr-value" placeholder="products.view, orders.view, ..."></textarea></label><p class="subtle">Permissionها را با ویرگول جدا کنید. بک‌اند مرجع نهایی اعتبارسنجی است.</p><button class="btn primary full" id="role-save">ساخت نقش</button></form>`);$('#role-form').addEventListener('submit',async e=>{e.preventDefault();const btn=$('#role-save'),data={name:$('#role-name').value.trim(),permissions:$('#role-permissions').value.split(',').map(x=>x.trim()).filter(Boolean)};try{await runBusy(btn,()=>api.createRole(data));toast('نقش ساخته شد.');closeModal();cache.roles=[];loadAdministration(true)}catch(err){toast(errorFa(err.code||err.message),'error')}})}

  const reportState={period:'30d'};
  async function loadReports(force=false){loading('گزارش‌ها');try{if(force||!cache.reports)cache.reports=await api.reports({period:reportState.period});renderReports(cache.reports)}catch(e){pageError(e)}}
  function reportNumber(obj,keys,def=0){for(const k of keys){if(obj&&obj[k]!==undefined&&obj[k]!==null)return Number(obj[k]||0)}return def}
  function renderReports(payload){const r=payload?.data||payload||{},sales=r.sales||r.revenue||{},orders=r.orders||{},customers=r.customers||{},inventory=r.inventory||{};$('#content').innerHTML=head('گزارش‌ها','فروش، سفارش، مشتری و موجودی')+`<div class="segmented"><button data-report-period="7d" class="${reportState.period==='7d'?'active':''}">۷ روز</button><button data-report-period="30d" class="${reportState.period==='30d'?'active':''}">۳۰ روز</button><button data-report-period="month" class="${reportState.period==='month'?'active':''}">ماه جاری</button></div>${payload===null?unavailableModule('گزارش‌ها'):`<div class="cards report-cards"><div class="metric"><span>فروش</span><b>${money(reportNumber(sales,['total','amount','revenue'],reportNumber(r,['salesTotal','revenueTotal'])))}</b></div><div class="metric"><span>سفارش</span><b>${fa(reportNumber(orders,['total','count'],reportNumber(r,['ordersTotal'])))}</b></div><div class="metric"><span>مشتری جدید</span><b>${fa(reportNumber(customers,['new','newCount'],reportNumber(r,['newCustomers'])))}</b></div><div class="metric"><span>کم‌موجود</span><b>${fa(reportNumber(inventory,['lowStock','low'],reportNumber(r,['lowStock'])))}</b></div></div><div class="panel"><h2>خلاصه عملکرد</h2><div class="kv"><div>میانگین سفارش</div><div>${money(reportNumber(r,['averageOrderValue','avgOrder']))}</div><div>سفارش تحویل‌شده</div><div>${fa(reportNumber(orders,['delivered','completed']))}</div><div>پرداخت بازپرداخت‌شده</div><div>${fa(reportNumber(r,['refundCount','refundedPayments']))}</div><div>محصول ناموجود</div><div>${fa(reportNumber(inventory,['outOfStock','out']))}</div></div></div>`}`;$$('[data-report-period]').forEach(b=>b.addEventListener('click',()=>{reportState.period=b.dataset.reportPeriod;cache.reports=null;loadReports(true)}))}

  async function loadSettings(force=false){loading('تنظیمات فروشگاه');try{if(force||!cache.settings)cache.settings=await api.settings();renderSettings(cache.settings)}catch(e){pageError(e)}}
  function renderSettings(payload){if(payload===null){$('#content').innerHTML=head('تنظیمات فروشگاه','تنظیمات عمومی و مالی')+unavailableModule('تنظیمات فروشگاه');return}const s=payload?.data||payload||{};$('#content').innerHTML=head('تنظیمات فروشگاه','تنظیمات عمومی، مالی و ارسال')+`<form class="panel" id="settings-form"><div class="grid2"><label class="field"><span>نام فروشگاه</span><input id="set-name" value="${esc(s.storeName||s.name||'Store')}"></label><label class="field"><span>موبایل/تلفن</span><input id="set-phone" value="${esc(s.phone||'')}"></label></div><label class="field"><span>ایمیل</span><input id="set-email" type="email" class="ltr-value" value="${esc(s.email||'')}"></label><div class="grid2"><label class="field"><span>واحد پول</span><select id="set-currency"><option value="IRR">ریال</option><option value="IRT">تومان</option></select></label><label class="field"><span>مالیات ٪</span><input id="set-tax" type="number" min="0" value="${esc(s.taxPercent??s.tax??0)}"></label></div><div class="grid2"><label class="field"><span>هشدار کم‌موجودی</span><input id="set-low-stock" type="number" min="0" value="${esc(s.lowStockThreshold??3)}"></label><label class="field"><span>ارسال رایگان از</span><input id="set-free-shipping" type="number" min="0" value="${esc(s.freeShippingThreshold??0)}"></label></div><label class="field"><span>اینستاگرام</span><input id="set-instagram" class="ltr-value" value="${esc(s.social?.instagram||s.instagram||'')}"></label>${can(P.SETTINGS_MANAGE)?'<button class="btn primary full" id="settings-save">ذخیره تنظیمات</button>':'<div class="notice">این حساب فقط اجازه مشاهده تنظیمات را دارد.</div>'}</form>`;$('#set-currency').value=s.currency||'IRR';$('#settings-form').addEventListener('submit',async e=>{e.preventDefault();if(!requirePermission(P.SETTINGS_MANAGE))return;const btn=$('#settings-save'),data={storeName:$('#set-name').value.trim(),phone:$('#set-phone').value.trim(),email:$('#set-email').value.trim(),currency:$('#set-currency').value,taxPercent:Number($('#set-tax').value||0),lowStockThreshold:Number($('#set-low-stock').value||0),freeShippingThreshold:Number($('#set-free-shipping').value||0),social:{instagram:$('#set-instagram').value.trim()}};try{await runBusy(btn,()=>api.updateSettings(data),'در حال ذخیره…');cache.settings=data;toast('تنظیمات ذخیره شد.')}catch(err){toast(errorFa(err.code||err.message),'error')}})}

  // Step 11 — API compatibility diagnostics
  async function loadDiagnostics(force=false){loading('سازگاری API');try{const cap=force||!cache.capabilities?await api.capabilities():cache.capabilities;cache.capabilities=cap;const checks=[...Contract.probePaths,['کد تخفیف','/admin/coupons?limit=1'],['نظرات','/admin/reviews?limit=1'],['بنرها','/admin/banners?limit=1'],['مدیران','/admin/admins?limit=1'],['گزارش‌ها','/admin/reports/summary?period=7d'],['تنظیمات','/admin/settings']];const results=await Promise.all(checks.map(async ([label,path])=>[label,await api.probe(path)]));renderDiagnostics(cap,results)}catch(e){pageError(e)}}
  function renderDiagnostics(cap,results){const badge=x=>x.status==='ok'?'<span class="badge ok">فعال</span>':x.status==='forbidden'?'<span class="badge warn">محدود</span>':x.status==='missing'?'<span class="badge danger">Endpoint ندارد</span>':'<span class="badge danger">خطا</span>';$('#content').innerHTML=head('سازگاری API','بررسی خواندنی Endpointها؛ هیچ داده‌ای تغییر نمی‌کند')+`<div class="panel"><div class="kv"><div>API Host</div><div class="ltr-value">${esc(API_HOST)}</div><div>App Version</div><div>${esc(APP_VERSION)}</div><div>API Contract</div><div class="ltr-value">${esc(Contract.contractVersion)}</div><div>Network</div><div>${networkState()==='online'?'آنلاین':'آفلاین'}</div><div>Capabilities</div><div>${cap?'<span class="health-ok">دریافت شد</span>':'<span class="subtle">Endpoint اختیاری موجود نیست</span>'}</div></div></div><div class="panel"><h2>ماژول‌ها</h2><div class="diagnostic-list">${results.map(([label,r])=>`<div><span>${esc(label)}</span>${badge(r)}</div>`).join('')}</div></div>${cap?`<details class="panel"><summary>پاسخ Capabilities</summary><pre class="csv-help">${esc(JSON.stringify(cap,null,2))}</pre></details>`:''}`}

  function renderImport(){if(!requireAnyPermission([P.CATALOG_IMPORT,P.PRODUCTS_CREATE]))return forbiddenView('import');page='import';$('#content').innerHTML=head('ورود CSV','ورود گروهی محصولات و موجودی')+`<div class="panel"><h2>فایل CSV</h2><p class="subtle">برای واردکردن گروهی محصولات، CSV با ستون‌های زیر انتخاب کنید. ابتدا «بررسی» و سپس «ثبت نهایی» انجام می‌شود.</p><div class="csv-help">name,slug,sku,variantTitle,price,compareAtPrice,stock,brand</div><div style="height:10px"></div><input id="csv-file" type="file" accept=".csv,text/csv"><div id="csv-info" class="subtle" style="margin-top:10px"></div><div class="item-actions"><button class="btn" id="csv-check" disabled>بررسی فایل</button><button class="btn primary" id="csv-commit" disabled>ثبت نهایی</button></div><pre id="csv-result" class="csv-help hidden"></pre></div>`;let rows=[];$('#csv-file').addEventListener('change',async e=>{const f=e.target.files?.[0];if(!f)return;rows=parseCSV(await f.text());$('#csv-info').textContent=`${fa(rows.length)} ردیف خوانده شد.`;$('#csv-check').disabled=!rows.length;$('#csv-commit').disabled=!rows.length});$('#csv-check').addEventListener('click',async()=>{try{const r=await api.importCatalog(rows,true);showImportResult(r)}catch(e){toast(errorFa(e.code||e.message),'error')}});$('#csv-commit').addEventListener('click',async()=>{if(!confirm(`${rows.length} ردیف در دیتابیس ثبت شود؟`))return;try{const r=await api.importCatalog(rows,false);showImportResult(r);cache.products=[];toast('ورود کاتالوگ انجام شد.')}catch(e){toast(errorFa(e.code||e.message),'error')}})}
  function parseCSV(text){const lines=text.replace(/^\uFEFF/,'').split(/\r?\n/).filter(x=>x.trim());if(lines.length<2)return[];const split=line=>{const out=[];let cur='',q=false;for(let i=0;i<line.length;i++){const c=line[i];if(c==='"'){if(q&&line[i+1]==='"'){cur+='"';i++}else q=!q}else if(c===','&&!q){out.push(cur.trim());cur=''}else cur+=c}out.push(cur.trim());return out};const h=split(lines[0]);return lines.slice(1).map(line=>{const v=split(line),o={};h.forEach((k,i)=>o[k]=v[i]??'');return {name:o.name,slug:o.slug,sku:o.sku,variantTitle:o.variantTitle||'اصلی',price:Number(o.price||0),compareAtPrice:o.compareAtPrice?Number(o.compareAtPrice):undefined,stock:Number(o.stock||0),brand:o.brand||'Trust'}}).filter(r=>r.name&&r.slug&&r.sku)}
  function showImportResult(r){const el=$('#csv-result');el.classList.remove('hidden');el.textContent=JSON.stringify(r,null,2)}

  const auditState={search:'',action:'all'};
  async function loadAudit(force=false){loading('گزارش عملیات');try{if(force||!cache.audit.length){const payload=await api.audit({limit:200});cache.audit=listPayload(payload,['auditLogs','logs']).items.length?listPayload(payload,['auditLogs','logs']).items:(Array.isArray(payload)?payload:[])}renderAudit()}catch(e){pageError(e)}}
  function renderAudit(){const rows=cache.audit||[],actions=[...new Set(rows.map(x=>x.action).filter(Boolean))];$('#content').innerHTML=head('گزارش عملیات','ردپای تغییرات مدیریتی')+`<div class="toolbar"><input class="search" id="audit-q" value="${esc(auditState.search)}" placeholder="جستجو در عملیات"><select class="select" id="audit-action"><option value="all">همه عملیات</option>${actions.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('')}</select></div><div class="panel" id="audit-list"></div>`;$('#audit-action').value=auditState.action;const draw=()=>{const q=$('#audit-q').value.trim().toLowerCase(),act=$('#audit-action').value;const f=rows.filter(a=>(!q||`${a.action||''} ${a.entityType||''} ${a.adminUser?.displayName||''} ${a.entityId||''}`.toLowerCase().includes(q))&&(act==='all'||a.action===act));$('#audit-list').innerHTML=f.length?f.map(a=>`<div class="audit-item"><b>${esc(a.action||'ACTION')} · ${esc(a.entityType||'Entity')}</b><small>${dateFa(a.createdAt)} · ${esc(a.adminUser?.displayName||a.adminUser?.mobile||'سیستم')}</small>${a.entityId?`<small class="ltr-value">ID: ${esc(a.entityId)}</small>`:''}</div>`).join(''):'<div class="empty compact">موردی پیدا نشد.</div>'};$('#audit-q').addEventListener('input',()=>{auditState.search=$('#audit-q').value;draw()});$('#audit-action').addEventListener('change',()=>{auditState.action=$('#audit-action').value;draw()});draw()}

  async function loadAccount(){
    loading('حساب و سیستم');
    let health=null;
    try{me=await api.me()}catch(e){return pageError(e)}
    try{const r=await fetch(HEALTH_URL,{cache:'no-store'});health=r.ok?await r.json():null}catch(_){health=null}
    const permissions=Authz.list(me);
    const role=Authz.roleName(me);
    $('#content').innerHTML=head('حساب و سیستم','وضعیت اتصال، نقش و دسترسی‌های مدیر')+`<div class="panel"><h2>مدیر واردشده</h2><div class="kv"><div>نام</div><div>${esc(me?.displayName||'—')}</div><div>موبایل</div><div>${esc(me?.mobile||'—')}</div><div>نقش</div><div>${esc(role||'—')}${Authz.isSuperAdmin(me)?' · Super Admin':''}</div><div>دسترسی‌ها</div><div>${Authz.isSuperAdmin(me)?'همه دسترسی‌ها':`${fa(permissions.length)} مورد`}</div></div>${permissions.length?`<div class="permission-list">${permissions.map(x=>`<span>${esc(x)}</span>`).join('')}</div>`:''}</div><div class="panel"><h2>وضعیت سرویس</h2><div class="kv"><div>API</div><div class="${health?'health-ok':'health-bad'}">${health?'متصل':'عدم اتصال'}</div><div>Database</div><div>${esc(health?.database||'—')}</div><div>Version</div><div>${esc(health?.version||'—')}</div><div>Admin App</div><div>${esc(APP_VERSION)}</div></div></div><button class="btn danger full" id="logout">خروج از حساب</button>`;
    $('#logout').addEventListener('click',async()=>{if(!confirm('از حساب مدیر خارج شوید؟'))return;try{await api.logout()}catch(_){}setToken('');me=null;cache={dashboard:null,products:[],productMeta:null,catalog:null,inventory:[],inventoryHistory:{},orders:[],payments:[],customers:[],customerMeta:null,marketing:null,admins:[],roles:[],reports:null,settings:null,capabilities:null,audit:[]};loginView()})
  }

  function openModal(title, body){modalOpen=true;$('#modal-root').innerHTML=`<div class="modal-wrap" id="modal-wrap"><section class="modal"><div class="modal-head"><h2>${esc(title)}</h2><button class="modal-close" id="modal-close">×</button></div>${body}</section></div>`;$('#modal-close').addEventListener('click',closeModal);$('#modal-wrap').addEventListener('click',e=>{if(e.target.id==='modal-wrap')closeModal()})}
  function closeModal(){modalOpen=false;$('#modal-root').innerHTML=''}
  window.AdminStoreBack=()=>{if(modalOpen){closeModal();return true}if(moreOpen){toggleMore();return true}if(page!=='dashboard'){navigate('dashboard');return true}return false};

  window.addEventListener('unhandledrejection',e=>{console.error('AdminStore unhandled rejection',e.reason);});
  async function init(){loginView();try{me=await api.me();await showShell('dashboard')}catch(_){setToken('');loginView()}}
  init();
})();
