window.AdminStoreConfig = Object.freeze({
  apiBase: 'https://store-api.weblines.ir/api/v1',
  healthUrl: 'https://store-api.weblines.ir/health',
  requestTimeoutMs: 20000,
  appVersion: '0.78-RC1'
});
