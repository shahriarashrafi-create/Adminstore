# Steps 23-25 — Final Release

## Step 23 — Update-safe Android release
- Kept applicationId `com.store.admin`
- Established fixed release signing identity
- Set versionCode to 100
- Added release signing configuration
- Added certificate fingerprint record

## Step 24 — Final release candidate validation
- Added aggregate final-release validation
- GitHub Actions runs the complete test suite before Android build
- Release APK integrity and APK signature are verified
- SHA-256 and build metadata are emitted with the artifact

## Step 25 — Production baseline 1.0.0
- Promoted versionName to `1.0.0`
- Added VERSION.json, CHANGELOG and release checklist
- Release workflow outputs `AdminStore-v1.0.0-release.apk`
- Future builds must preserve applicationId + release keystore and only increase versionCode
