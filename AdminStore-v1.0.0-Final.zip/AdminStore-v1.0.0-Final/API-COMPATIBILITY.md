# AdminStore API Compatibility

The client supports the existing core APIs plus optional modules. The Diagnostics page performs read-only probes.

## Core
- /admin/auth/*
- /admin/dashboard
- /admin/products, /admin/variants, /admin/inventory
- /admin/orders
- /admin/payments
- /admin/customers
- /admin/audit-logs

## Step 8 optional modules
- /admin/coupons
- /admin/reviews
- /admin/banners
- /admin/campaigns

## Step 9 optional modules
- /admin/admins (fallback: /admin/users/admins)
- /admin/roles
- /admin/permissions
- /admin/reports/summary (fallback: /admin/reports)
- /admin/settings (fallback: /admin/store/settings)

## Compatibility discovery
- /admin/capabilities (fallback: /admin/features)

404 / 405 / 501 on optional modules are treated as unavailable capability rather than a fatal application error.
