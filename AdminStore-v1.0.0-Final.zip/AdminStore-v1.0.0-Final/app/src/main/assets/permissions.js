(() => {
  'use strict';

  const P = Object.freeze({
    PRODUCTS_VIEW: 'products.view',
    PRODUCTS_CREATE: 'products.create',
    PRODUCTS_UPDATE: 'products.update',
    PRODUCTS_DELETE: 'products.delete',
    VARIANTS_CREATE: 'variants.create',
    VARIANTS_DELETE: 'variants.delete',
    CATALOG_VIEW: 'catalog.view',
    CATALOG_MANAGE: 'catalog.manage',
    INVENTORY_VIEW: 'inventory.view',
    INVENTORY_UPDATE: 'inventory.update',
    ORDERS_VIEW: 'orders.view',
    ORDERS_UPDATE: 'orders.update',
    ORDERS_CANCEL: 'orders.cancel',
    ORDERS_SHIPPING: 'orders.shipping',
    PAYMENTS_VIEW: 'payments.view',
    PAYMENTS_REVIEW: 'payments.review',
    PAYMENTS_REFUND: 'payments.refund',
    CUSTOMERS_VIEW: 'customers.view',
    CUSTOMERS_UPDATE: 'customers.update',
    MARKETING_VIEW: 'marketing.view',
    MARKETING_MANAGE: 'marketing.manage',
    REVIEWS_MANAGE: 'reviews.manage',
    BANNERS_MANAGE: 'banners.manage',
    ADMINS_VIEW: 'admins.view',
    ADMINS_MANAGE: 'admins.manage',
    ROLES_MANAGE: 'roles.manage',
    REPORTS_VIEW: 'reports.view',
    SETTINGS_VIEW: 'settings.view',
    SETTINGS_MANAGE: 'settings.manage',
    DIAGNOSTICS_VIEW: 'diagnostics.view',
    CATALOG_IMPORT: 'catalog.import',
    AUDIT_VIEW: 'audit.view'
  });

  // Canonical permissions are the values above. Aliases keep the client compatible
  // with common backend naming variants; the backend remains the security authority.
  const aliases = Object.freeze({
    [P.PRODUCTS_VIEW]: ['products.view', 'product.view', 'products.read', 'catalog.view'],
    [P.PRODUCTS_CREATE]: ['products.create', 'product.create', 'products.write', 'catalog.create'],
    [P.PRODUCTS_UPDATE]: ['products.update', 'product.update', 'products.edit', 'catalog.update'],
    [P.PRODUCTS_DELETE]: ['products.delete', 'product.delete', 'products.archive', 'catalog.delete'],
    [P.VARIANTS_CREATE]: ['variants.create', 'variant.create', 'products.update', 'catalog.update'],
    [P.VARIANTS_DELETE]: ['variants.delete', 'variant.delete', 'products.update', 'catalog.update'],
    [P.CATALOG_VIEW]: ['catalog.view', 'catalog.read', 'products.view'],
    [P.CATALOG_MANAGE]: ['catalog.manage', 'categories.manage', 'brands.manage', 'attributes.manage', 'products.update'],
    [P.INVENTORY_VIEW]: ['inventory.view', 'inventory.read', 'products.view'],
    [P.INVENTORY_UPDATE]: ['inventory.update', 'inventory.adjust', 'stock.update', 'products.update'],
    [P.ORDERS_VIEW]: ['orders.view', 'order.view', 'orders.read'],
    [P.ORDERS_UPDATE]: ['orders.update', 'order.update', 'orders.edit', 'orders.status.update'],
    [P.ORDERS_CANCEL]: ['orders.cancel', 'order.cancel', 'orders.update'],
    [P.ORDERS_SHIPPING]: ['orders.shipping', 'orders.ship', 'shipping.update', 'orders.update'],
    [P.PAYMENTS_VIEW]: ['payments.view', 'payment.view', 'payments.read'],
    [P.PAYMENTS_REVIEW]: ['payments.review', 'payment.review', 'payments.update', 'payments.approve', 'payments.manage'],
    [P.PAYMENTS_REFUND]: ['payments.refund', 'payment.refund', 'refunds.create', 'payments.manage'],
    [P.CUSTOMERS_VIEW]: ['customers.view', 'customer.view', 'customers.read', 'users.view'],
    [P.CUSTOMERS_UPDATE]: ['customers.update', 'customer.update', 'customers.edit', 'users.update'],
    [P.MARKETING_VIEW]: ['marketing.view', 'marketing.read', 'coupons.view', 'reviews.view', 'banners.view'],
    [P.MARKETING_MANAGE]: ['marketing.manage', 'coupons.manage', 'discounts.manage', 'campaigns.manage'],
    [P.REVIEWS_MANAGE]: ['reviews.manage', 'reviews.update', 'reviews.moderate', 'marketing.manage'],
    [P.BANNERS_MANAGE]: ['banners.manage', 'banners.update', 'content.manage', 'marketing.manage'],
    [P.ADMINS_VIEW]: ['admins.view', 'admins.read', 'admin_users.view'],
    [P.ADMINS_MANAGE]: ['admins.manage', 'admins.update', 'admin_users.manage'],
    [P.ROLES_MANAGE]: ['roles.manage', 'permissions.manage', 'admins.manage'],
    [P.REPORTS_VIEW]: ['reports.view', 'reports.read', 'analytics.view'],
    [P.SETTINGS_VIEW]: ['settings.view', 'settings.read', 'store.settings.view'],
    [P.SETTINGS_MANAGE]: ['settings.manage', 'settings.update', 'store.settings.manage'],
    [P.DIAGNOSTICS_VIEW]: ['diagnostics.view', 'system.view', 'settings.view'],
    [P.CATALOG_IMPORT]: ['catalog.import', 'products.import', 'catalog.manage'],
    [P.AUDIT_VIEW]: ['audit.view', 'audit.read', 'audit_logs.view', 'activity_logs.view']
  });

  const pageAccess = Object.freeze({
    dashboard: null,
    products: { any: [P.PRODUCTS_VIEW] },
    catalog: { any: [P.CATALOG_VIEW, P.PRODUCTS_VIEW] },
    inventory: { any: [P.INVENTORY_VIEW, P.PRODUCTS_VIEW] },
    orders: { any: [P.ORDERS_VIEW] },
    payments: { any: [P.PAYMENTS_VIEW] },
    customers: { any: [P.CUSTOMERS_VIEW] },
    marketing: { any: [P.MARKETING_VIEW, P.MARKETING_MANAGE, P.REVIEWS_MANAGE, P.BANNERS_MANAGE] },
    reports: { any: [P.REPORTS_VIEW] },
    administration: { any: [P.ADMINS_VIEW, P.ADMINS_MANAGE, P.ROLES_MANAGE] },
    settings: { any: [P.SETTINGS_VIEW, P.SETTINGS_MANAGE] },
    diagnostics: { any: [P.DIAGNOSTICS_VIEW] },
    import: { any: [P.CATALOG_IMPORT, P.PRODUCTS_CREATE] },
    audit: { any: [P.AUDIT_VIEW] },
    account: null
  });

  const norm = value => String(value ?? '').trim().toLowerCase();

  function permissionName(value) {
    if (typeof value === 'string') return norm(value);
    if (!value || typeof value !== 'object') return '';
    return norm(value.permission ?? value.name ?? value.key ?? value.code ?? value.slug ?? value.value);
  }

  function roleName(admin) {
    const role = admin?.role ?? admin?.adminRole ?? admin?.roleName;
    if (typeof role === 'string') return norm(role);
    if (!role || typeof role !== 'object') return '';
    return norm(role.name ?? role.key ?? role.code ?? role.slug ?? role.value);
  }

  function isSuperAdmin(admin) {
    if (admin?.isSuperAdmin === true || admin?.superAdmin === true) return true;
    return ['super_admin', 'super-admin', 'superadmin', 'owner'].includes(roleName(admin));
  }

  function getSet(admin) {
    const source = Array.isArray(admin?.permissions)
      ? admin.permissions
      : Array.isArray(admin?.role?.permissions)
        ? admin.role.permissions
        : [];
    return new Set(source.map(permissionName).filter(Boolean));
  }

  function grantMatches(grant, requested) {
    if (!grant || !requested) return false;
    if (grant === '*' || grant === 'admin.*') return true;
    if (grant === requested) return true;
    if (grant.endsWith('.*')) return requested.startsWith(grant.slice(0, -1));
    return false;
  }

  function has(admin, requested) {
    if (!requested) return true;
    if (isSuperAdmin(admin)) return true;
    const set = getSet(admin);
    const accepted = aliases[requested] || [requested];
    for (const grant of set) {
      for (const candidate of accepted) {
        if (grantMatches(grant, norm(candidate))) return true;
      }
    }
    return false;
  }

  const hasAny = (admin, requested=[]) => !requested.length || requested.some(p => has(admin, p));
  const hasAll = (admin, requested=[]) => requested.every(p => has(admin, p));

  function canAccessPage(admin, page) {
    const rule = pageAccess[page];
    if (!rule) return true;
    if (rule.any && !hasAny(admin, rule.any)) return false;
    if (rule.all && !hasAll(admin, rule.all)) return false;
    return true;
  }

  function list(admin) {
    return [...getSet(admin)].sort();
  }

  window.AdminStorePermissions = Object.freeze({
    P,
    aliases,
    pageAccess,
    has,
    hasAny,
    hasAll,
    canAccessPage,
    isSuperAdmin,
    roleName,
    list
  });
})();
