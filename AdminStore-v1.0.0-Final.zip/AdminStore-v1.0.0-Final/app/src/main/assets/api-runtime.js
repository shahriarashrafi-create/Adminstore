(function (root, factory) {
  const runtime = factory(root || {});
  if (typeof module === 'object' && module.exports) module.exports = runtime;
  if (root) root.AdminStoreApiRuntime = runtime;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (root) {
  'use strict';

  function createClient(options) {
    const baseUrl = String(options.baseUrl || '').replace(/\/+$/, '');
    const timeoutMs = Number(options.timeoutMs || 20000);
    const fetchImpl = options.fetchImpl || root.fetch;
    const getToken = options.getToken || (() => '');
    const setToken = options.setToken || (() => {});
    const onRefreshAdmin = options.onRefreshAdmin || (() => {});
    const refreshPath = options.refreshPath || '/admin/auth/refresh';
    const noRefreshPaths = new Set(options.noRefreshPaths || ['/admin/auth/login', refreshPath, '/admin/auth/logout']);
    let refreshPromise = null;

    if (typeof fetchImpl !== 'function') throw new Error('fetch implementation is required');

    function makeError(code, status, payload) {
      const e = new Error(code || `HTTP_${status || 0}`);
      e.code = code || `HTTP_${status || 0}`;
      if (status !== undefined) e.status = status;
      if (payload !== undefined) e.payload = payload;
      return e;
    }

    async function refreshSession() {
      if (refreshPromise) return refreshPromise;
      refreshPromise = (async () => {
        let response;
        try {
          response = await fetchImpl(baseUrl + refreshPath, {
            method: 'POST', credentials: 'include', headers: { Accept: 'application/json' }
          });
        } catch (_) {
          throw makeError('NETWORK');
        }
        if (!response.ok) throw makeError('SESSION_EXPIRED', response.status);
        const payload = await response.json();
        if (!payload || !payload.accessToken) throw makeError('SESSION_EXPIRED', response.status);
        setToken(payload.accessToken);
        if (payload.admin) onRefreshAdmin(payload.admin);
        return payload;
      })().finally(() => { refreshPromise = null; });
      return refreshPromise;
    }

    async function raw(path, requestOptions = {}, retry = true) {
      if (!baseUrl) throw makeError('API_CONFIG');
      const headers = new Headers(requestOptions.headers || {});
      headers.set('Accept', 'application/json');
      const FormDataCtor = root.FormData;
      const isFormData = FormDataCtor && requestOptions.body instanceof FormDataCtor;
      if (!isFormData && requestOptions.body !== undefined && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
      const token = getToken();
      if (token) headers.set('Authorization', `Bearer ${token}`);

      const ownController = !requestOptions.signal && typeof AbortController !== 'undefined' ? new AbortController() : null;
      const timer = ownController ? setTimeout(() => ownController.abort(), timeoutMs) : null;
      let response;
      try {
        response = await fetchImpl(baseUrl + path, {
          ...requestOptions,
          headers,
          credentials: requestOptions.credentials || 'include',
          signal: requestOptions.signal || (ownController && ownController.signal)
        });
      } catch (err) {
        if (timer) clearTimeout(timer);
        throw makeError(err && err.name === 'AbortError' ? 'REQUEST_TIMEOUT' : 'NETWORK');
      }
      if (timer) clearTimeout(timer);

      if (response.status === 401 && retry && !noRefreshPaths.has(path.split('?')[0])) {
        try {
          await refreshSession();
          return raw(path, requestOptions, false);
        } catch (refreshError) {
          setToken('');
          throw refreshError;
        }
      }

      if (!response.ok) {
        let payload = {};
        try { payload = await response.json(); } catch (_) {}
        const code = payload && (payload.error || payload.code) || `HTTP_${response.status}`;
        throw makeError(code, response.status, payload);
      }
      if (response.status === 204) return null;
      return response.json();
    }

    return Object.freeze({ raw, refreshSession });
  }

  return Object.freeze({ createClient });
});
