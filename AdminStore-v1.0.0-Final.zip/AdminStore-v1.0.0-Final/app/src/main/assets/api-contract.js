(function (root, factory) {
  const contract = factory();
  if (typeof module === 'object' && module.exports) module.exports = contract;
  if (root) root.AdminStoreApiContract = contract;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const enc = value => encodeURIComponent(String(value));
  const endpoints = Object.freeze({
    auth: Object.freeze({
      login: '/admin/auth/login', refresh: '/admin/auth/refresh', logout: '/admin/auth/logout', me: '/admin/auth/me'
    }),
    dashboard: '/admin/dashboard',
    products: Object.freeze({
      list: '/admin/products', detail: id => `/admin/products/${enc(id)}`,
      variants: productId => `/admin/products/${enc(productId)}/variants`,
      variant: (productId, variantId) => `/admin/products/${enc(productId)}/variants/${enc(variantId)}`,
      variantDirect: variantId => `/admin/variants/${enc(variantId)}`,
      validateSku: '/admin/variants/validate-sku', images: productId => `/admin/products/${enc(productId)}/images`,
      image: (productId, imageId) => `/admin/products/${enc(productId)}/images/${enc(imageId)}`, import: '/admin/catalog/import'
    }),
    catalog: Object.freeze({categories:'/admin/categories',brands:'/admin/brands',attributes:'/admin/attributes'}),
    inventory: Object.freeze({list:'/admin/inventory',history: variantId => `/admin/inventory/${enc(variantId)}/history`,adjust: variantId => `/admin/inventory/${enc(variantId)}/adjust`}),
    orders: Object.freeze({
      list:'/admin/orders', detail:id=>`/admin/orders/${enc(id)}`, status:id=>`/admin/orders/${enc(id)}/status`,
      timeline:id=>`/admin/orders/${enc(id)}/timeline`, shipping:id=>`/admin/orders/${enc(id)}/shipping`, cancel:id=>`/admin/orders/${enc(id)}/cancel`
    }),
    payments: Object.freeze({
      list:'/admin/payments', detail:id=>`/admin/payments/${enc(id)}`, history:id=>`/admin/payments/${enc(id)}/history`,
      receiptUrl:id=>`/admin/payments/${enc(id)}/receipt-url`, approve:id=>`/admin/payments/${enc(id)}/approve`,
      reject:id=>`/admin/payments/${enc(id)}/reject`, resubmission:id=>`/admin/payments/${enc(id)}/resubmission`,
      refund:id=>`/admin/payments/${enc(id)}/refund`, refunds:id=>`/admin/payments/${enc(id)}/refunds`
    }),
    customers: Object.freeze({
      list:'/admin/customers', detail:id=>`/admin/customers/${enc(id)}`, orders:id=>`/admin/customers/${enc(id)}/orders`,
      payments:id=>`/admin/customers/${enc(id)}/payments`, status:id=>`/admin/customers/${enc(id)}/status`, notes:id=>`/admin/customers/${enc(id)}/notes`
    }),
    marketing: Object.freeze({
      coupons:'/admin/coupons', coupon:id=>`/admin/coupons/${enc(id)}`,
      reviews:'/admin/reviews', review:id=>`/admin/reviews/${enc(id)}`, reviewStatus:id=>`/admin/reviews/${enc(id)}/status`,
      banners:'/admin/banners', banner:id=>`/admin/banners/${enc(id)}`,
      campaigns:'/admin/campaigns', campaign:id=>`/admin/campaigns/${enc(id)}`
    }),
    administration: Object.freeze({
      admins:'/admin/admins', admin:id=>`/admin/admins/${enc(id)}`, roles:'/admin/roles', role:id=>`/admin/roles/${enc(id)}`, permissions:'/admin/permissions'
    }),
    reports: Object.freeze({summary:'/admin/reports/summary',root:'/admin/reports',export:'/admin/reports/export'}),
    settings: Object.freeze({root:'/admin/settings',store:'/admin/store/settings'}),
    system: Object.freeze({capabilities:'/admin/capabilities',features:'/admin/features',audit:'/admin/audit-logs'})
  });

  const orderTransitions = Object.freeze({
    PENDING:Object.freeze(['CONFIRMED','CANCELLED']), AWAITING_PAYMENT:Object.freeze(['PAYMENT_SUBMITTED','CANCELLED']),
    PAYMENT_SUBMITTED:Object.freeze(['CONFIRMED','CANCELLED']), PAYMENT_REVIEW:Object.freeze(['CONFIRMED','CANCELLED']),
    CONFIRMED:Object.freeze(['PROCESSING','PREPARING','CANCELLED']), PAID:Object.freeze(['PROCESSING','PREPARING','CANCELLED']),
    PROCESSING:Object.freeze(['PREPARING','SHIPPED','CANCELLED']), PREPARING:Object.freeze(['SHIPPED','CANCELLED']),
    SHIPPED:Object.freeze(['DELIVERED','RETURNED']), DELIVERED:Object.freeze(['RETURNED']),
    RETURNED:Object.freeze(['REFUNDED','PARTIALLY_REFUNDED']), PARTIALLY_REFUNDED:Object.freeze(['REFUNDED']),
    CANCELLED:Object.freeze([]), REFUNDED:Object.freeze([])
  });

  const probePaths = Object.freeze([
    ['Auth / Me',endpoints.auth.me],['Products',`${endpoints.products.list}?limit=1`],['Inventory',`${endpoints.inventory.list}?limit=1`],
    ['Orders',`${endpoints.orders.list}?limit=1`],['Payments',`${endpoints.payments.list}?limit=1`],['Customers',`${endpoints.customers.list}?limit=1`],
    ['Coupons',`${endpoints.marketing.coupons}?limit=1`],['Reviews',`${endpoints.marketing.reviews}?limit=1`],['Banners',`${endpoints.marketing.banners}?limit=1`],
    ['Admins',`${endpoints.administration.admins}?limit=1`],['Reports',`${endpoints.reports.summary}?period=7d`],['Settings',endpoints.settings.root]
  ]);

  return Object.freeze({contractVersion:'2026-10-17.step18-22',apiVersion:'v1',endpoints,orderTransitions,probePaths});
});
