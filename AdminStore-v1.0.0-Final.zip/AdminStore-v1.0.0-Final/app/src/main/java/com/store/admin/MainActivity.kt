package com.store.admin

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

@Suppress("DEPRECATION")
class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var root: FrameLayout
    private lateinit var splash: View
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val handler = Handler(Looper.getMainLooper())
    private val launchAt = System.currentTimeMillis()
    private var webReady = false
    private var splashDismissed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#F6F8F7")
        window.navigationBarColor = Color.parseColor("#F6F8F7")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        root = FrameLayout(this)
        webView = WebView(this).apply { setBackgroundColor(Color.parseColor("#F6F8F7")) }
        root.addView(webView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        splash = buildNativeSplash()
        root.addView(splash, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setContentView(root)

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            allowFileAccess = false
            allowContentAccess = true
            allowUniversalAccessFromFileURLs = false
            allowFileAccessFromFileURLs = false
            builtInZoomControls = false
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = true
            defaultTextEncodingName = "utf-8"
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) safeBrowsingEnabled = true
        }

        CookieManager.getInstance().setAcceptCookie(true)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false)
        }

        webView.overScrollMode = View.OVER_SCROLL_NEVER
        webView.addJavascriptInterface(NativeBridge(this), "NativeBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                webReady = true
                dismissSplashWhenReady()
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) dismissSplashWhenReady()
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val uri = request?.url ?: return null
                val apiUri = Uri.parse(BuildConfig.API_BASE_URL)
                if (uri.scheme == "https" && uri.host == apiUri.host && uri.path?.startsWith(LOCAL_ASSET_PREFIX) == true) {
                    val assetName = uri.path!!.removePrefix(LOCAL_ASSET_PREFIX).ifBlank { "index.html" }
                    if (assetName.contains("..") || assetName.contains("/")) return null
                    return try {
                        val mime = when {
                            assetName.endsWith(".html") -> "text/html"
                            assetName.endsWith(".css") -> "text/css"
                            assetName.endsWith(".js") -> "application/javascript"
                            assetName.endsWith(".json") -> "application/json"
                            assetName.endsWith(".svg") -> "image/svg+xml"
                            assetName.endsWith(".png") -> "image/png"
                            else -> "application/octet-stream"
                        }
                        WebResourceResponse(mime, "UTF-8", assets.open(assetName))
                    } catch (_: Exception) { null }
                }
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                val apiUri = Uri.parse(BuildConfig.API_BASE_URL)
                val isLocalApp = uri.scheme == "https" && uri.host == apiUri.host && uri.path?.startsWith(LOCAL_ASSET_PREFIX) == true
                if (isLocalApp) return false
                if (uri.scheme != "https") return true
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    true
                } catch (_: Exception) { true }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = try { params?.createIntent() ?: return false } catch (_: Exception) {
                    filePathCallback = null
                    return false
                }
                return try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST)
                    true
                } catch (_: Exception) {
                    filePathCallback = null
                    false
                }
            }
        }

        val apiUri = Uri.parse(BuildConfig.API_BASE_URL)
        val portPart = if (apiUri.port > 0) ":${apiUri.port}" else ""
        val origin = if (apiUri.scheme == "https" && !apiUri.host.isNullOrBlank()) "https://${apiUri.host}$portPart" else "https://appassets.invalid"
        webView.loadUrl("$origin${LOCAL_ASSET_PREFIX}index.html")
        handler.postDelayed({ if (!splashDismissed) dismissSplash(force = true) }, 2500L)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildNativeSplash(): View {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(28), dp(28), dp(28))
            setBackgroundColor(Color.parseColor("#F6F8F7"))
        }
        val logo = TextView(this).apply {
            text = "A"
            textSize = 34f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            background = getDrawable(R.drawable.splash_logo)
        }
        wrap.addView(logo, LinearLayout.LayoutParams(dp(84), dp(84)))
        val title = TextView(this).apply {
            text = "AdminStore"
            textSize = 27f
            setTextColor(Color.parseColor("#16251F"))
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        wrap.addView(title, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(15) })
        val sub = TextView(this).apply {
            text = "مدیریت فروشگاه Store"
            textSize = 13f
            setTextColor(Color.parseColor("#6A7771"))
            gravity = Gravity.CENTER
        }
        wrap.addView(sub, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(7) })
        wrap.alpha = 0f
        wrap.animate().alpha(1f).setDuration(280).start()
        return wrap
    }

    private fun dismissSplashWhenReady() {
        val delay = (650L - (System.currentTimeMillis() - launchAt)).coerceAtLeast(0L)
        handler.postDelayed({ dismissSplash(false) }, delay)
    }

    private fun dismissSplash(force: Boolean) {
        if (splashDismissed || (!force && !webReady)) return
        splashDismissed = true
        splash.animate().alpha(0f).setDuration(180).withEndAction { root.removeView(splash) }.start()
    }

    class NativeBridge(private val context: Context) {
        @JavascriptInterface
        fun haptic() {
            try {
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
                if (!vibrator.hasVibrator()) return
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE))
                } else vibrator.vibrate(18)
            } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun appVersion(): String = BuildConfig.VERSION_NAME

        @JavascriptInterface
        fun apiBaseUrl(): String = BuildConfig.API_BASE_URL

        @JavascriptInterface
        fun healthUrl(): String = BuildConfig.HEALTH_URL

        @JavascriptInterface
        fun openUrl(url: String) {
            try {
                if (!url.startsWith("https://")) return
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (_: Exception) {}
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_CHOOSER_REQUEST) {
            filePathCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            filePathCallback = null
        }
    }

    override fun onBackPressed() {
        webView.evaluateJavascript("window.AdminStoreBack ? AdminStoreBack() : false") { value ->
            if (value == "true") return@evaluateJavascript
            if (webView.canGoBack()) webView.goBack() else finish()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        webView.removeJavascriptInterface("NativeBridge")
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val FILE_CHOOSER_REQUEST = 9101
        private const val LOCAL_ASSET_PREFIX = "/__adminstore__/"
    }
}
