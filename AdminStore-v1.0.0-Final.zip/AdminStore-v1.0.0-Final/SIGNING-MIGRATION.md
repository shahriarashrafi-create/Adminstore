# Signing migration note

AdminStore versions before 1.0.0 were built as debug APKs without a project-owned fixed signing key. A debug key created by an ephemeral CI runner cannot be recovered from this source archive.

Version 1.0.0 establishes the permanent AdminStore release signing identity. If an older installed APK was signed with a different debug certificate, Android will reject an in-place update to 1.0.0 and that device will need a one-time clean install. After 1.0.0 is installed, every future release can update in place as long as both of these remain unchanged:

- applicationId: `com.store.admin`
- release keystore: `keystore/adminstore-release.jks`

Future versions must only increase `versionCode` and must never replace the release keystore.
