const assert=require('assert');
const Runtime=require('../app/src/main/assets/api-runtime.js');
const C=require('../app/src/main/assets/api-contract.js');
const response=(status,payload)=>({status,ok:status>=200&&status<300,json:async()=>payload});
(async()=>{
  const state={products:{},variants:{},history:{}}; let pseq=0,vseq=0;
  const fetchImpl=async(url,opt={})=>{
    const u=new URL(url), path=u.pathname.replace('/api/v1',''), method=(opt.method||'GET').toUpperCase();
    const body=opt.body?JSON.parse(opt.body):{};
    if(path===C.endpoints.products.list && method==='POST'){
      const id=`p${++pseq}`; state.products[id]={id,...body,variants:[]}; return response(201,state.products[id]);
    }
    let m=path.match(/^\/admin\/products\/([^/]+)\/variants$/);
    if(m&&method==='POST'){
      const productId=decodeURIComponent(m[1]); if(!state.products[productId])return response(404,{error:'PRODUCT_NOT_FOUND'});
      const id=`v${++vseq}`; state.variants[id]={id,productId,stock:Number(body.stock||0),...body}; state.products[productId].variants.push(id); return response(201,state.variants[id]);
    }
    m=path.match(/^\/admin\/inventory\/([^/]+)\/adjust$/);
    if(m&&method==='POST'){
      const id=decodeURIComponent(m[1]), v=state.variants[id]; if(!v)return response(404,{error:'VARIANT_NOT_FOUND'});
      const before=v.stock; v.stock=Math.max(0,Number(body.absoluteQuantity??(before+Number(body.delta||0))));
      (state.history[id]||(state.history[id]=[])).push({before,after:v.stock,reason:body.reason||''}); return response(200,{variantId:id,stock:v.stock});
    }
    m=path.match(/^\/admin\/inventory\/([^/]+)\/history$/);
    if(m&&method==='GET') return response(200,{items:state.history[decodeURIComponent(m[1])]||[]});
    if(path===C.endpoints.inventory.list&&method==='GET') return response(200,{items:Object.values(state.variants)});
    return response(404,{error:'ENDPOINT_NOT_AVAILABLE'});
  };
  const client=Runtime.createClient({baseUrl:'https://example.test/api/v1',fetchImpl,getToken:()=> 'token',setToken:()=>{},timeoutMs:1000});
  const product=await client.raw(C.endpoints.products.list,{method:'POST',body:JSON.stringify({name:'Test Product',slug:'test-product'})});
  const variant=await client.raw(C.endpoints.products.variants(product.id),{method:'POST',body:JSON.stringify({sku:'TEST-1',price:100,stock:2})});
  const adjusted=await client.raw(C.endpoints.inventory.adjust(variant.id),{method:'POST',body:JSON.stringify({delta:8,reason:'restock'})});
  assert.equal(adjusted.stock,10);
  const inventory=await client.raw(C.endpoints.inventory.list+'?limit=20');
  assert.equal(inventory.items[0].stock,10);
  const history=await client.raw(C.endpoints.inventory.history(variant.id));
  assert.deepEqual(history.items[0],{before:2,after:10,reason:'restock'});
  console.log('Product/inventory E2E contract test passed.');
})().catch(e=>{console.error(e);process.exit(1)});
