const C=require('../app/src/main/assets/api-contract.js');
const base=String(process.env.ADMINSTORE_API_BASE_URL||'').replace(/\/+$/,'');
const health=process.env.ADMINSTORE_HEALTH_URL||'';
const mobile=process.env.ADMINSTORE_TEST_MOBILE||'';
const password=process.env.ADMINSTORE_TEST_PASSWORD||'';
async function req(url,opt={}){const r=await fetch(url,opt);let body=null;try{body=await r.json()}catch{}return {r,body}}
(async()=>{
  if(!base) throw new Error('ADMINSTORE_API_BASE_URL is required');
  if(health){const {r}=await req(health);if(!r.ok)throw new Error(`Health failed: ${r.status}`);console.log('Health:',r.status)}
  if(!mobile||!password){console.log('Authenticated live contract tests skipped: ADMINSTORE_TEST_MOBILE/PASSWORD not configured.');return}
  const login=await req(base+C.endpoints.auth.login,{method:'POST',headers:{'content-type':'application/json','accept':'application/json'},body:JSON.stringify({mobile,password})});
  if(!login.r.ok||!login.body?.accessToken)throw new Error(`Login contract failed: ${login.r.status}`);
  const headers={accept:'application/json',authorization:`Bearer ${login.body.accessToken}`};
  for(const [name,path] of C.probePaths){const {r}=await req(base+path,{headers});if([404,405,501].includes(r.status)||r.status>=500)throw new Error(`${name} contract mismatch: ${r.status} ${path}`);console.log(`${name}: ${r.status}`)}
  console.log('Live backend contract checks passed.');
})().catch(e=>{console.error(e);process.exit(1)});
