const assert=require('assert');
const fs=require('fs');
const path=require('path');
const C=require('../app/src/main/assets/api-contract.js');
assert.equal(C.apiVersion,'v1');
assert.ok(C.contractVersion.includes('step18-22'));
const required=[
  C.endpoints.auth.login,C.endpoints.auth.refresh,C.endpoints.auth.me,
  C.endpoints.products.list,C.endpoints.inventory.list,C.endpoints.orders.list,
  C.endpoints.payments.list,C.endpoints.customers.list
];
required.forEach(p=>assert.ok(String(p).startsWith('/admin/'),`invalid endpoint ${p}`));
assert.equal(C.endpoints.products.detail('p 1'),'/admin/products/p%201');
assert.equal(C.endpoints.inventory.adjust('v/1'),'/admin/inventory/v%2F1/adjust');
assert.equal(C.endpoints.orders.shipping('o1'),'/admin/orders/o1/shipping');
assert.ok(C.orderTransitions.SHIPPED.includes('DELIVERED'));
assert.ok(!C.orderTransitions.SHIPPED.includes('CANCELLED'));
assert.equal(C.endpoints.payments.refunds('p/1'),'/admin/payments/p%2F1/refunds');
assert.equal(C.endpoints.marketing.coupon('x 1'),'/admin/coupons/x%201');
assert.equal(C.endpoints.administration.admin('a1'),'/admin/admins/a1');
assert.equal(C.endpoints.reports.export,'/admin/reports/export');
const app=fs.readFileSync(path.join(__dirname,'..','app','src','main','assets','app.js'),'utf8');
assert.ok(app.includes('AdminStoreApiContract'));
assert.ok(app.includes('E.inventory.adjust'));
assert.ok(app.includes('E.orders.shipping'));
console.log('API contract test passed.');
