const assert=require('assert');
const Runtime=require('../app/src/main/assets/api-runtime.js');
const C=require('../app/src/main/assets/api-contract.js');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const response=(status,payload)=>({status,ok:status>=200&&status<300,json:async()=>payload});
(async()=>{
  let token='expired-token', refreshCalls=0, admin=null;
  const calls=[];
  const header=(headers,name)=>headers?.get?headers.get(name):(headers?.[name]||headers?.[name.toLowerCase()]||headers?.[name.toUpperCase()]||'');
  const fetchImpl=async(url,opt={})=>{
    const path=new URL(url).pathname;
    calls.push({path,auth:header(opt.headers,'Authorization')||''});
    if(path.endsWith(C.endpoints.auth.refresh)){
      refreshCalls++; await sleep(20); return response(200,{accessToken:'fresh-token',admin:{id:'a1',role:'manager',permissions:['products.view']}});
    }
    if((header(opt.headers,'Authorization')||'')==='Bearer expired-token') return response(401,{error:'UNAUTHORIZED_ADMIN'});
    if((header(opt.headers,'Authorization')||'')==='Bearer fresh-token') return response(200,{data:{ok:true}});
    return response(401,{error:'UNAUTHORIZED_ADMIN'});
  };
  const client=Runtime.createClient({baseUrl:'https://example.test/api/v1',fetchImpl,getToken:()=>token,setToken:v=>token=v,onRefreshAdmin:a=>admin=a,refreshPath:C.endpoints.auth.refresh,noRefreshPaths:[C.endpoints.auth.login,C.endpoints.auth.refresh,C.endpoints.auth.logout],timeoutMs:1000});
  const [a,b]=await Promise.all([client.raw(C.endpoints.auth.me),client.raw(C.endpoints.dashboard)]);
  assert.equal(refreshCalls,1,'parallel 401s must share one refresh request');
  assert.equal(token,'fresh-token');
  assert.equal(admin.id,'a1');
  assert.equal(a.data.ok,true); assert.equal(b.data.ok,true);
  assert.ok(calls.filter(x=>x.path.endsWith(C.endpoints.auth.refresh)).length===1);
  console.log('Auth/session test passed.');
})().catch(e=>{console.error(e);process.exit(1)});
