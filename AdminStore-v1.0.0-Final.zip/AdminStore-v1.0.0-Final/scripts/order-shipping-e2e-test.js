const assert=require('assert');
const Runtime=require('../app/src/main/assets/api-runtime.js');
const C=require('../app/src/main/assets/api-contract.js');
const response=(status,payload)=>({status,ok:status>=200&&status<300,json:async()=>payload});
(async()=>{
  const order={id:'o1',status:'PENDING',shipping:{}};
  const fetchImpl=async(url,opt={})=>{
    const path=new URL(url).pathname.replace('/api/v1',''), method=(opt.method||'GET').toUpperCase(), body=opt.body?JSON.parse(opt.body):{};
    if(path===C.endpoints.orders.detail('o1')&&method==='GET')return response(200,order);
    if(path===C.endpoints.orders.status('o1')&&method==='PATCH'){
      const allowed=C.orderTransitions[order.status]||[];
      if(!allowed.includes(body.status))return response(409,{error:'INVALID_ORDER_TRANSITION'});
      order.status=body.status; return response(200,order);
    }
    if(path===C.endpoints.orders.shipping('o1')&&method==='PATCH'){
      if(!['CONFIRMED','PROCESSING','PREPARING','SHIPPED'].includes(order.status))return response(409,{error:'SHIPPING_UPDATE_NOT_ALLOWED'});
      order.shipping={...order.shipping,...body}; return response(200,order.shipping);
    }
    if(path===C.endpoints.orders.cancel('o1')&&method==='POST'){
      const allowed=C.orderTransitions[order.status]||[];
      if(!allowed.includes('CANCELLED'))return response(409,{error:'INVALID_ORDER_TRANSITION'});
      order.status='CANCELLED'; return response(200,order);
    }
    return response(404,{error:'ENDPOINT_NOT_AVAILABLE'});
  };
  const client=Runtime.createClient({baseUrl:'https://example.test/api/v1',fetchImpl,getToken:()=> 'token',setToken:()=>{},timeoutMs:1000});
  await client.raw(C.endpoints.orders.status('o1'),{method:'PATCH',body:JSON.stringify({status:'CONFIRMED'})});
  await client.raw(C.endpoints.orders.status('o1'),{method:'PATCH',body:JSON.stringify({status:'PROCESSING'})});
  await client.raw(C.endpoints.orders.shipping('o1'),{method:'PATCH',body:JSON.stringify({carrier:'Post',trackingCode:'TRK-1'})});
  await client.raw(C.endpoints.orders.status('o1'),{method:'PATCH',body:JSON.stringify({status:'SHIPPED'})});
  let cancelError=null; try{await client.raw(C.endpoints.orders.cancel('o1'),{method:'POST',body:JSON.stringify({reason:'late'})})}catch(e){cancelError=e}
  assert.equal(cancelError&&cancelError.code,'INVALID_ORDER_TRANSITION');
  await client.raw(C.endpoints.orders.status('o1'),{method:'PATCH',body:JSON.stringify({status:'DELIVERED'})});
  assert.equal(order.status,'DELIVERED');
  assert.equal(order.shipping.trackingCode,'TRK-1');
  console.log('Order/shipping E2E contract test passed.');
})().catch(e=>{console.error(e);process.exit(1)});
