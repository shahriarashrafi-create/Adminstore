const assert=require('assert');
const Runtime=require('../app/src/main/assets/api-runtime.js'); const C=require('../app/src/main/assets/api-contract.js');
const response=(status,payload)=>({status,ok:status>=200&&status<300,json:async()=>payload});
(async()=>{const payment={id:'pay1',status:'PENDING_REVIEW',amount:1000,refundedAmount:0,refundableAmount:1000,order:{id:'o1',status:'PENDING'}};const refunds=[];const history=[];
const fetchImpl=async(url,opt={})=>{const p=new URL(url).pathname.replace('/api/v1',''),m=(opt.method||'GET').toUpperCase(),b=opt.body?JSON.parse(opt.body):{};
if(p===C.endpoints.payments.detail('pay1')&&m==='GET')return response(200,payment);
if(p===C.endpoints.payments.receiptUrl('pay1')&&m==='GET')return response(200,{url:'https://example.test/receipt.jpg'});
if(p===C.endpoints.payments.approve('pay1')&&m==='POST'){payment.status='APPROVED';payment.order.status='CONFIRMED';history.push({type:'APPROVED'});return response(200,payment)}
if(p===C.endpoints.payments.refund('pay1')&&m==='POST'){if(!['APPROVED','PARTIALLY_REFUNDED'].includes(payment.status))return response(409,{error:'REFUND_NOT_ALLOWED'});const amount=Number(b.amount||0);if(amount<=0||amount>payment.refundableAmount)return response(422,{error:'REFUND_AMOUNT_INVALID'});payment.refundedAmount+=amount;payment.refundableAmount-=amount;payment.status=payment.refundableAmount===0?'REFUNDED':'PARTIALLY_REFUNDED';refunds.push({id:`r${refunds.length+1}`,amount,status:'REFUNDED',reason:b.reason});return response(200,refunds.at(-1))}
if(p===C.endpoints.payments.refunds('pay1')&&m==='GET')return response(200,{items:refunds}); if(p===C.endpoints.payments.history('pay1')&&m==='GET')return response(200,{items:history}); return response(404,{error:'ENDPOINT_NOT_AVAILABLE'})};
const client=Runtime.createClient({baseUrl:'https://example.test/api/v1',fetchImpl,getToken:()=> 'token',setToken:()=>{},timeoutMs:1000});
assert.equal((await client.raw(C.endpoints.payments.receiptUrl('pay1'))).url.endsWith('.jpg'),true); await client.raw(C.endpoints.payments.approve('pay1'),{method:'POST'}); assert.equal(payment.order.status,'CONFIRMED');
await client.raw(C.endpoints.payments.refund('pay1'),{method:'POST',body:JSON.stringify({type:'partial',amount:400,reason:'partial return'})}); assert.equal(payment.status,'PARTIALLY_REFUNDED'); assert.equal(payment.refundableAmount,600);
await client.raw(C.endpoints.payments.refund('pay1'),{method:'POST',body:JSON.stringify({type:'full',amount:600,reason:'complete return'})}); assert.equal(payment.status,'REFUNDED'); assert.equal((await client.raw(C.endpoints.payments.refunds('pay1'))).items.length,2); console.log('Payment/receipt/refund E2E contract test passed.');})().catch(e=>{console.error(e);process.exit(1)});
