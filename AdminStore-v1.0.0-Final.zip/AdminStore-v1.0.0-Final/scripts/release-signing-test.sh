#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
[ -f signing.properties ] || { echo "signing.properties missing"; exit 1; }
[ -f keystore/adminstore-release.jks ] || { echo "release keystore missing"; exit 1; }
STOREPASS=$(awk -F= '$1=="storePassword"{print substr($0,index($0,"=")+1)}' signing.properties)
ALIAS=$(awk -F= '$1=="keyAlias"{print substr($0,index($0,"=")+1)}' signing.properties)
EXPECTED=$(node -p "require('./VERSION.json').signingCertSha256")
ACTUAL=$(keytool -list -v -keystore keystore/adminstore-release.jks -storepass "$STOREPASS" -alias "$ALIAS" 2>/dev/null | awk -F': ' '/SHA256:/{print $2; exit}')
if [ "$ACTUAL" != "$EXPECTED" ]; then
  echo "Release signing fingerprint mismatch"
  echo "Expected: $EXPECTED"
  echo "Actual:   $ACTUAL"
  exit 1
fi
echo "Release signing identity test passed."
