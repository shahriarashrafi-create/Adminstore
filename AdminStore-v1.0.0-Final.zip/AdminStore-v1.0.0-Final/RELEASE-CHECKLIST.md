# AdminStore 1.0.0 Release Checklist

## Identity / update safety
- applicationId remains `com.store.admin`
- versionCode is greater than all previous builds
- the fixed release keystore is present
- release APK is signed with the fixed certificate
- certificate fingerprint is recorded in `RELEASE-IDENTITY.md`

## Automated validation
- JavaScript syntax checks
- smoke test
- API contract test
- auth/session test
- product/inventory E2E
- order/shipping E2E
- payment/refund E2E
- customer/marketing E2E
- admin/reports/settings E2E
- security hardening test
- final release identity test

## Manual production acceptance
- login against production backend
- create/edit one test product
- inventory adjustment
- review one test order/payment flow
- customer detail view
- reports/settings access by correct roles
- install release APK over the prior signed release and verify data/session behavior
