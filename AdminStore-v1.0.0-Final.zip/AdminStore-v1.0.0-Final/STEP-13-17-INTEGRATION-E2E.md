# Step 13–17 — Backend Contract, CI, Auth, Product/Inventory & Order E2E

Version: `0.78-RC1` — `versionCode 18`

## Step 13 — Backend contract
- `assets/api-contract.js` is the canonical AdminStore API contract for Auth, Products, Inventory, Orders, Payments and Customers.
- Dynamic IDs are URL encoded centrally.
- The Diagnostics page shows the contract version and probes canonical endpoints.
- The app consumes the contract for the critical Step 13–17 modules instead of scattering endpoint strings.
- `scripts/live-contract-test.js` can compare the contract with a real backend when GitHub Actions is manually dispatched with live checks enabled.

## Step 14 — CI / APK build validation
- GitHub Actions now validates JS syntax and all integration tests before Gradle build.
- API base and health URL can be configured using GitHub repository variables.
- Optional live contract tests can be enabled on workflow dispatch.
- The built APK is ZIP-verified, SHA-256 hashed and uploaded together with build metadata.

## Step 15 — Auth/session
- Network/auth logic was extracted to `assets/api-runtime.js` so it can be tested independently.
- Parallel 401 responses share one refresh request.
- The failed request is retried with the refreshed access token.
- Refresh failure clears the access token.
- Auth/session contract test runs in CI.

## Step 16 — Products / Inventory E2E
Automated contract flow:
1. Create product
2. Create variant
3. Adjust stock through inventory endpoint
4. Read inventory
5. Read inventory history

This protects product/variant/inventory endpoint shape from regressions before APK build.

## Step 17 — Orders / Shipping E2E
Automated contract flow:
1. PENDING → CONFIRMED
2. CONFIRMED → PROCESSING
3. Save shipping carrier/tracking code
4. PROCESSING → SHIPPED
5. Confirm cancellation is rejected after shipping
6. SHIPPED → DELIVERED

Order transitions are centralized in `api-contract.js`.

## Live backend verification
For a manual GitHub Actions run, enable **Run live backend contract checks**.
Optional secrets:
- `ADMINSTORE_TEST_MOBILE`
- `ADMINSTORE_TEST_PASSWORD`

Repository variables:
- `ADMINSTORE_API_BASE_URL`
- `ADMINSTORE_HEALTH_URL`

If credentials are not configured, the live script checks health only and skips authenticated probes.
