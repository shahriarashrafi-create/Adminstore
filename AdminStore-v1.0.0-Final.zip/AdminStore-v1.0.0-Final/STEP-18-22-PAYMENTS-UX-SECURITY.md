# Step 18–22 — Payments, Customer/Marketing, Administration, UX & Security

## Step 18
Payment receipt review, approval, resubmission/rejection and full/partial refund contract is covered by automated E2E tests. Refund history endpoint is supported in Payment detail. Sensitive payment mutations use idempotency keys.

## Step 19
Customer status/notes and Marketing flows (coupon, review moderation, banner, campaign) are centralized in the API contract and covered by automated tests.

## Step 20
Admin/Role/Permission, Reports and Settings endpoints are centralized. Role creation can consume backend permissions. Reports support server export with local CSV fallback. Settings include order/shipping/maintenance/social fields.

## Step 21
Skeleton loading, compact responsive improvements, clearer offline/error states and interaction feedback were added.

## Step 22
WebView no longer uses file:// universal access. Local assets are served through a virtual HTTPS path on the API origin, third-party cookies are disabled, cleartext is blocked by network security config, CSP is enabled and security checks are part of CI.
