# AdminStore — Steps 8 to 12

Version: 0.73-RC1 (versionCode 13)

## Step 8 — Marketing & Content
- Coupons: list/create/edit/delete with optional backend fallback behavior.
- Reviews: moderation (approve/reject/delete).
- Banners: list/create/edit/delete.
- Campaigns: list/create/edit/delete.
- Permission-aware navigation/actions.

## Step 9 — Administration / Reports / Settings
- Admin accounts and role assignment.
- Role creation with permissions.
- Reports summary with 7d/30d/month periods.
- Store settings read/update.
- Audit log search/filter.

## Step 10 — Production UX hardening
- 20 second request timeout.
- Online/offline status in the header.
- Retry action on page errors.
- Double-submit protection for new mutations.
- Extra responsive rules for small phones/tablets.

## Step 11 — API compatibility diagnostics
- Read-only diagnostics page.
- Capabilities/features endpoint support when available.
- Safe GET probes for core/admin/marketing modules.
- Distinguishes active / forbidden / missing / error endpoints.

## Step 12 — Release hardening
- App version advanced to 0.73-RC1 / versionCode 13.
- Node syntax validation remains in CI.
- Added scripts/smoke-test.js to validate critical pages, APIs and permissions before APK build.
- Existing HTTPS-only Android network policy and WebView mixed-content blocking retained.

## Compatibility note
Optional modules intentionally use non-fatal GET fallbacks. If an endpoint has not yet been deployed to the backend, AdminStore shows an unavailable-state instead of crashing the whole app. Backend authorization remains authoritative.
