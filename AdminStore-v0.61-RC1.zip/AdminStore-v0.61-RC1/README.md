# AdminStore Android — v0.61 RC1

اپلیکیشن Android مدیریت Store، متصل به Backend واقعی:

- API: `https://store-api.weblines.ir/api/v1`
- Health: `https://store-api.weblines.ir/health`
- Login: موبایل + رمز Owner/Admin
- هیچ رمز یا JWT Secret داخل پروژه قرار ندارد.

## بخش‌های اپ

- داشبورد فروش، سفارش، پرداخت در انتظار و کم‌موجود
- محصولات: جستجو، ساخت محصول، ویرایش مشخصات، قیمت و موجودی Variant
- سفارش‌ها: فیلتر، جزئیات و تغییر وضعیت مجاز
- پرداخت‌ها: مشاهده رسید، تایید، رد و درخواست ارسال مجدد
- مشتریان: خلاصه مشتریان استخراج‌شده از سفارش‌ها
- ورود گروهی CSV با Dry Run و Commit
- Audit Log
- حساب مدیر و Health سرویس

## GitHub

Workflow موردنظر در `.github/workflows/build-apk.yml` داخل این بسته قرار دارد. برای اینکه GitHub آن را اجرا کند، فایل Workflow باید در خود Repository (خارج از ZIP) در همین مسیر وجود داشته باشد و ZIP پروژه در ریشه Repository قرار گیرد.

خروجی Workflow:

`AdminStore-debug.apk`

Artifact:

`AdminStore-APK`
