(() => {
  'use strict';

  const API_BASE = 'https://store-api.weblines.ir/api/v1';
  const HEALTH_URL = 'https://store-api.weblines.ir/health';
  const TOKEN_KEY = 'adminstore.access';
  let token = sessionStorage.getItem(TOKEN_KEY) || '';
  let me = null;
  let page = 'dashboard';
  let cache = { dashboard:null, products:[], orders:[], payments:[], audit:[] };
  let moreOpen = false;
  let modalOpen = false;

  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const esc = (v='') => String(v).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const fa = n => new Intl.NumberFormat('fa-IR').format(Number(n || 0));
  const money = n => `${fa(n)} تومان`;
  const dateFa = v => v ? new Date(v).toLocaleString('fa-IR') : '—';
  const haptic = () => { try { window.NativeBridge?.haptic(); } catch (_) {} };
  const openUrl = url => { try { if (window.NativeBridge?.openUrl) window.NativeBridge.openUrl(url); else window.open(url, '_blank'); } catch (_) {} };

  const statusFa = {
    DRAFT:'پیش‌نویس', AWAITING_PAYMENT:'در انتظار پرداخت', PAYMENT_SUBMITTED:'رسید ارسال شده', PAYMENT_REVIEW:'بررسی پرداخت',
    PAID:'پرداخت شده', PREPARING:'در حال آماده‌سازی', SHIPPED:'ارسال شده', DELIVERED:'تحویل شده', CANCELLED:'لغو شده', RETURNED:'مرجوعی',
    CREATED:'ایجاد شده', REVIEW:'نیازمند بررسی', APPROVED:'تأیید شده', REJECTED:'رد شده', NEEDS_RESUBMISSION:'ارسال مجدد رسید'
  };
  const statusClass = s => ['APPROVED','PAID','DELIVERED'].includes(s) ? 'ok' : ['REVIEW','PAYMENT_REVIEW','PREPARING','SHIPPED','NEEDS_RESUBMISSION'].includes(s) ? 'warn' : ['REJECTED','CANCELLED','RETURNED'].includes(s) ? 'danger' : '';
  const statusBadge = s => `<span class="badge ${statusClass(s)}">${esc(statusFa[s] || s || '—')}</span>`;

  function toast(msg, type='ok') {
    const el = $('#toast');
    el.textContent = msg;
    el.className = `toast show ${type === 'error' ? 'error' : ''}`;
    clearTimeout(toast._t);
    toast._t = setTimeout(() => el.className = 'toast', 2800);
  }

  const errorFa = code => ({
    INVALID_ADMIN_CREDENTIALS:'شماره موبایل یا رمز عبور نادرست است.', UNAUTHORIZED_ADMIN:'نشست مدیر منقضی شده است.', REFRESH_REQUIRED:'لطفاً دوباره وارد شوید.',
    SESSION_EXPIRED:'نشست شما منقضی شده است.', FORBIDDEN:'برای این عملیات دسترسی کافی ندارید.', VALIDATION_ERROR:'اطلاعات واردشده معتبر نیست.',
    PRODUCT_NOT_FOUND:'محصول پیدا نشد.', VARIANT_NOT_FOUND:'واریانت پیدا نشد.', ORDER_NOT_FOUND:'سفارش پیدا نشد.', INVALID_ORDER_TRANSITION:'این تغییر وضعیت مجاز نیست.',
    PAYMENT_NOT_FOUND:'پرداخت پیدا نشد.', PAYMENT_NOT_REVIEWABLE:'این پرداخت قابل بررسی نیست.', RECEIPT_NOT_FOUND:'رسید برای این پرداخت ثبت نشده است.',
    STORAGE_NOT_CONFIGURED:'فضای ذخیره‌سازی رسید هنوز تنظیم نشده است.', STOCK_CHANGED:'موجودی محصول تغییر کرده است.', NETWORK:'اتصال به سرور برقرار نشد.'
  }[code] || code || 'خطای نامشخص');

  async function raw(path, options={}, retry=true) {
    const headers = new Headers(options.headers || {});
    if (!(options.body instanceof FormData)) headers.set('Content-Type','application/json');
    if (token) headers.set('Authorization', `Bearer ${token}`);
    let res;
    try {
      res = await fetch(API_BASE + path, {...options, headers, credentials:'include'});
    } catch (_) {
      const e = new Error('NETWORK'); e.code='NETWORK'; throw e;
    }
    if (res.status === 401 && retry && !path.startsWith('/admin/auth/')) {
      try {
        const rr = await fetch(API_BASE + '/admin/auth/refresh', {method:'POST', credentials:'include'});
        if (rr.ok) {
          const j = await rr.json(); setToken(j.accessToken); me = j.admin || me; return raw(path, options, false);
        }
      } catch (_) {}
    }
    if (!res.ok) {
      let payload = {};
      try { payload = await res.json(); } catch (_) {}
      const e = new Error(payload.error || `HTTP_${res.status}`); e.code = payload.error || `HTTP_${res.status}`; e.status=res.status; e.payload=payload; throw e;
    }
    return res.status === 204 ? null : res.json();
  }
  function setToken(v) { token = v || ''; token ? sessionStorage.setItem(TOKEN_KEY, token) : sessionStorage.removeItem(TOKEN_KEY); }
  const api = {
    login:(mobile,password)=>raw('/admin/auth/login',{method:'POST',body:JSON.stringify({mobile,password})}),
    me:()=>raw('/admin/auth/me'), logout:()=>raw('/admin/auth/logout',{method:'POST'}),
    dashboard:()=>raw('/admin/dashboard'), products:()=>raw('/admin/products'),
    createProduct:data=>raw('/admin/products',{method:'POST',body:JSON.stringify(data)}),
    updateProduct:(id,data)=>raw(`/admin/products/${id}`,{method:'PATCH',body:JSON.stringify(data)}),
    updateVariant:(id,data)=>raw(`/admin/variants/${id}`,{method:'PATCH',body:JSON.stringify(data)}),
    importCatalog:(rows,dryRun)=>raw('/admin/catalog/import',{method:'POST',body:JSON.stringify({rows,dryRun})}),
    orders:()=>raw('/admin/orders'), updateOrderStatus:(id,status)=>raw(`/admin/orders/${id}/status`,{method:'PATCH',body:JSON.stringify({status})}),
    payments:()=>raw('/admin/payments'), receiptUrl:id=>raw(`/admin/payments/${id}/receipt-url`),
    approvePayment:id=>raw(`/admin/payments/${id}/approve`,{method:'POST'}),
    rejectPayment:(id,reason)=>raw(`/admin/payments/${id}/reject`,{method:'POST',body:JSON.stringify({reason,needsResubmission:true})}),
    audit:()=>raw('/admin/audit-logs')
  };

  function appRoot(html) { $('#app').innerHTML = html; }
  function loginView(error='') {
    appRoot(`<section class="login"><form class="login-card" id="login-form">
      <div class="login-logo">A</div><h1>AdminStore</h1><p>مدیریت ساده و امن فروشگاه Store</p>
      ${error ? `<div class="login-error">${esc(error)}</div>` : ''}
      <label class="field"><span>شماره موبایل مدیر</span><input id="mobile" inputmode="numeric" autocomplete="username" placeholder="09xxxxxxxxx" required></label>
      <label class="field"><span>رمز عبور</span><input id="password" type="password" autocomplete="current-password" required></label>
      <button class="btn primary full" id="login-btn">ورود به مدیریت</button>
      <div class="login-note">اتصال امن: store-api.weblines.ir</div>
    </form></section>`);
    $('#login-form').addEventListener('submit', async e => {
      e.preventDefault(); haptic();
      const btn=$('#login-btn'); btn.disabled=true; btn.textContent='در حال ورود…';
      try {
        const r=await api.login($('#mobile').value.trim(), $('#password').value);
        setToken(r.accessToken); me=r.admin; await showShell('dashboard');
      } catch (e) { loginView(errorFa(e.code || e.message)); }
    });
  }

  function shellTemplate() {
    return `<div class="shell">
      <header class="topbar"><div class="brand"><div class="brand-mark">A</div><div><strong>AdminStore</strong><small>${esc(me?.displayName || 'مدیریت فروشگاه')}</small></div></div>
      <div class="top-actions"><button class="icon-btn" id="refresh-btn" aria-label="به‌روزرسانی">↻</button><button class="icon-btn" id="more-top" aria-label="بیشتر">⋮</button></div></header>
      <main class="main" id="content"></main>
      <nav class="bottom-nav">
        ${navButton('dashboard','⌂','خانه')}${navButton('products','▦','محصولات')}${navButton('orders','▤','سفارش‌ها')}${navButton('payments','✓','پرداخت')}${navButton('more','☰','بیشتر')}
      </nav>
      <div id="more-menu"></div>
    </div>`;
  }
  function navButton(id, ico, label) { return `<button class="nav-btn ${page===id?'active':''}" data-page="${id}"><span class="ico">${ico}</span><span>${label}</span></button>`; }

  async function showShell(next='dashboard') {
    page=next; moreOpen=false; appRoot(shellTemplate()); bindShell(); await loadPage(page);
  }
  function bindShell() {
    $$('.nav-btn').forEach(b=>b.addEventListener('click',()=>{haptic(); const p=b.dataset.page; if(p==='more') toggleMore(); else navigate(p);}));
    $('#refresh-btn').addEventListener('click',()=>{haptic(); loadPage(page,true)});
    $('#more-top').addEventListener('click',()=>{haptic(); toggleMore()});
  }
  function updateNav() { $$('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.page===page || (b.dataset.page==='more'&&['customers','import','audit','account'].includes(page)))); }
  async function navigate(p) { page=p; moreOpen=false; renderMore(); updateNav(); await loadPage(p); }
  function toggleMore(){moreOpen=!moreOpen;renderMore();}
  function renderMore(){const host=$('#more-menu'); if(!host)return; host.innerHTML=moreOpen?`<div class="more-menu"><div class="more-grid">
    <button data-more="customers">👥<b>مشتریان</b></button><button data-more="import">⇧<b>ورود CSV</b></button><button data-more="audit">☷<b>گزارش عملیات</b></button><button data-more="account">⚙<b>حساب و سیستم</b></button><button data-more="products">＋<b>محصولات</b></button><button id="close-more">×<b>بستن</b></button>
  </div></div>`:''; $$('[data-more]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.more))); $('#close-more')?.addEventListener('click',()=>toggleMore());}

  function head(title, sub, action='') { return `<div class="page-head"><div><h1>${esc(title)}</h1><p>${esc(sub)}</p></div>${action}</div>`; }
  function loading(title='در حال دریافت اطلاعات…'){ $('#content').innerHTML=head(title,'')+`<div class="loading"><div class="spinner"></div><span>کمی صبر کنید</span></div>`; }
  function pageError(e){ $('#content').innerHTML += `<div class="error-box">${esc(errorFa(e.code||e.message))}</div>`; if(e.status===401){setToken(''); setTimeout(()=>loginView('برای ادامه دوباره وارد شوید.'),700);} }

  async function loadPage(p, force=false) {
    moreOpen=false; renderMore(); updateNav();
    try {
      if(p==='dashboard') return loadDashboard();
      if(p==='products') return loadProducts(force);
      if(p==='orders') return loadOrders(force);
      if(p==='payments') return loadPayments(force);
      if(p==='customers') return loadCustomers(force);
      if(p==='import') return renderImport();
      if(p==='audit') return loadAudit(force);
      if(p==='account') return loadAccount();
    } catch(e){pageError(e)}
  }

  async function loadDashboard(){
    loading('داشبورد');
    try{
      const d=await api.dashboard(); cache.dashboard=d;
      $('#content').innerHTML=head('داشبورد','وضعیت امروز فروشگاه')+`<div class="cards">
        <div class="metric"><span>فروش امروز</span><b>${money(d.salesToday)}</b></div><div class="metric"><span>سفارش امروز</span><b>${fa(d.ordersToday)}</b></div>
        <div class="metric"><span>پرداخت برای بررسی</span><b>${fa(d.pendingPayments)}</b></div><div class="metric"><span>کم‌موجود</span><b>${fa(d.lowStock)}</b></div>
      </div><div class="panel"><h2>کارهای مهم</h2>${d.pendingPayments?`<div class="notice warn">${fa(d.pendingPayments)} پرداخت منتظر بررسی است.</div>`:`<div class="notice">پرداخت معوقی برای بررسی ندارید.</div>`}
      ${d.lowStock?`<div class="notice warn" style="margin-top:8px">${fa(d.lowStock)} واریانت کم‌موجود است.</div>`:''}</div>`;
    }catch(e){pageError(e)}
  }

  async function loadProducts(force=false){
    loading('محصولات');
    try{ if(force||!cache.products.length) cache.products=await api.products(); renderProducts(cache.products); }catch(e){pageError(e)}
  }
  function renderProducts(rows){
    $('#content').innerHTML=head('محصولات','مدیریت قیمت، موجودی و وضعیت',`<button class="btn primary small" id="new-product">＋ محصول</button>`)+`<div class="toolbar"><input class="search" id="product-q" placeholder="جستجوی نام یا SKU"><select class="select" id="product-state"><option value="all">همه</option><option value="active">فعال</option><option value="inactive">غیرفعال</option><option value="low">کم‌موجود</option></select></div><div class="list" id="products-list"></div>`;
    const draw=()=>{const q=$('#product-q').value.trim().toLowerCase(),st=$('#product-state').value; const filtered=rows.filter(p=>{const txt=`${p.name} ${p.brand} ${(p.variants||[]).map(v=>v.sku).join(' ')}`.toLowerCase(); const low=(p.variants||[]).some(v=>v.stock<=3); return (!q||txt.includes(q))&&(st==='all'||(st==='active'&&p.active)||(st==='inactive'&&!p.active)||(st==='low'&&low));}); $('#products-list').innerHTML=filtered.length?filtered.map(productCard).join(''):`<div class="empty">محصولی پیدا نشد.</div>`; $$('[data-edit-product]').forEach(b=>b.addEventListener('click',()=>openProduct(rows.find(x=>x.serverId===b.dataset.editProduct))));};
    $('#product-q').addEventListener('input',draw); $('#product-state').addEventListener('change',draw); $('#new-product').addEventListener('click',openCreateProduct); draw();
  }
  function productCard(p){const variants=p.variants||[];const stock=variants.reduce((s,v)=>s+Number(v.stock||0),0);const min=variants.length?Math.min(...variants.map(v=>Number(v.price||0))):p.price||0;return `<article class="item"><div class="item-top"><div><h3>${esc(p.name)}</h3><div class="item-meta"><span>${esc(p.brand||'Trust')}</span><span>${fa(variants.length)} واریانت</span><span>موجودی ${fa(stock)}</span></div></div><span class="badge ${p.active?'ok':'danger'}">${p.active?'فعال':'غیرفعال'}</span></div><div class="item-actions"><span class="money">${money(min)}</span><button class="btn small" data-edit-product="${esc(p.serverId)}">ویرایش</button></div></article>`;}
  function openProduct(p){if(!p)return; openModal(`ویرایش محصول`, `<form id="edit-product-form"><label class="field"><span>نام محصول</span><input id="ep-name" value="${esc(p.name)}" required></label><label class="field"><span>توضیح کوتاه</span><textarea id="ep-short">${esc(p.shortDescription||'')}</textarea></label><div class="grid2"><label class="field"><span>فعال</span><select id="ep-active"><option value="1" ${p.active?'selected':''}>بله</option><option value="0" ${!p.active?'selected':''}>خیر</option></select></label><label class="field"><span>محصول جدید</span><select id="ep-new"><option value="1" ${p.isNew?'selected':''}>بله</option><option value="0" ${!p.isNew?'selected':''}>خیر</option></select></label></div><button class="btn primary full">ذخیره اطلاعات</button></form><div class="divider"></div><h3>واریانت‌ها</h3>${(p.variants||[]).map(v=>variantForm(v)).join('')||'<div class="empty">واریانتی ندارد.</div>'}`);
    $('#edit-product-form').addEventListener('submit',async e=>{e.preventDefault();try{await api.updateProduct(p.serverId,{name:$('#ep-name').value.trim(),shortDescription:$('#ep-short').value.trim(),active:$('#ep-active').value==='1',isNew:$('#ep-new').value==='1'});toast('محصول ذخیره شد.');closeModal();cache.products=[];loadProducts(true)}catch(e){toast(errorFa(e.code||e.message),'error')}});
    $$('[data-save-variant]').forEach(b=>b.addEventListener('click',async()=>{const id=b.dataset.saveVariant,box=$(`[data-variant-box="${id}"]`);try{await api.updateVariant(id,{price:Number($('.v-price',box).value),compareAtPrice:$('.v-compare',box).value?Number($('.v-compare',box).value):null,stock:Number($('.v-stock',box).value),active:$('.v-active',box).value==='1'});toast('واریانت ذخیره شد.');cache.products=[]}catch(e){toast(errorFa(e.code||e.message),'error')}}));
  }
  function variantForm(v){return `<div class="variant" data-variant-box="${esc(v.id)}"><h4>${esc(v.label||'اصلی')} · ${esc(v.sku)}</h4><div class="grid2"><label class="field"><span>قیمت</span><input class="v-price" type="number" min="0" value="${Number(v.price||0)}"></label><label class="field"><span>قیمت قبلی</span><input class="v-compare" type="number" min="0" value="${v.compareAtPrice??''}"></label><label class="field"><span>موجودی</span><input class="v-stock" type="number" min="0" value="${Number(v.stock||0)}"></label><label class="field"><span>وضعیت</span><select class="v-active"><option value="1" ${v.active?'selected':''}>فعال</option><option value="0" ${!v.active?'selected':''}>غیرفعال</option></select></label></div><button type="button" class="btn small" data-save-variant="${esc(v.id)}">ذخیره واریانت</button></div>`;}
  function openCreateProduct(){openModal('محصول جدید',`<form id="create-product-form"><label class="field"><span>نام محصول</span><input id="cp-name" required></label><label class="field"><span>Slug انگلیسی</span><input id="cp-slug" dir="ltr" required placeholder="trust-product"></label><div class="grid2"><label class="field"><span>برند</span><input id="cp-brand" value="Trust"></label><label class="field"><span>SKU</span><input id="cp-sku" dir="ltr" required></label><label class="field"><span>عنوان واریانت</span><input id="cp-variant" value="اصلی"></label><label class="field"><span>قیمت</span><input id="cp-price" type="number" min="0" required></label><label class="field"><span>قیمت قبلی</span><input id="cp-compare" type="number" min="0"></label><label class="field"><span>موجودی</span><input id="cp-stock" type="number" min="0" value="0"></label></div><label class="field"><span>توضیح کوتاه</span><textarea id="cp-short"></textarea></label><button class="btn primary full">ساخت محصول</button></form>`);$('#create-product-form').addEventListener('submit',async e=>{e.preventDefault();const data={name:$('#cp-name').value.trim(),slug:$('#cp-slug').value.trim(),brand:$('#cp-brand').value.trim()||'Trust',shortDescription:$('#cp-short').value.trim(),active:true,variants:[{sku:$('#cp-sku').value.trim(),title:$('#cp-variant').value.trim()||'اصلی',price:Number($('#cp-price').value),stock:Number($('#cp-stock').value||0)}]};if($('#cp-compare').value)data.variants[0].compareAtPrice=Number($('#cp-compare').value);try{await api.createProduct(data);toast('محصول ساخته شد.');closeModal();cache.products=[];loadProducts(true)}catch(e){toast(errorFa(e.code||e.message),'error')}})}

  async function loadOrders(force=false){loading('سفارش‌ها');try{if(force||!cache.orders.length)cache.orders=await api.orders();renderOrders(cache.orders)}catch(e){pageError(e)}}
  function renderOrders(rows){$('#content').innerHTML=head('سفارش‌ها','پیگیری و تغییر وضعیت سفارش')+`<div class="toolbar"><input class="search" id="order-q" placeholder="شماره سفارش یا موبایل"><select class="select" id="order-state"><option value="all">همه وضعیت‌ها</option>${['AWAITING_PAYMENT','PAYMENT_REVIEW','PAID','PREPARING','SHIPPED','DELIVERED','CANCELLED','RETURNED'].map(s=>`<option value="${s}">${statusFa[s]}</option>`).join('')}</select></div><div class="list" id="orders-list"></div>`;const draw=()=>{const q=$('#order-q').value.trim(),st=$('#order-state').value;const f=rows.filter(o=>(!q||String(o.orderNumber).includes(q)||(o.user?.mobile||'').includes(q))&&(st==='all'||o.status===st));$('#orders-list').innerHTML=f.length?f.map(orderCard).join(''):'<div class="empty">سفارشی پیدا نشد.</div>';$$('[data-order]').forEach(b=>b.addEventListener('click',()=>openOrder(rows.find(x=>x.id===b.dataset.order))));};$('#order-q').addEventListener('input',draw);$('#order-state').addEventListener('change',draw);draw()}
  function orderCard(o){return `<article class="item"><div class="item-top"><div><h3>سفارش #${fa(o.orderNumber)}</h3><div class="item-meta"><span>${esc(o.user?.mobile||'—')}</span><span>${dateFa(o.createdAt)}</span></div></div>${statusBadge(o.status)}</div><div class="item-actions"><span class="money">${money(o.finalTotal)}</span><button class="btn small" data-order="${esc(o.id)}">جزئیات و اقدام</button></div></article>`;}
  const transitions={DRAFT:['AWAITING_PAYMENT'],AWAITING_PAYMENT:['CANCELLED'],PAYMENT_SUBMITTED:['PAYMENT_REVIEW','CANCELLED'],PAYMENT_REVIEW:['AWAITING_PAYMENT','PAID','CANCELLED'],PAID:['PREPARING','CANCELLED'],PREPARING:['SHIPPED','CANCELLED'],SHIPPED:['DELIVERED'],DELIVERED:['RETURNED'],CANCELLED:[],RETURNED:[]};
  function openOrder(o){const addr=o.addressSnapshot||{},ship=o.shippingSnapshot||{};const opts=(transitions[o.status]||[]).map(s=>`<option value="${s}">${statusFa[s]||s}</option>`).join('');openModal(`سفارش #${fa(o.orderNumber)}`,`<div class="kv"><div>وضعیت</div><div>${statusBadge(o.status)}</div><div>مشتری</div><div>${esc([o.user?.firstName,o.user?.lastName].filter(Boolean).join(' ')||'—')} · ${esc(o.user?.mobile||'—')}</div><div>مبلغ نهایی</div><div class="money">${money(o.finalTotal)}</div><div>ثبت</div><div>${dateFa(o.createdAt)}</div><div>گیرنده</div><div>${esc(addr.recipientName||'—')}</div><div>آدرس</div><div>${esc([addr.province,addr.city,addr.addressLine].filter(Boolean).join('، ')||'—')}</div><div>ارسال</div><div>${esc(ship.title||ship.carrier||'—')}</div></div>${opts?`<div class="divider"></div><label class="field"><span>تغییر وضعیت</span><select id="order-next">${opts}</select></label><button class="btn primary full" id="order-update">ثبت وضعیت جدید</button>`:`<div class="notice" style="margin-top:15px">برای وضعیت فعلی اقدام بعدی تعریف نشده است.</div>`}`);$('#order-update')?.addEventListener('click',async()=>{const next=$('#order-next').value;if(!confirm(`وضعیت به «${statusFa[next]||next}» تغییر کند؟`))return;try{await api.updateOrderStatus(o.id,next);toast('وضعیت سفارش تغییر کرد.');closeModal();cache.orders=[];loadOrders(true)}catch(e){toast(errorFa(e.code||e.message),'error')}})}

  async function loadPayments(force=false){loading('پرداخت‌ها');try{if(force||!cache.payments.length)cache.payments=await api.payments();renderPayments(cache.payments)}catch(e){pageError(e)}}
  function renderPayments(rows){$('#content').innerHTML=head('پرداخت‌ها','بررسی رسیدهای کارت‌به‌کارت')+`<div class="toolbar"><select class="select" id="pay-state"><option value="all">همه</option><option value="REVIEW">نیازمند بررسی</option><option value="APPROVED">تأیید شده</option><option value="NEEDS_RESUBMISSION">ارسال مجدد</option><option value="REJECTED">رد شده</option></select></div><div class="list" id="payments-list"></div>`;const draw=()=>{const st=$('#pay-state').value,f=rows.filter(p=>st==='all'||p.status===st);$('#payments-list').innerHTML=f.length?f.map(paymentCard).join(''):'<div class="empty">پرداختی وجود ندارد.</div>';$$('[data-payment]').forEach(b=>b.addEventListener('click',()=>openPayment(rows.find(x=>x.id===b.dataset.payment))));};$('#pay-state').addEventListener('change',draw);draw()}
  function paymentCard(p){return `<article class="item"><div class="item-top"><div><h3>سفارش #${fa(p.order?.orderNumber)}</h3><div class="item-meta"><span>${esc(p.order?.user?.mobile||'—')}</span><span>${dateFa(p.submittedAt||p.createdAt)}</span></div></div>${statusBadge(p.status)}</div><div class="item-actions"><span class="money">${money(p.amount)}</span><button class="btn small" data-payment="${esc(p.id)}">بررسی</button></div></article>`;}
  function openPayment(p){openModal(`پرداخت سفارش #${fa(p.order?.orderNumber)}`,`<div class="kv"><div>وضعیت</div><div>${statusBadge(p.status)}</div><div>مبلغ</div><div class="money">${money(p.amount)}</div><div>شماره پیگیری</div><div>${esc(p.referenceNumber||'—')}</div><div>ثبت رسید</div><div>${dateFa(p.submittedAt)}</div>${p.rejectReason?`<div>علت رد</div><div>${esc(p.rejectReason)}</div>`:''}</div><div class="divider"></div><div class="item-actions"><button class="btn ghost" id="receipt">مشاهده رسید</button>${p.status==='REVIEW'?`<button class="btn primary" id="approve">تأیید پرداخت</button><button class="btn danger" id="reject">رد / ارسال مجدد</button>`:''}</div>`);$('#receipt').addEventListener('click',async()=>{try{const r=await api.receiptUrl(p.id);openUrl(r.url)}catch(e){toast(errorFa(e.code||e.message),'error')}});$('#approve')?.addEventListener('click',async()=>{if(!confirm('پرداخت تأیید شود؟ این کار موجودی را قطعی کم می‌کند.'))return;try{await api.approvePayment(p.id);toast('پرداخت تأیید شد.');closeModal();cache.payments=[];cache.orders=[];loadPayments(true)}catch(e){toast(errorFa(e.code||e.message),'error')}});$('#reject')?.addEventListener('click',()=>rejectPaymentModal(p))}
  function rejectPaymentModal(p){openModal('رد پرداخت',`<p class="subtle">علت را برای مشتری بنویسید. سفارش دوباره در انتظار پرداخت قرار می‌گیرد.</p><label class="field"><span>علت رد</span><textarea id="reject-reason" placeholder="مثلاً تصویر رسید خوانا نیست"></textarea></label><button class="btn danger full" id="reject-submit">ثبت و درخواست ارسال مجدد</button>`);$('#reject-submit').addEventListener('click',async()=>{const reason=$('#reject-reason').value.trim();if(reason.length<3)return toast('علت رد را وارد کنید.','error');try{await api.rejectPayment(p.id,reason);toast('پرداخت رد شد.');closeModal();cache.payments=[];cache.orders=[];loadPayments(true)}catch(e){toast(errorFa(e.code||e.message),'error')}})}

  async function loadCustomers(force=false){loading('مشتریان');try{if(force||!cache.orders.length)cache.orders=await api.orders();const map=new Map();cache.orders.forEach(o=>{const u=o.user||{};const k=u.id||u.mobile;if(!k)return;const x=map.get(k)||{...u,orders:0,total:0,last:null};x.orders++;if(['PAID','PREPARING','SHIPPED','DELIVERED'].includes(o.status))x.total+=Number(o.finalTotal||0);if(!x.last||new Date(o.createdAt)>new Date(x.last))x.last=o.createdAt;map.set(k,x)});const rows=[...map.values()];$('#content').innerHTML=head('مشتریان','خلاصه مشتریان بر اساس سفارش‌های ثبت‌شده')+`<div class="toolbar"><input class="search" id="customer-q" placeholder="جستجوی موبایل یا نام"></div><div class="list" id="customers-list"></div>`;const draw=()=>{const q=$('#customer-q').value.trim().toLowerCase(),f=rows.filter(u=>`${u.mobile} ${u.firstName||''} ${u.lastName||''}`.toLowerCase().includes(q));$('#customers-list').innerHTML=f.length?f.map(u=>`<article class="item"><div class="item-top"><div><h3>${esc([u.firstName,u.lastName].filter(Boolean).join(' ')||u.mobile)}</h3><div class="item-meta"><span>${esc(u.mobile||'—')}</span><span>${fa(u.orders)} سفارش</span></div></div></div><div class="item-actions"><span class="money">${money(u.total)}</span><span class="subtle">آخرین: ${dateFa(u.last)}</span></div></article>`).join(''):'<div class="empty">مشتری پیدا نشد.</div>'};$('#customer-q').addEventListener('input',draw);draw()}catch(e){pageError(e)}}

  function renderImport(){page='import';$('#content').innerHTML=head('ورود CSV','ورود گروهی محصولات و موجودی')+`<div class="panel"><h2>فایل CSV</h2><p class="subtle">برای واردکردن گروهی محصولات، CSV با ستون‌های زیر انتخاب کنید. ابتدا «بررسی» و سپس «ثبت نهایی» انجام می‌شود.</p><div class="csv-help">name,slug,sku,variantTitle,price,compareAtPrice,stock,brand</div><div style="height:10px"></div><input id="csv-file" type="file" accept=".csv,text/csv"><div id="csv-info" class="subtle" style="margin-top:10px"></div><div class="item-actions"><button class="btn" id="csv-check" disabled>بررسی فایل</button><button class="btn primary" id="csv-commit" disabled>ثبت نهایی</button></div><pre id="csv-result" class="csv-help hidden"></pre></div>`;let rows=[];$('#csv-file').addEventListener('change',async e=>{const f=e.target.files?.[0];if(!f)return;rows=parseCSV(await f.text());$('#csv-info').textContent=`${fa(rows.length)} ردیف خوانده شد.`;$('#csv-check').disabled=!rows.length;$('#csv-commit').disabled=!rows.length});$('#csv-check').addEventListener('click',async()=>{try{const r=await api.importCatalog(rows,true);showImportResult(r)}catch(e){toast(errorFa(e.code||e.message),'error')}});$('#csv-commit').addEventListener('click',async()=>{if(!confirm(`${rows.length} ردیف در دیتابیس ثبت شود؟`))return;try{const r=await api.importCatalog(rows,false);showImportResult(r);cache.products=[];toast('ورود کاتالوگ انجام شد.')}catch(e){toast(errorFa(e.code||e.message),'error')}})}
  function parseCSV(text){const lines=text.replace(/^\uFEFF/,'').split(/\r?\n/).filter(x=>x.trim());if(lines.length<2)return[];const split=line=>{const out=[];let cur='',q=false;for(let i=0;i<line.length;i++){const c=line[i];if(c==='"'){if(q&&line[i+1]==='"'){cur+='"';i++}else q=!q}else if(c===','&&!q){out.push(cur.trim());cur=''}else cur+=c}out.push(cur.trim());return out};const h=split(lines[0]);return lines.slice(1).map(line=>{const v=split(line),o={};h.forEach((k,i)=>o[k]=v[i]??'');return {name:o.name,slug:o.slug,sku:o.sku,variantTitle:o.variantTitle||'اصلی',price:Number(o.price||0),compareAtPrice:o.compareAtPrice?Number(o.compareAtPrice):undefined,stock:Number(o.stock||0),brand:o.brand||'Trust'}}).filter(r=>r.name&&r.slug&&r.sku)}
  function showImportResult(r){const el=$('#csv-result');el.classList.remove('hidden');el.textContent=JSON.stringify(r,null,2)}

  async function loadAudit(force=false){loading('گزارش عملیات');try{if(force||!cache.audit.length)cache.audit=await api.audit();$('#content').innerHTML=head('گزارش عملیات','آخرین فعالیت‌های مدیریتی')+`<div class="panel">${cache.audit.length?cache.audit.map(a=>`<div class="audit-item"><b>${esc(a.action)} · ${esc(a.entityType)}</b><small>${dateFa(a.createdAt)} · ${esc(a.adminUser?.displayName||a.adminUser?.mobile||'سیستم')}</small></div>`).join(''):'<div class="empty">گزارشی ثبت نشده است.</div>'}</div>`}catch(e){pageError(e)}}

  async function loadAccount(){loading('حساب و سیستم');let health=null;try{me=await api.me()}catch(e){return pageError(e)}try{const r=await fetch(HEALTH_URL,{cache:'no-store'});health=r.ok?await r.json():null}catch(_){health=null}$('#content').innerHTML=head('حساب و سیستم','وضعیت اتصال و نشست مدیر')+`<div class="panel"><h2>مدیر واردشده</h2><div class="kv"><div>نام</div><div>${esc(me?.displayName||'—')}</div><div>موبایل</div><div>${esc(me?.mobile||'—')}</div><div>دسترسی‌ها</div><div>${fa(me?.permissions?.length||0)} مورد</div></div></div><div class="panel"><h2>وضعیت سرویس</h2><div class="kv"><div>API</div><div class="${health?'health-ok':'health-bad'}">${health?'متصل':'عدم اتصال'}</div><div>Database</div><div>${esc(health?.database||'—')}</div><div>Version</div><div>${esc(health?.version||'—')}</div><div>Admin App</div><div>0.61-RC1</div></div></div><button class="btn danger full" id="logout">خروج از حساب</button>`;$('#logout').addEventListener('click',async()=>{if(!confirm('از حساب مدیر خارج شوید؟'))return;try{await api.logout()}catch(_){}setToken('');me=null;cache={dashboard:null,products:[],orders:[],payments:[],audit:[]};loginView()})}

  function openModal(title, body){modalOpen=true;$('#modal-root').innerHTML=`<div class="modal-wrap" id="modal-wrap"><section class="modal"><div class="modal-head"><h2>${esc(title)}</h2><button class="modal-close" id="modal-close">×</button></div>${body}</section></div>`;$('#modal-close').addEventListener('click',closeModal);$('#modal-wrap').addEventListener('click',e=>{if(e.target.id==='modal-wrap')closeModal()})}
  function closeModal(){modalOpen=false;$('#modal-root').innerHTML=''}
  window.AdminStoreBack=()=>{if(modalOpen){closeModal();return true}if(moreOpen){toggleMore();return true}if(page!=='dashboard'){navigate('dashboard');return true}return false};

  async function init(){loginView();try{me=await api.me();await showShell('dashboard')}catch(_){setToken('');loginView()}}
  init();
})();
