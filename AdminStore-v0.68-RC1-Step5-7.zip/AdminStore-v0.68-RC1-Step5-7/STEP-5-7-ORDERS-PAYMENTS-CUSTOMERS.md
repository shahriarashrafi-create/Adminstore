# Step 5–7 — Orders, Payments & Customers

Version: `0.68-RC1` (`versionCode 8`)

## Step 5 — Orders + Shipping

- Order list with search and status filtering.
- Full order detail with customer, address, items, totals and payment state.
- Controlled status transitions for both legacy and new backend status names.
- Shipping card with carrier/method, tracking code, shipping cost and shipped date.
- Shipping update flow guarded by `orders.shipping` (with compatible aliases).
- Cancellation flow guarded by `orders.cancel`, with required reason and optional admin note.
- Cancellation is hidden after shipment/delivery; post-shipment handling belongs to Return flow.
- Order timeline/history supports `/timeline`, `/history`, inline timeline/statusHistory and a safe fallback.

## Step 6 — Payments + Refund

- Payment list with search and expanded status filtering.
- Payment detail and payment timeline/history.
- Receipt viewing.
- Approve payment flow.
- Separate final Reject and Needs Resubmission flows, both requiring a reason.
- Full and partial refund UI with amount validation, reason and optional admin note.
- Refund actions are guarded by `payments.refund`.
- Order/payment caches are invalidated together after state-changing actions.

## Step 7 — Customers

- `/admin/customers` is now the primary customer source.
- Customer detail uses `/admin/customers/:id` when available.
- Customer orders and payments use dedicated endpoints when available.
- Customer profile includes contact details, account status, registration date, addresses, order history, payment history and lifetime purchase value.
- Customer status management: Active / Inactive / Blocked, guarded by `customers.update`.
- Admin support note flow with compatible endpoint fallback.
- A temporary compatibility fallback can derive customers from orders only when the Customer endpoint is unavailable; it is clearly labeled in the UI and is no longer the primary model.

## Permissions added

- `orders.cancel`
- `orders.shipping`
- `payments.refund`
- `customers.update`

Aliases for common backend naming variants remain supported. Backend authorization is still authoritative.

## Compatibility strategy

Because the backend may expose slightly different route names while evolving, destructive or newer actions use explicit endpoint fallback only where safe. Missing optional detail/history endpoints do not break the main list views.
