# Step 2 — Auth + Permission

Version: `0.63-RC1` (`versionCode 3`)

## Permission model

Canonical client permissions:

- `products.view`
- `products.create`
- `products.update`
- `orders.view`
- `orders.update`
- `payments.view`
- `payments.review`
- `customers.view`
- `catalog.import`
- `audit.view`

The permission engine also understands common backend aliases and object-shaped permissions (`name`, `key`, `code`, `slug`, etc.). `*`, `admin.*`, Super Admin and Owner roles grant all client UI permissions.

## Page guards

- Dashboard: any authenticated admin
- Products: products.view
- Orders: orders.view
- Payments: payments.view
- Customers: customers.view OR orders.view (current customer screen is derived from order data)
- CSV Import: catalog.import OR products.create
- Audit: audit.view
- Account: any authenticated admin

## Action guards

- Create Product: products.create
- Edit Product / Variant: products.update
- Change Order Status: orders.update
- Approve/Reject Payment: payments.review

All operations still rely on backend authorization. UI guards never replace server-side permission checks.

## Auth behavior

1. Login returns an access token.
2. Client immediately calls `/admin/auth/me` and uses that response as the authoritative admin identity/role/permission model.
3. Expired access tokens are refreshed once, with concurrent refresh calls deduplicated.
4. 401 clears the client session.
5. 403 renders a dedicated forbidden state instead of treating the user as logged out.
