# Step 3 + 4 — Catalog / Products + Inventory

Version: `0.65-RC1` (`versionCode 5`)

## Step 3 — Products / Catalog

- Product list upgraded with search, status, brand, category and sort controls.
- Supports server-side query params and paginated API responses, while keeping a client-side fallback for the current array response.
- Product detail view added.
- Product edit expanded with slug, brand, category, active/new flags and short description.
- Product archive/delete action added with DELETE -> PATCH archive fallback.
- Product images: gallery, upload, delete and main-image actions added.
- Variant management: create, edit and delete.
- SKU validation uses the backend endpoint when available and falls back to the already-loaded catalog.
- Catalog page added for categories, brands and attributes.
- Catalog metadata is derived from products when dedicated catalog endpoints are not available.
- CSV import remains compatible with the existing backend contract.

## Step 4 — Inventory

- Dedicated Inventory page added.
- Total stock, variant count, low-stock and out-of-stock metrics.
- Search and stock-state filters.
- Stock adjustment flow supports Increase / Decrease / Set Final Quantity and requires a reason.
- Dedicated inventory adjustment endpoints are used when available.
- If the backend has no inventory-adjust endpoint, the app safely falls back to the existing variant stock PATCH endpoint.
- Inventory history screen added; dedicated history endpoints are probed and a clear backend-capability notice is shown if unavailable.
- Direct stock editing was removed from the normal variant edit form so stock changes flow through Inventory Adjustment.

## New client permissions

- `products.delete`
- `variants.create`
- `variants.delete`
- `catalog.view`
- `catalog.manage`
- `inventory.view`
- `inventory.update`

Common backend aliases and existing `products.view` / `products.update` grants remain supported for compatibility.

## Optional backend endpoints recognized by this client

The client keeps compatibility with the current backend and only uses these when present:

- `GET /admin/products/:id`
- `DELETE /admin/products/:id`
- `POST /admin/products/:id/variants`
- `DELETE /admin/products/:id/variants/:variantId`
- `GET /admin/variants/validate-sku`
- `GET/POST/PATCH/DELETE /admin/categories`
- `GET/POST/PATCH/DELETE /admin/brands`
- `GET/POST/PATCH/DELETE /admin/attributes`
- `POST /admin/products/:id/images`
- `DELETE/PATCH /admin/products/:id/images/:imageId`
- `GET /admin/inventory`
- `POST /admin/inventory/:variantId/adjust`
- `GET /admin/inventory/:variantId/history`

For variant create/delete, image operations and inventory operations, alternate conventional endpoint shapes are also supported where possible.

## Build validation

- `app.js`: syntax checked with Node.
- `permissions.js`: syntax checked with Node.
- CI workflow validates both JS files before Android build.
- Full Gradle build still requires network access to Gradle/Maven; GitHub Actions is configured for that environment.
