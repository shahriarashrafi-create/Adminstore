const fs=require('fs');
const path=require('path');
const base=path.join(__dirname,'..','app','src','main','assets');
const app=fs.readFileSync(path.join(base,'app.js'),'utf8');
const perms=fs.readFileSync(path.join(base,'permissions.js'),'utf8');
const requiredPages=['marketing','reports','administration','settings','diagnostics'];
const requiredApi=['coupons:','reviews:','banners:','campaigns:','admins:','reports:','settings:','capabilities:'];
const missing=[];
for(const x of requiredPages) if(!app.includes(`p==='${x}'`)) missing.push(`page:${x}`);
for(const x of requiredApi) if(!app.includes(x)) missing.push(`api:${x}`);
for(const x of ['MARKETING_VIEW','ADMINS_MANAGE','REPORTS_VIEW','SETTINGS_MANAGE','DIAGNOSTICS_VIEW']) if(!perms.includes(x)) missing.push(`permission:${x}`);
if(!app.includes('REQUEST_TIMEOUT')) missing.push('request-timeout');
if(!app.includes('updateNetworkStatus')) missing.push('network-state');
if(missing.length){console.error('Smoke test failed:',missing.join(', '));process.exit(1)}
console.log('AdminStore smoke tests passed.');
