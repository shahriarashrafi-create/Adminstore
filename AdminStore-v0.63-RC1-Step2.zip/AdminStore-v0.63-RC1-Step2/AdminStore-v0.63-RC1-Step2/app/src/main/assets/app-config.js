window.AdminStoreConfig = Object.freeze({
  apiBase: 'https://store-api.weblines.ir/api/v1',
  healthUrl: 'https://store-api.weblines.ir/health',
  appVersion: '0.63-RC1'
});
