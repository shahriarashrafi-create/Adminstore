(() => {
  'use strict';

  const P = Object.freeze({
    PRODUCTS_VIEW: 'products.view',
    PRODUCTS_CREATE: 'products.create',
    PRODUCTS_UPDATE: 'products.update',
    ORDERS_VIEW: 'orders.view',
    ORDERS_UPDATE: 'orders.update',
    PAYMENTS_VIEW: 'payments.view',
    PAYMENTS_REVIEW: 'payments.review',
    CUSTOMERS_VIEW: 'customers.view',
    CATALOG_IMPORT: 'catalog.import',
    AUDIT_VIEW: 'audit.view'
  });

  // Canonical permissions are the values above. Aliases keep the client compatible
  // with common backend naming variants; the backend remains the security authority.
  const aliases = Object.freeze({
    [P.PRODUCTS_VIEW]: ['products.view', 'product.view', 'products.read', 'catalog.view'],
    [P.PRODUCTS_CREATE]: ['products.create', 'product.create', 'products.write', 'catalog.create'],
    [P.PRODUCTS_UPDATE]: ['products.update', 'product.update', 'products.edit', 'catalog.update'],
    [P.ORDERS_VIEW]: ['orders.view', 'order.view', 'orders.read'],
    [P.ORDERS_UPDATE]: ['orders.update', 'order.update', 'orders.edit', 'orders.status.update'],
    [P.PAYMENTS_VIEW]: ['payments.view', 'payment.view', 'payments.read'],
    [P.PAYMENTS_REVIEW]: ['payments.review', 'payment.review', 'payments.update', 'payments.approve', 'payments.manage'],
    [P.CUSTOMERS_VIEW]: ['customers.view', 'customer.view', 'customers.read', 'users.view'],
    [P.CATALOG_IMPORT]: ['catalog.import', 'products.import', 'catalog.manage'],
    [P.AUDIT_VIEW]: ['audit.view', 'audit.read', 'audit_logs.view', 'activity_logs.view']
  });

  const pageAccess = Object.freeze({
    dashboard: null,
    products: { any: [P.PRODUCTS_VIEW] },
    orders: { any: [P.ORDERS_VIEW] },
    payments: { any: [P.PAYMENTS_VIEW] },
    // Customers are currently derived from orders, so orders.view is an accepted fallback.
    customers: { any: [P.CUSTOMERS_VIEW, P.ORDERS_VIEW] },
    import: { any: [P.CATALOG_IMPORT, P.PRODUCTS_CREATE] },
    audit: { any: [P.AUDIT_VIEW] },
    account: null
  });

  const norm = value => String(value ?? '').trim().toLowerCase();

  function permissionName(value) {
    if (typeof value === 'string') return norm(value);
    if (!value || typeof value !== 'object') return '';
    return norm(value.permission ?? value.name ?? value.key ?? value.code ?? value.slug ?? value.value);
  }

  function roleName(admin) {
    const role = admin?.role ?? admin?.adminRole ?? admin?.roleName;
    if (typeof role === 'string') return norm(role);
    if (!role || typeof role !== 'object') return '';
    return norm(role.name ?? role.key ?? role.code ?? role.slug ?? role.value);
  }

  function isSuperAdmin(admin) {
    if (admin?.isSuperAdmin === true || admin?.superAdmin === true) return true;
    return ['super_admin', 'super-admin', 'superadmin', 'owner'].includes(roleName(admin));
  }

  function getSet(admin) {
    const source = Array.isArray(admin?.permissions)
      ? admin.permissions
      : Array.isArray(admin?.role?.permissions)
        ? admin.role.permissions
        : [];
    return new Set(source.map(permissionName).filter(Boolean));
  }

  function grantMatches(grant, requested) {
    if (!grant || !requested) return false;
    if (grant === '*' || grant === 'admin.*') return true;
    if (grant === requested) return true;
    if (grant.endsWith('.*')) return requested.startsWith(grant.slice(0, -1));
    return false;
  }

  function has(admin, requested) {
    if (!requested) return true;
    if (isSuperAdmin(admin)) return true;
    const set = getSet(admin);
    const accepted = aliases[requested] || [requested];
    for (const grant of set) {
      for (const candidate of accepted) {
        if (grantMatches(grant, norm(candidate))) return true;
      }
    }
    return false;
  }

  const hasAny = (admin, requested=[]) => !requested.length || requested.some(p => has(admin, p));
  const hasAll = (admin, requested=[]) => requested.every(p => has(admin, p));

  function canAccessPage(admin, page) {
    const rule = pageAccess[page];
    if (!rule) return true;
    if (rule.any && !hasAny(admin, rule.any)) return false;
    if (rule.all && !hasAll(admin, rule.all)) return false;
    return true;
  }

  function list(admin) {
    return [...getSet(admin)].sort();
  }

  window.AdminStorePermissions = Object.freeze({
    P,
    aliases,
    pageAccess,
    has,
    hasAny,
    hasAll,
    canAccessPage,
    isSuperAdmin,
    roleName,
    list
  });
})();
