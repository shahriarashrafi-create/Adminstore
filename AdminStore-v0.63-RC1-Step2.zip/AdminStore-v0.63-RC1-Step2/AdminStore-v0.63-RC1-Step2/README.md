# AdminStore Android — v0.63 RC1

نسخه‌ی Foundation تثبیت‌شده‌ی اپلیکیشن Android مدیریت Store.

## اتصال Backend

مقادیر پیش‌فرض در `gradle.properties` قرار دارند:

- `ADMINSTORE_API_BASE_URL=https://store-api.weblines.ir/api/v1`
- `ADMINSTORE_HEALTH_URL=https://store-api.weblines.ir/health`

در Build اندروید این مقادیر به `BuildConfig` منتقل می‌شوند و از طریق Native Bridge در اختیار رابط WebView قرار می‌گیرند. فایل `app-config.js` فقط fallback برای اجرای مستقیم assetها خارج از Android است. هیچ رمز عبور، JWT secret یا credential داخل پروژه قرار ندارد.

## اصلاحات Step 1

- نسخه به `0.62-RC1` / `versionCode 2` ارتقا یافت.
- آدرس API و Health از `app.js` خارج و قابل تنظیم شد.
- Refresh Token برای `/admin/auth/me` نیز فعال شد؛ بنابراین نشست دارای Refresh Cookie بعد از از دست رفتن Access Token قابل بازیابی است.
- Refreshهای همزمان به یک درخواست مشترک تبدیل شدند تا چند Refresh موازی ارسال نشود.
- تنظیمات امنیتی WebView برای جلوگیری از Mixed Content و فعال‌بودن Safe Browsing تقویت شد.
- GitHub Action هم پروژه‌ی Extract‌شده و هم ZIP را تشخیص می‌دهد و Java 17 / Gradle 8.7 را Pin می‌کند.
- اسکریپت `gradlew` ابتدا Gradle 8.7 نصب‌شده توسط CI/سیستم را استفاده می‌کند و فقط در صورت نبود آن Bootstrap می‌کند.
- `.gitignore` اضافه شد.

## بخش‌های فعلی اپ

- Login / Refresh / Logout
- Dashboard
- Products و Variant editing
- Orders و تغییر وضعیت
- Payments و بررسی رسید
- Customers summary
- CSV import
- Audit Log
- Account / Health

## Build

نیازمندی‌ها: Java 17 و Gradle 8.7.

```bash
chmod +x ./gradlew
./gradlew assembleDebug
```

خروجی معمولاً در مسیر زیر ساخته می‌شود:

`app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions

Workflow در `.github/workflows/build-apk.yml` قرار دارد. اگر سورس Extract‌شده در Repository باشد مستقیماً همان را Build می‌کند؛ اگر فقط ZIP در ریشه Repository باشد، جدیدترین ZIP را Extract کرده و پروژه Android داخل آن را Build می‌کند.

Artifact خروجی: `AdminStore-APK`

## اصلاحات Step 2 — Auth & Permissions

- نسخه به `0.63-RC1` / `versionCode 3` ارتقا یافت.
- Permission engine مستقل در `assets/permissions.js` اضافه شد.
- Permissionهای string و object-based پشتیبانی می‌شوند.
- نقش‌های Super Admin/Owner و wildcardهای `*` / `admin.*` پشتیبانی می‌شوند.
- Navigation بر اساس دسترسی مدیر فیلتر می‌شود.
- ورود مستقیم به صفحه‌ی غیرمجاز با نمای 403 مسدود می‌شود.
- عملیات حساس Product، Order و Payment در UI بر اساس Permission کنترل می‌شوند.
- بعد از Login، `/admin/auth/me` مرجع نهایی نقش و Permissionهاست.
- صفحه Account اکنون Role و Permissionهای واقعی مدیر را نمایش می‌دهد.
- خطای 403 سمت Backend نیز به نمای دسترسی محدود تبدیل می‌شود.

> کنترل Permission در Frontend فقط برای UX است؛ Backend همچنان مرجع امنیت و مجوز عملیات است.
