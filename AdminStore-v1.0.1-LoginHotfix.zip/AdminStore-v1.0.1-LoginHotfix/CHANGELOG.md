# Changelog

## 1.0.1 — Login Hotfix

- Restored the last known-working WebView login transport from v0.78.
- Fixed `403 Forbidden` regression introduced by the v0.83 virtual API-host origin.
- Retained all v1.0 functionality and stable release signing.
- versionCode 101.

## 1.0.0
Production baseline for AdminStore.

- Stable Android package identity and fixed release signing
- Update-safe versioning baseline
- Authentication, refresh-token and permission guards
- Catalog, products, variants, images and inventory workflows
- Orders, shipping, payments, receipts and refunds
- Customers, marketing content and moderation
- Admins, roles, reports, settings and audit capabilities
- Central API contract and compatibility diagnostics
- Automated E2E/contract/security test suite
- Hardened WebView and HTTPS local asset origin
- Release APK verification, certificate verification and SHA-256 output in CI
