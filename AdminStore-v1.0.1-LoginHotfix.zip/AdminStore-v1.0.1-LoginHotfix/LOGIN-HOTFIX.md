# AdminStore v1.0.1 — Login Hotfix

## Regression fixed

`v0.83` changed the WebView application origin from the previously working
`file:///android_asset/index.html` transport to a virtual HTTPS origin on the
API host. The same release also changed cookie policy and added a CSP tied to
that new origin.

On the deployed backend this caused `POST /admin/auth/login` to return
`403 Forbidden`, even though the same credentials worked in earlier builds.

## What v1.0.1 does

- Restores the last known-working WebView login transport from `v0.78`.
- Restores third-party cookie behavior used by that working transport.
- Removes the CSP that was coupled to the virtual API-host origin.
- Keeps all AdminStore features added after v0.78.
- Keeps `usesCleartextTraffic=false`, mixed-content blocking and Safe Browsing.
- Keeps the stable v1.0 release signing key so v1.0.1 updates over v1.0.0.
- Bumps version to `1.0.1` / `versionCode 101`.

No backend change is required for this hotfix.
