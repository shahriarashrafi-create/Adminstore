const assert=require('assert');
const fs=require('fs');
const path=require('path');
const root=path.join(__dirname,'..');
const kt=fs.readFileSync(path.join(root,'app/src/main/java/com/store/admin/MainActivity.kt'),'utf8');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
const manifest=fs.readFileSync(path.join(root,'app/src/main/AndroidManifest.xml'),'utf8');
// Login compatibility hotfix: restore the exact WebView transport used by the last known-working build (v0.78).
assert.ok(kt.includes('file:///android_asset/index.html'));
assert.ok(kt.includes('allowUniversalAccessFromFileURLs = true'));
assert.ok(kt.includes('allowFileAccess = true'));
assert.ok(kt.includes('setAcceptThirdPartyCookies(webView, true)'));
// Keep network-level protections that do not alter the working login transport.
assert.ok(kt.includes('mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW'));
assert.ok(manifest.includes('usesCleartextTraffic="false"'));
assert.ok(manifest.includes('networkSecurityConfig'));
// CSP from v0.83 intentionally removed because it was coupled to the virtual API-host origin regression.
assert.ok(!html.includes('Content-Security-Policy'));
console.log('WebView login-compatibility/security baseline test passed.');
