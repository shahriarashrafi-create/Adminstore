# AdminStore Release Identity

- Application ID: `com.store.admin`
- Version: `1.0.1`
- Version code: `100`
- Signing alias: `adminstore`
- Signing certificate SHA-256: `B7:02:26:83:8B:4B:34:C1:BA:0B:17:25:7A:95:6F:DE:C7:06:79:60:42:F3:1A:91:78:9C:0D:7C:BA:99:B7:82`
- Release keystore: `keystore/adminstore-release.jks`

This signing identity must remain unchanged for every future APK update. Replacing the keystore will prevent Android from installing the new APK as an update over existing production installs.

The signing material is bundled with this project by design for deterministic update-safe builds. Keep the repository private and keep secure backups of the ZIP/keystore.
